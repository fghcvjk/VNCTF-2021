var kuicms=[];

/*表单验证规则，可修改*/
kuicms.rules=function(label)
{
	return {
		required:[/[^(^\s*)|(\s*$)]/,label+'不能为空']
		,int:[/^\d+$/,"请填写数字"]
		,dot: [/^(\-|\+)?\d{1,10}(?:\.\d{0,2})?$/, "请输入数字"]
		,letters:[/^[a-z]+$/i,"请填写字母"]
		,date:[/^\d{4}-\d{2}-\d{2}$/,"请填写有效的日期，格式:yyyy-mm-dd"]
		,time:[/^([01]\d|2[0-3])(:[0-5]\d){1,2}$/,"请填写有效的时间，00:00到23:59之间"]
		,email:[/^[\w\+\-]+(\.[\w\+\-]+)*@[a-z\d\-]+(\.[a-z\d\-]+)*\.([a-z]{2,4})$/i,"请填写有效的邮箱"]
		,url:[/^(https?|s?ftp):\/\/\S+$/i,"请填写有效的网址"]
		,qq:[/^[1-9]\d{4,}$/,"请填写有效的QQ号"]
		,IDcard:[/^\d{6}(19|2\d)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)?$/,"请填写正确的身份证号码"]
		,tel:[/^(?:(?:0\d{2,3}[\- ]?[1-9]\d{6,7})|(?:[48]00[\- ]?[1-9]\d{6}))$/,"请填写有效的电话号码"]
		,mobile:[/^1[3-9]\d{9}$/,"请填写有效的手机号"]
		,zipcode:[/^\d{6}$/,"请检查邮政编码格式"]
		,chinese:[/^[\u0391-\uFFE5]+$/,"请填写中文字符"]
		,username:[/^[\u0391-\uFFE5\w\d]{3,12}$/,"请填写3-12位数字、字母、中文、下划线"]
		,password:[/^[\S]{5,16}$/,"请填写5-16位字符，不能包含空格"]
	}
};

kuicms.language=function()
{
	return {
		homepage:"设置首页失败，请手动设置！",
		favorite:"加入收藏失败，请使用Ctrl+D进行添加",
		ok:"确定",
		cancel:"取消",
		city:"请选择省市区",
		backtime:"秒后重发",
		over:'已结束',
		day:'天',
		hour:'时',
		minute:'分',
		second:'秒',
		checked:"请选择",
		length:"长度：",
		min:"不能小于：",
		max:"不能大于：",
		between:"请输入{1}至{2}之间的数值",
		match:"{1}与{2}不一致",
		total:'总数：',
		pre:'上一页',
		next:'下一页',
		home:'首页',
		last:'末页',
	}
};

kuicms.root="/";

kuicms.success=function(text,align,title,color,progress,time)
{
	$.success(
	{
		'title':title,
		'text':text,
		'align':align,
		'color':color,
		'progress':progress,
		'time':time
	});
};

kuicms.error=function(text,align,title,color,progress,time)
{
	$.error(
	{
		'title':title,
		'text':text,
		'align':align,
		'color':color,
		'progress':progress,
		'time':time
	});
};

kuicms.warn=function(text,align,title,color,progress,time)
{
	$.warn(
	{
		'title':title,
		'text':text,
		'align':align,
		'color':color,
		'progress':progress,
		'time':time
	});
};

kuicms.loading=function(text,align,title,color,progress,time)
{
	$.loading(
	{
		'title':title,
		'text':text,
		'align':align,
		'color':color,
		'progress':progress,
		'time':time
	});
};

$(function()
{
	/*轮播必备：自定义事件*/
	$.event.special.UiTransitionEnd=
	{
		bindType:'transitionend',
		delegateType:'transitionend',
		handle:function(e)
		{
			if($(e.target).is(this))
			{
				return e.handleObj.handler.apply(this,arguments);
			}
		}
    };
	$(document).on("click",".ui-homepage",function()
	{
		if(document.all)
		{
            document.body.style.behavior="url(#default#homepage)";
            document.body.setHomePage(document.URL);
        }
		else
		{
            alert(kuicms.language()['homepage'])
        }
	});
	$(document).on("click",".ui-favorite",function()
	{
		var url=document.URL;
        var title=document.title;
        try
		{
            window.external.addFavorite(url,title);
        }
		catch(e)
		{
            try
			{
                window.sidebar.addPanel(title,url,"");
            }
			catch(e)
			{
                alert(kuicms.language()['favorite']);
            }
        }
	});

    $(document).on("click",".ui-back",function()
	{
		window.history.go(-1);
	});
	
	$(document).on("click",".ui-backtop",function()
	{
		if($(document).scrollTop()>50)
		{
			$("body,html").animate({scrollTop:0},1000);
		}
        return false;
	});
	
	$(document).on("click",".ui-refresh",function()
	{
		window.location.reload();
	});
	$(document).on("click",".ui-print",function()
	{
		window.print();
	});
	$(document).on("click",".ui-copy",function()
	{
		var target=$(this).attr("data-target");
		$("#"+target).select();
		document.execCommand("Copy");
		kuicms.success("复制成功");
	});
	$(document).on("click",".ui-close",function()
	{
		 window.close();
	});

	/*表单中全选/取消*/
	$(document).on("click",".checkall",function()
	{
		var result=this.checked;
		$(this).closest("form").find(":checkbox").each(function()
		{
			if(!$(this).closest("label").hasClass("switch"))
			{
				this.checked=result;
			}
		})
	});

	/*文本框自动高度*/
	$('.form-limit').each(function()
	{
		this.setAttribute('style','height:'+(this.scrollHeight)+'px;overflow-y:hidden;');
	}).on('input',function()
	{
		this.style.height='auto';this.style.height=(this.scrollHeight)+'px';
		/*字数限制开始*/
		var e=$(this);
		var $max=(e.attr("data-max") || 255);
		var $target=e.attr("data-target");
		if($target==null)
		{
			$target=e.closest(".form-group").find(".form-limit-text");
		}
		else
		{
			$target=$($target);
		}
		var str=e.val();
		if(str.length>$max)
		{
			e.val(str.substring(0,$max));
		}
		var $min=str.length;
		if($min>$max){$min=$max;}
		$target.html("<span>"+$min+"</span>/"+$max);
		/*字数限制结束*/
	});

	$(".form-submit").each(function()
	{
		var e=$(this);
		var type=e.attr("data-type") || 1;
		var hide=e.attr("data-hide") || 1;
		var show=e.attr("data-show") || 0;
		if(type==2)
		{
			show=0;
		}
		/*添加相关属性*/
		e.closest("form").attr("data-type",type);
		e.closest("form").attr("data-hide",hide);
		e.closest("form").attr("data-show",show);
	});
	$(":input").blur(function()
	{
		var e=$(this);
		var type=e.closest("form").attr("data-type");
		var hide=e.closest("form").attr("data-hide");
		var align=e.closest("form").attr("data-align");
		if(type==2)
		{
			if($(this).val()=='')
			{
				return false;
			}
			else
			{
				$input(e,type,hide,align);
			}
		}
		else
		{
			$input(e,type,hide,align);
		}
    });
	$input=function(e,formtype,formhide,formalign)
	{
		if(formtype==null){formtype=1;}
		if(formhide==null){formhide=1;}
		if(formalign==null || formalign==''){formalign='top-right'}
		var isvalidator=0;
		if(formhide==1)
		{
			if(!e.is(":hidden"))
			{
				isvalidator=1;
			}
		}
		else
		{
			isvalidator=1;
		}
		if(isvalidator==1)
		{
			var name=e.attr("name");
			if(e.attr("data-rule"))
			{
				var ismsg=0;
				if(e.closest(".form-group").find(".error-msg").length>0)
				{
					ismsg=1;
				}
				var $checkdata=e.attr("data-rule");
				$checkdata=$checkdata.split(":");
				var $label=$checkdata[0];
				if($label.indexOf("required")>=0)
				{
					$label='';
					$checkdata=$checkdata[0];
				}
				else
				{
					$label=$checkdata[0];
					$checkdata=$checkdata[1];
				}
				var $checkvalue=e.val();
				var $checkstate=true;
				var $checktext="";
				if(e.attr("placeholder")==$checkvalue)
				{
					$checkvalue=$label;
				}
				if($checkvalue!="" || e.attr("data-rule").indexOf("required")>=0)
				{
					var $data=$checkdata.split(";");
					for(var i=0;i<$data.length;i++)
					{
						if($data[i]!='')
						{
							var result=$formcheck(e,$data[i],$checkvalue,$label);
							if(result!=true)
							{
								$checkstate=false;
								$checktext=result;
								break;
							}
						}
					}
				}
				if($checkstate)
				{
					e.closest(".form-group").find(".error-msg").fadeOut(300,function(){$(this).remove();});
					setTimeout(function(){e.closest(".form-group").removeClass("check-error");},300)
					if(formtype>1)
					{
						/*验证成功后移除提示，防止提示还在页面上*/
						$(".ui-toast").remove();
					}
					return true;
				}
				else
				{
					e.closest(".form-group").addClass("check-error");
					if(formtype==1)
					{
						if(ismsg==0)
						{
							e.closest(".form-group").append('<span class="error-msg ui-am-scale-up">'+$checktext+"</span>");
						}
						else
						{
							e.closest(".form-group").find(".error-msg").html($checktext);
						}
					}
					else
					{
						e.closest(".form-group").find(".form-icon").css({"top":"45%"})
						$.warn({text:$checktext,align:formalign});
					}
					return false;
				}
			}
		}
		else
		{
			return true;
		}
	};
	
    $formcheck=function(element,type,value,label)
	{
        $value=value.replace(/(^\s*)|(\s*$)/g,"");
		var rules=kuicms.rules(label);
		var data=rules[type];
		if(data)
		{
			if(data[0].test($value))
			{
				return true;
			}
			else
			{
				return data[1];
			}
		}
		else
		{
			if(type=='checked')
			{
				var radio=element.closest("form").find('input[name="'+element.attr("name")+'"]:checked').length;
				if(radio==0)
				{
					return kuicms.language()['checked']+label;
				}
				else
				{
					return true;
				}
			}
			var rRule=/(\w+)(?:\[\s*(.*?\]?)\s*\]|\(\s*(.*?\)?)\s*\))?/;
			var parts=rRule.exec(type);
			if(parts)
			{
				method=parts[1];

				params=parts[2] || parts[3];
				switch(method)
				{
					case "length":
						var length=element.closest("form").find('input[name="'+element.attr("name")+'"]:checked').length;
						var $test=params.split("#");
						var where=params;
						var text=kuicms.language()['length']+params;
						if($test.length==2)
						{
							 where=$test[0];
							 text=$test[1];
						}
						if(!eval(length+where))
						{
							return text;
						}
						break;
					case "min":
						if(parseFloat($value)<parseFloat(params))
						{
							return kuicms.language()['min']+params;
						}
						break;
					case "max":
						if(parseFloat($value)>parseFloat(params))
						{
							return kuicms.language()['max']+params;
						}
						break;
					case "between":
						var $num=params.split(",");
						var $min=0;
						var $max=params;
						if($num.length==2)
						{
							$min=$num[0];
							$max=$num[1];
						}
						if(parseFloat($value)<parseFloat($min) || parseFloat($value)>parseFloat($max))
						{
							return $.format(kuicms.language()['between'],[$min,$max])
						}
						break;
					case "match":
						var old=$("#"+params);
						var oldval=old.val();
						var oldlabel=old.attr("data-rule").split(":")[0];
						if(oldval!=$value)
						{
							return $.format(kuicms.language()['match'],[label,oldlabel])
						}
						break;
					case "ajax":
						var result='';
						$.ajax(
						{
							type:"post",
							async:false,
							dataType:'json',
							url:params,
							data:'backval='+encodeURIComponent($value),
							error:function(e){alert(e.responseText);},
							success:function(d)
							{
								if(d.state=='error')
								{
									result=d.msg;
								}
							}
						});
						if(result!='')
						{
							return result;
						}
						break;
				}
			}
			return true;
		}
    };
    $(".form-submit").click(function()
	{
		var e=$(this);
		
		var type=e.attr("data-type") || 1;
		var hide=e.attr("data-hide") || 1;
		var show=e.attr("data-show") || 0;
		var align=e.attr("data-align");
		if(type==2)
		{
			show=0;
		}
		/*添加相关属性*/
		e.closest("form").attr("data-type",type);
		e.closest("form").attr("data-hide",hide);
		e.closest("form").attr("data-show",show);
		e.closest("form").attr("data-align",align);
		
		var total=1;
		e.closest("form").find(":input[data-rule]").each(function()
		{
			var result=$input($(this),type,hide,align);
			if(!result)
			{
				total=0;
				if(show==0)
				{
					$(this).first().focus().select();
					return false;
				}
			}
			else
			{
				total=total*1;
			}
		});
		if(total==0)
		{
			return false;
		}
    });
	
	$(".form-reset").click(function()
	{
        $(this).closest("form").find(".error-msg").remove();
        $(this).closest("form").find(".form-group").removeClass("check-error");
		$(this).closest("form")[0].reset();
    });
	
	/*星星评分*/
	$(".star").each(function()
	{
		var e=$(this);
		var num=e.attr("data-num") || 0;
		var maxnum=e.attr("data-max") || 5;
		var target=e.attr("data-target");
		var star_full=e.attr("data-full") || '★';
		var star_empty=e.attr("data-empty") || '☆';
		var setfull=function(num)
		{
			if(num>0)
			{
				e.find(".star-item").removeClass("star-full").html(star_empty);
				for(i=1;i<=num;i++)
				{
					e.find(".star-item").eq(i-1).addClass("star-full").html(star_full);
				}
			}
			if(target!=null && num>0)
			{
				$(target).val(num);
			} 
		};
		for(i=0;i<maxnum;i++)
		{
			e.append('<div class="star-item">'+star_empty+'</div>')
		}
		setfull(num);
		e.find(".star-item").hover(function(){
			$(this).addClass("star-active").prevAll().addClass("star-active");
		},function()
		{
			$(this).removeClass("star-active").prevAll().removeClass("star-active");
		});
		e.find(".star-item").click(function()
		{
			num=$(this).prevAll().length+1;
			setfull(num);
		})
	});
	
	/*数字回滚*/
	$(".rock").each(function()
	{
		var e=$(this);
		var num=(e.attr("data-to") || 100);
		var time=(e.attr("data-time") || 3000);
		var easing=(e.attr("data-easing") || 'swing');
		e.animate({num:"rock"},{duration:time,easing:easing,step:function(a,b){e.html(parseInt(b.pos*num));}});
	});
	
	/*选项卡*/
	$(".tabs-nav li").each(function()
	{
		var e=$(this);
		var type=e.closest(".tabs").attr("data-type");
		/*是否为链接*/
		var href=e.closest(".tabs").attr("data-href") || 0;
		if(href==1)
		{
			return;
		}
		if(type=='hover')
		{
			e.mouseover(function()
			{
				$tabs(e);
			});
		}
		else
		{
			e.click(function()
			{
				$tabs(e);
				return false;
			});
		}
	});
	$tabs=function(e)
	{
		$(e).addClass("active").siblings().removeClass("active");
		$(e).closest(".tabs").find(".tabs-pane").removeClass("active").eq($(e).index()).addClass("active");
	};
	
	/*模态窗口*/
	$(document).on("click",".modal-show",function()
	{
		var e=$(this);
		$modal(e,'show');
	});
	$modal=function(e,opentype)
	{
		var target=e.attr("data-target") || e;
		$mask=$('<div class="modal-mask"></div>');
		$body=$(target);
		if(target!=null && opentype=='show')
		{
			$("body").append($mask);
			$mask.fadeIn(function(){$(this).css("display","block")});
			var x=parseInt($(window).width()-$body.outerWidth())/2;
			var y=parseInt($(window).height()-$body.outerHeight())/2;
			if(!$body.hasClass("animated"))
			{
				y-=50;
			}
			$body.css({"left":x,"top":y,"display":"block"});
			if(!$body.hasClass("animated"))
			{
				$body.addClass("modal-in").fadeIn();
			}
		}
		var close=function()
		{
			/*$("body").parent().css("overflow","auto");*/
			$body.removeClass("modal-in").addClass("modal-out").fadeOut(function(){$(this).removeClass("modal-out").css("display","none");setTimeout(function(){$mask.fadeOut(function(){$(".modal-mask").remove()});},100);});
		};
		$body.find(".modal-close").click(function()
		{
            close();
        });
		$mask.click(function()
		{
			close();
        });
		if(opentype=='close')
		{
			close();
		}
	};

	/*轮播*/
	$(".carousel").each(function()
	{
		var e=$(this);
		var $li=e.find(".carousel-item");
		var time=(e.attr("data-time") || 5)*1000;
		var arrow=e.attr("data-arrow") || true;
		var way=e.attr("data-way") || 'default';
		var flash=e.attr("data-flash") || false;
		var page=e.attr("data-page") || false;
		var total=$li.length;
		//如果只有1条，则不轮播
		if(total<=1){return;}
		if(flash)
		{
			e.addClass("carousel-flash");
			e.append('<div class="carousel-control"><div class="carousel-title"></div></div>');
			var title=e.find(".carousel-item").eq(0).find("img").attr("data-title");
			if(title!=null)
			{
				e.find(".carousel-title").html(title);
			}
		}
		//初始索引值
		var index=0;
		var timer;
		
		function autoplay()
		{
			timer=setInterval(function(){play_next();},time);
		}	
		function play_prev()
		{
			index--;
			if(index<0){index=total-1;}
			$carousel(e,total,index,'prev',way,flash,page);
		}
		
		function play_next()
		{
			index++;
			if(index>=total){index=0;}
			$carousel(e,total,index,'next',way,flash,page);
		}
		
		
		/*鼠标移入移出*/
		e.on('mouseenter',function()
		{
			clearInterval(timer);
		}).on('mouseleave',function()
		{
			autoplay();
		});
		
		/*检查是否支持触屏*/
		var touchSupported='ontouchstart' in document.documentElement || navigator.maxTouchPoints > 0;	
		if(touchSupported)
		{
			var start=0;
			var end=0;
			e.on('touchstart',function(event)
			{
				clearInterval(timer);
				/*触摸开始时记录一下手指所在的坐标x*/
				start=event.originalEvent.touches[0].clientX;
			});
			e.on('touchmove',function(event)
			{
				clearInterval(timer);
				/*离开屏幕一瞬间的坐标x*/
				end=event.originalEvent.touches[0].clientX;
			});
			e.on('touchend',function(event) 
			{
				clearInterval(timer);
				allowClick=true;
				/*获取差值*/
				var distance=Math.abs(start-end);
				/*当差值大于30说明有方向的变化*/
				if(distance>30)
				{
					if(start>end)
					{
						play_next();
					}
					else
					{
						play_prev();
					}
				}
			});
		}
		
		/*如果开启了左右箭头*/
		if(arrow==true)
		{
			if(e.find(".carousel-prev").length==0)
			{
				e.append('<a class="carousel-prev" href="javascript:;"><span class="carousel-prev-icon"></span></a>');
			}
			var $prev=e.find(".carousel-prev");
			
			if(e.find(".carousel-next").length==0)
			{
				e.append('<a class="carousel-next" href="javascript:;"><span class="carousel-next-icon"></span></a>');
			}
			var $next=e.find(".carousel-next");
			$prev.click(function()
			{
				clearInterval(timer);
				play_prev();
			});
			$next.click(function()
			{
				clearInterval(timer);
				play_next();
			});
		}
		
		if(page==false)
		{
			/*指示器*/
			if(e.find(".carousel-page").length==0)
			{
				var html='';
				html+='<ul class="carousel-page">';
				html+='	<li data-num="0" class="active"></li>';
				for(i=1;i<total;i++)
				{
					html+='	<li data-num="'+i+'"></li>';
				}
				html+='</ul>';
				if(flash)
				{
					e.find(".carousel-control").append(html);
				}
				else
				{
					e.append(html);
				}
			}
		}
		else
		{
			var html='';
			html+='<div class="carousel-pagenum">1/'+total+'</div>';
			e.append(html);
		}
		e.find(".carousel-page li").click(function()
		{
			clearInterval(timer);
			var num=$(this).attr("data-num");
			//获取不到索引值，重新获取
			var index=e.find(".carousel-item.active").index();
			$carousel(e,total,num,(index>num)?'prev':'next',way,flash,page);
		});
		/*自动播放*/
		autoplay();
		if(flash==true)
		{
			var title=e.find(".carousel-item").eq(0).find("img").attr("data-title");
			if(title!=null)
			{
				e.find(".carousel-title").html(title);
			}
		}
	});
	$carousel=function(e,total,index,direction,way,flash,page)
	{
		if(way=='default')
		{
			var NEXT,LEFT
			if(direction=='next')
			{
				NEXT='next';
				LEFT='left';
			}
			else
			{
				NEXT='prev';
				LEFT='right';
			}
			var $active=e.find(".carousel-item.active");
			var activeIndex=$active.index();
			var delta=(direction=='prev')?-1:1;
			var itemIndex=(activeIndex+delta)%total;
			var $next=e.find(".carousel-item").eq(itemIndex);
		
			$next.addClass("carousel-item-"+NEXT);
			$next[0].offsetWidth;/*重要，缺少的话就无法实现效果*/
			$active.addClass("carousel-item-"+LEFT);
			$next.addClass("carousel-item-"+LEFT);
			$active.one('UiTransitionEnd',function()
			{
				$active.removeClass(['active',"carousel-item-"+LEFT].join(' '));
				$next.removeClass(["carousel-item-"+NEXT,"carousel-item-"+LEFT].join(' ')).addClass('active');
			});
		}
		else
		{
			e.find(".carousel-item").eq(index).fadeIn(function(){$(this).addClass("active");}).siblings().fadeOut(function(){$(this).removeClass("active")});
		}
		/*指示器*/
		e.find(".carousel-page li").eq(index).addClass("active").siblings().removeClass("active");
		
		if(page)
		{
			e.find(".carousel-pagenum").html((index+1)+'/'+total);
		}
		
		if(flash)
		{
			var title=e.find(".carousel-item").eq(index).find("img").attr("data-title");
			if(title!=null)
			{
				e.find(".carousel-title").html(title);
			}
		}
	};
	
	/*侧边栏*/
	$(document).on("click",".offside-show",function()
	{
		var e=$(this);
		$offside(e,'show');
	});
	$offside=function(e,opentype)
	{
		var target=e.attr("data-target") || e;
		var $push=e.attr("data-push") || false;
		$mask=$('<div class="offside-mask"></div>');
		$body=$(target);
		if(target!=null && opentype=='show')
		{
			var isleft=$body.hasClass("offside-left");
			$("body").append($mask).parent().css("overflow","hidden");
			$mask.fadeIn(function(){$(this).css("display","block")});
			var width=$body.outerWidth();
			var height=$body.outerHeight();
			if($body.hasClass("offside-left"))
			{
				$body.css({"left":0});
				if($push){$("body").animate({"marginLeft":width});}
			}
			if($body.hasClass("offside-right"))
			{
				$body.css({"right":0});
				if($push){$("body").animate({"marginRight":width});}
			}
			if($body.hasClass("offside-top"))
			{
				$body.css({"top":0});
				if($push){$("body").animate({"marginTop":height});}
			}
			if($body.hasClass("offside-bottom"))
			{
				$body.css({"bottom":0});
				/*无效的效果*/
				if($push){$("body").animate({"marginBottom":height});}
			}
			$body.addClass("offside-in");
		}
		var close=function()
		{
			$("body").parent().css("overflow","auto");
			var width=$body.outerWidth();
			var height=$body.outerHeight();
			$body.removeClass("offside-in");
			if($body.hasClass("offside-left"))
			{
				$body.css({"left":-width});
				if($push){$("body").animate({"marginLeft":0});}
			}
			if($body.hasClass("offside-right"))
			{
				$body.css({"right":-width});
				if($push){$("body").animate({"marginRight":0});}
			}
			if($body.hasClass("offside-top"))
			{
				$body.css({"top":-height});
				if($push){$("body").animate({"marginTop":0});}
			}
			if($body.hasClass("offside-bottom"))
			{
				$body.css({"bottom":-height});
				if($push){$("body").animate({"marginBottom":0});}
			}
			$mask.fadeOut(function(){$(this).remove()});
			setTimeout(function(){$(".offside-mask").remove();},100)
		};
		$body.find(".offside-close").click(function()
		{
            close();
        });
		$mask.click(function()
		{
			close();
        })
		if(opentype=='close')
		{
			close();
		}
	};
	
	/*下拉菜单*/
	$(".dropdown-show").each(function()
	{
		var e=$(this);
		e.click(function(event)
		{
			event.stopPropagation();
			$dropdown(e);
		});
	});
	$dropdown=function(e)
	{
		var align=e.attr("data-align");
		var target=e.attr("data-target");
		$html=$(target)
		switch(align)
		{
			case "left":
			case "top":
			case "right":
			case "bottom":
			case "bottom-left":
			case "top-left":
			case "right-top":
				break;
			default:
				align="bottom-left";
				break;
		}
		var classname="dropdown-"+align;
		if(target!=null)
		{
			if($html.css("display")=='none')
			{
				var x=0;
				var y=0;
				switch(align)
				{
					case "left":
						x=e.offset().left-$html.outerWidth()-10;
						y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
						break;
					case "top":
						x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
						y=e.offset().top-$html.outerHeight()-10;
						break;
					case "right":
						x=e.offset().left+e.outerWidth()+10;
						y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
						break;
					case "bottom":
						x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
						y=e.offset().top+e.outerHeight()+10;
						break;
					case "top-left":
						x=e.offset().left;
						y=e.offset().top-$html.outerHeight()-10;
						break;
					case "bottom-left":
						x=e.offset().left;
						y=e.offset().top+e.outerHeight()+10;
						break;
					case "right-top":
						x=e.offset().left+e.outerWidth()+10;
						y=e.offset().top;
						break;
				}
				$html.addClass(classname).css({"left":x+"px","top":y+"px","position":"absolute","display":"block"});
			}
			else
			{



				$html.removeClass(classname).css({"display":"none"});
			}
		}
	};
	/*空白处点击*/
	$(document).click(function(event)
	{
		var $html=$('.dropdown');
		if($html)
		{
			if(!$html.is(event.target) && $html.has(event.target).length===0)
			{
				var classname=$html.attr("class");
				if(classname!=null)
				{
					var data=classname.split(" ");
					for(var i=0;i<data.length;i++)
					{
						if(data[i]!=="dropdown")
						{
							$html.removeClass(data[i]);
						}
					}
				}
				$html.css({"display":"none"});
			}
		}
	});
	
	/*提示*/
	$(".tips").each(function()
	{
		var e=$(this);
		var type=e.attr("data-type");
		if(type=="" || type==null)
		{
            type="hover"
        }
		if(type=='hover')
		{
			e.mouseover(function()
			{
				$tips(e);
			});
		}
		else
		{
			e.click(function()
			{
				$tips(e);
			});
		}
	});
	$tips=function(e)
	{
		var align=e.attr("data-align");
		var title=e.attr("title") || e.attr("data-title") || '';
		var pic=e.attr("data-pic");
		var width=e.attr("data-width");
		var x=0;
		var y=0;
		switch(align)
		{
			case "top":
			case "right":
			case "bottom":
			case "bottom-left":
			case "top-left":
			case "right-top":
				break;
			default:
				align="left";
				break;
		}
		var str=title;
		if(pic!=null)
		{
			str='<img src="'+pic+'"><div class="tips-title">'+title+'</div>';
		}
		var html='<div class="tips-show">'+str+'</div>';
		$html=$(html)
		$("body").append($html);
		if(width!=null)
		{
			$html.css({"width":width})
		}
		switch(align)
		{
			case "left":
				x=e.offset().left-$html.outerWidth()-10;
				y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
				break;
			case "top":
				x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
                y=e.offset().top-$html.outerHeight()-10;
				break;
			case "right":
				x=e.offset().left+e.outerWidth()+10;
                y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
				break;
			case "bottom":
				x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
                y=e.offset().top+e.outerHeight()+10;
				break;
			case "top-left":
				x=e.offset().left;
                y=e.offset().top-$html.outerHeight()-10;
				break;
			case "bottom-left":
				x=e.offset().left;
                y=e.offset().top+e.outerHeight()+10;
				break;
			case "right-top":
				x=e.offset().left+e.outerWidth()+10;
                y=e.offset().top;
				break;
		}
		var classname="tips-"+align;
		$html.addClass(classname);
		$html.css({"left":x+"px","top":y+"px","position":"absolute"});
		e.mouseout(function()
		{
			$html.remove();
		});
	};
	
	/*导航*/
	$(".nav ul li").each(function()
	{
		var e=$(this)
		var ishave=0;

		if(e.hasClass("active"))
		{
			ishave=1;
		}
		e.hover(function()
		{
			if(ishave==0)
			{
				$(this).addClass("active");
			}
		},function()
		{
			if(ishave==0)
			{
				$(this).removeClass("active");
			}
		});
	});

	/*折叠面板*/
	$(".collapse .card-header").each(function()
	{
		var e=$(this);
		var type=e.closest(".collapse").attr("data-type");
		if(type=='hover')
		{
			e.mouseover(function()
			{
				$collapse(e,'hover');
			});
		}
		else
		{
			e.click(function()
			{
				$collapse(e,'click');
			});
		}
	});
	$collapse=function(e,type)
	{
		if(!e.closest(".card").children(".card-header").hasClass("active") || type=='hover')
		{
			e.closest(".card").siblings().children(".card-header").removeClass("active");
			e.closest(".card").children(".card-header").addClass("active");
			e.closest(".card").siblings().children(".card-body").slideUp(300,function(){$(this).addClass("hide")});
			e.closest(".card").children(".card-body").slideDown(300,function(){$(this).removeClass("hide")});
		}
		else
		{
			e.closest(".card").children(".card-header").removeClass("active");
			e.closest(".card").children(".card-body").slideUp(300,function(){$(this).addClass("hide")});
		}
	};
	
	/*折叠菜单*/
	$(".collapse .collapse-menu").each(function()
	{
		var e=$(this);
		var type=e.closest(".collapse").attr("data-type");
		if(type=='hover')
		{
			e.mouseover(function()
			{
				$collapse_menu(e,'hover');
			});
		}
		else
		{
			if(e.hasClass("hasson"))
			{
				e.click(function()
				{
					$collapse_menu(e,'click');
				});
			}
		}
	});
	$collapse_menu=function(e,type)
	{
		if(!e.hasClass("active") || type=='hover')
		{
			e.siblings().removeClass("active");
			e.addClass("active");
			e.siblings().children(".collapse-body").slideUp(300,function(){$(this).addClass("hide")});
			e.children(".collapse-body").slideDown(300,function(){$(this).removeClass("hide")});
		}
		else
		{
			e.removeClass("active");
			e.children(".collapse-body").slideUp(300,function(){$(this).addClass("hide")});
		}
	};
		
	/*Fixed*/
	$(".fixed").each(function()
	{
        var e=$(this);
		var width=e.outerWidth();
        var align=e.attr("data-align") || "fixed-top";
		var classname=e.attr("data-hover") || "";
        var top=e.attr("data-offset");
		top=(top==null) ? (e.offset().top) : (e.offset().top-parseInt(top));
        $(window).bind("scroll",function()
		{
            var thistop=top-$(window).scrollTop();
			if(align=="fixed-top")
			{
                if(thistop<0)
				{
					e.addClass("fixed-top").css({"width":width,"left":"auto","right":"auto"});
					e.addClass(classname)
				}
				else
				{
					e.removeClass("fixed-top");
					e.removeClass(classname)
				}
            }
            
			if(e.hasClass("topbar-opacity"))
			{
				if($(window).scrollTop() > 10)
				{
					e.addClass("topbar-show");
					e.css({"position":"fixed"});
				}
				else
				{
					e.removeClass("topbar-show");
					e.css({"position":"relative"});
				}
			}
            var thisbottom=top-$(window).scrollTop()-$(window).height();
			if(align=="fixed-bottom")
			{
				if(thisbottom>0)
				{
					e.addClass("fixed-bottom").css({"width":width,"left":"auto","right":"auto"});
					e.addClass(classname)
				}
				else
				{
					e.removeClass("fixed-bottom");
					e.removeClass(classname)
				}
			}
            
        });
    });
	$(".fixed-top").each(function()
	{
		var e=$(this);
		var height=e.outerHeight();
		var old=e.prop("outerHTML");
		var cname=e.attr("data-class") || '';
		var html='<div class="fixed-warp '+cname+'" style="height:'+(height)+'px">'+old+'</div>';
		e.prop("outerHTML",html);
	});
	
	$(".fixed-bottom").each(function()
	{
		var e=$(this);
		var height=e.outerHeight();
		var old=e.prop("outerHTML");
		var cname=e.attr("data-class") || '';
		var html='<div class="fixed-warp '+cname+'" style="height:'+(height)+'px">'+old+'</div>';
		e.prop("outerHTML",html);
	});
	
	/*步骤条*/
	$(".step").each(function()
	{
		var total=$(this).find(".step-item").length;
		var num=$(this).find(".step-item.active").length;
		$(this).parent().find(".step-progress").animate({"width":(num/total)*100+"%"})
	});
	
	/*滚动*/
	$(".scroll").each(function()
	{
		var e=$(this);
		var $ul=e.attr("data-ul") || 'ul';
		var $li=e.attr("data-li") || 'li';
		var $speed=e.attr("data-speed") || 1000;
		var $line=e.attr("data-line") || 1;
		var $max=e.attr("data-max") || 1;
		var $time=e.attr("data-time") || 3;
		var $align=e.attr("data-align") || 'up';
		var $width=e.attr("data-width") || '';
		var $height=e.attr("data-height") || '';
		var $list=e.find($ul);
		var $Lwidth=$list.find($li+":first").outerWidth(true);
		var $Lheight=$list.find($li+":first").outerHeight(true);
		var lineH=$Lheight;
		var upHeight=0-$line*lineH;
		var lineW=$Lwidth;
		var upWidth=0-$line*lineW;
		if(e.find($li).length<=$line)
		{
			return;
		}
		if($align=='up')
		{
			if($height=='')
			{
				$height=$line*$Lheight;
			}
			e.css({"height":$height});
			var scrollUp=function()
			{
				$list.animate({marginTop:upHeight},$speed,function()
				{
					for(var i=0;i<$line;i++)
					{
						$list.find($li+":first").appendTo($list);
					}
					$list.css({marginTop:0});
				});
			}

			window.setInterval(scrollUp,$time*1000);
		}
		else
		{
			if($width=='')
			{
				$width=$max*$Lwidth;
			}
			if($height=='')
			{
				$height=$Lheight;
			}
			e.css({"width":$width,"height":$height});
			var scrollLeft=function()
			{
				$list.animate({marginLeft:upWidth},$speed,function()
				{
					for(var i=0;i<$line;i++)
					{
						$list.find($li+":first").appendTo($list);
					}
					$list.css({marginLeft:0});
				});
			}
			window.setInterval(scrollLeft,$time*1000);
		}
	});
	
	/*灯箱*/
	$(document).on("click",".lightbox",function(event)
	{
		/*阻止点击事件*/
		event.preventDefault();
		var e=$(this);
		var data=[];
		var step=0;
		$lightbox(e,data,step);
	});
	$lightbox=function(e,data,step)
	{
		
		var fname=e.attr("data-name") || 'ui-lightbox';
		var ftitle=(e.attr("data-title") || e.attr("title")) || '';
		var fmode=e.attr("data-mode") || 'image';
		var fwidth=e.attr("data-width") || '650';
		var fheight=e.attr("data-height") || '450';
		var id=e.attr("data-id");
		var fpic=$("#"+id).val() || e.attr("href");
		if(fpic==null)
		{
			kuicms.warn("没有找到图片");
			return false;
		}
		
		/*遍历寻找相同的name*/
		var realWidth=0;
        var realHeight=0;
		var width=$(window).width()*80/100;
		var height=$(window).height()*80/100;
		
		var j=0;
		$(".lightbox").each(function(i)
		{
			var l=$(this);
			var name=l.attr("data-name") || 'ui-lightbox';
			if(name==null)
			{
				name='lightbox';
			}
			if(l.attr("data-mode")=='video')
			{
				name='lightbox-video';
			}
			var title=(l.attr("data-title") || l.attr("title")) || '';
			var pic=l.attr("href");
			if(name==fname)
			{
				var arr=[];
				arr['title']=title;
				arr['pic']=pic;
				if(fmode=='image')
				{
					$("<img>").attr("src",pic).load(function()
					{
						realWidth=this.width;
						realHeight=this.height;
						if(realWidth>width || realHeight>height)
						{
							var ww=realWidth/width;
							var hh=realHeight/height;
							if(ww>hh)
							{
								realWidth=width;
								realHeight=parseInt(realHeight/ww);
							}
							else
							{
								realHeight=height;
								realWidth=parseInt(realWidth/hh);
							}
						}
						arr['w']=realWidth;
						arr['h']=realHeight;
					})
				}
				else
				{
					arr['w']=fwidth;
					arr['h']=fheight;
				}
				data.push([arr]);
				if(ftitle==title && fpic==pic)
				{
					step=j;
				}
				j++;
			}
		});
		var total=data.length;
		var $mask=$('<div class="lightbox-mask"></div>');
		if(total>=0)
		{
			$("body").append($mask);
			$mask.fadeIn(function(){$(this).css("display","block")});
			if(fmode=='image')
			{
				if(total==1)
				{
					$warp=$('<div class="lightbox-warp"><div class="lightbox-image"><img src="'+fpic+'" class="lightbox-image-url" /><div class="lightbox-bottom"><i class="lightbox-num">'+(step+1)+'/'+total+'</i><div class="lightbox-text text-hide">'+ftitle+'</div></div></div><div class="lightbox-close rotate">×</div></div>');
				}
				else
				{
					$warp=$('<div class="lightbox-warp"><div class="lightbox-image"><img src="'+fpic+'" class="lightbox-image-url" /><div class="lightbox-left"></div><div class="lightbox-right"></div><div class="lightbox-bottom"><i class="lightbox-num">'+(step+1)+'/'+total+'</i><div class="lightbox-text text-hide">'+ftitle+'</div></div></div><div class="lightbox-close rotate">×</div></div>');
				}
			}
			else
			{
				$warp=$('<div class="lightbox-warp"><div class="lightbox-video"><video src="'+fpic+'" class="lightbox-image-url" controls /></video></div><div class="lightbox-close rotate">×</div></div>');
			}
		
			$("body").append($warp);
			var lefter=$warp.find(".lightbox-left");
			var righter=$warp.find(".lightbox-right");
			var num=0;
			var isclick=0;
			if(isclick==0)
			{
				if(fmode=='image')
				{
					$("<img>").attr("src",fpic).load(function()
					{
						realWidth=this.width;
						realHeight=this.height;
						if(realWidth>width || realHeight>height)
						{
							var ww=realWidth/width;
							var hh=realHeight/height;
							if(ww>hh)
							{
								realWidth=width;
								realHeight=parseInt(realHeight/ww);
							}
							else
							{
								realHeight=height;
								realWidth=parseInt(realWidth/hh);
							}
						}
						$warp.find(".lightbox-image-url").animate({"width":realWidth,"height":realHeight},800);
						var x=($(window).width()/2)-(realWidth/2)-5;
						var y=(($(window).height()-realHeight)/2)-5;
						$warp.animate({"left":x,"top":y});
						$warp.find(".lightbox-bottom").animate({"width":"100%","height":"40px"},1000);	
					});
				}
				else
				{
					$warp.find(".lightbox-image-url").animate({"width":fwidth,"height":fheight},800);
					var x=($(window).width()/2)-(fwidth/2)-5;
					var y=(($(window).height()-fheight)/2)-5;
					$warp.animate({"left":x,"top":y});
				}
			}
			if(step>0)
			{
				num=step;
			}
			lefter.click(function()
			{
				num--;
				if(num<=-1)
				{
					num=total-1;
				}
				var url=data[num][0].pic;
				var text=data[num][0].title;
				var widths=data[num][0].w;
				var heights=data[num][0].h;
				$warp.find(".lightbox-image-url").attr("src",url).animate({"width":widths,"height":heights},800);
				$warp.find(".lightbox-text").html(text);
				$warp.find(".lightbox-num").html((num+1)+'/'+total);
				var x=($(window).width()/2)-(widths/2)-5;
				var y=($(window).height()/2)-(heights/2)-5;
				$warp.animate({"left":x,"top":y})
				isclick=1;
			});
			righter.click(function()
			{
				num++;
				if(num>=total)
				{
					num=0;
				}
				var url=data[num][0].pic;
				var text=data[num][0].title;
				var widths=data[num][0].w;
				var heights=data[num][0].h;
				$warp.find(".lightbox-image-url").attr("src",url).animate({"width":widths,"height":heights},800);
				$warp.find(".lightbox-text").html(text);
				$warp.find(".lightbox-num").html((num+1)+'/'+total);
				if(widths<100 || heights<100)
				{
					$warp.find(".lightbox-bottom").css({"display":"none"});
				}
				else
				{
					$warp.find(".lightbox-bottom").css({"display":"block"});
				}
				var x=($(window).width()/2)-(widths/2)-5;
				var y=($(window).height()/2)-(heights/2)-5;
				$warp.animate({"left":x,"top":y})
				isclick=1;
			});
			var close=function()
			{
				$("body").parent().css("overflow","auto");$warp.fadeOut(function(){$(this).remove()});setTimeout(function(){$mask.fadeOut(function(){$(this).remove();});},300);
			};
			$mask.click(function(){if(fmode=='image'){close();}});
			$warp.find(".lightbox-close").click(function(){close();});
		}
	};
	/*滚动动画*/
	$scrollspy=function(e)
	{
		var am=e.attr("data-am") || 'ui-am-fade';
		var loop=e.attr("data-loop") || false;
		var time=e.attr("data-time") || 0;
		var top=e.offset().top;
		var thistop=top-$(window).scrollTop();
		if(thistop<$(window).height())
		{
			if(parseInt(time)==0)
			{
				e.addClass(am);
			}
			else
			{
				setTimeout(function(){e.addClass(am);},time)
			}
		}
		else
		{
			if(loop)
			{
				if(parseInt(time)==0)
				{
					e.addClass(am);
				}
				else
				{
					setTimeout(function(){e.removeClass(am);},time)
				}
			}
		}
	};
	$(".scrollspy").each(function()
	{
		$scrollspy($(this));
	});
	
	/*滚动导航*/
	$(".scrollnav a").each(function()
	{
		var e=$(this);
		var t=e.closest(".scrollnav");
		var target=t.attr("data-target") || window;
		var top=t.attr("data-offset") || 0;
		$(target).bind("scroll",function()
		{
			var thistop=$(e.attr("href")).offset().top - $(window).scrollTop() - parseInt(top);
			if(thistop<0)
			{
				t.find('li').removeClass("active");
				e.parents('li').addClass("active");
			};
		});
	});
	
	$(window).scroll(function()
	{
		$(".scrollspy").each(function()
		{
			$scrollspy($(this));
		});
	});

	
	/*Extend*/
	var tipsid=0;
	var toastid=0;
	var dialogid=0;
	$.extend(
	{
		/*占位符*/
		format:function(result,data)
		{
			if(data.length==0)
			{
				return result;
			}
			var i=data.length+1;
			while(--i)
			{
				result=result.replace('{'+i+'}',data[i-1]);
			}
			return result;
		},
		tips:function(opt)
		{
			var defaults={
				'text': '',
				'id': '',
				'align': 'top',
				'time':5,
				'name':'',
				'color':''
			};
			var config=$.extend({},defaults,opt);
			var e=$(config.id);
			var x=0;
			var y=0;
			tipsid++;
			var name=tipsid;
			if(config.name!='')
			{
				name=config.name;
			}
			var color='';
			if(config.color!=null)
			{
				color=' tips-'+config.color;
			}
			var html='<div class="tips-show'+color+'" id="tips_'+name+'">'+config.text+'</div>';
			$html=$(html);
			$("body").append($html);
			switch(config.align)
			{
				case "left":
					x=e.offset().left-$html.outerWidth()-10;
					y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
					break;
				case "top":
					x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
					y=e.offset().top-$html.outerHeight()-10;
					break;
				case "right":
					x=e.offset().left+e.outerWidth()+10;
					y=e.offset().top-$html.outerHeight()/2+e.outerHeight()/2;
					break;
				case "bottom":
					x=e.offset().left-$html.outerWidth()/2+e.outerWidth()/2;
					y=e.offset().top+e.outerHeight()+10;
					break;
				case "top-left":
					x=e.offset().left;
					y=e.offset().top-$html.outerHeight()-10;
					break;
				case "bottom-left":
					x=e.offset().left;
					y=e.offset().top+e.outerHeight()+10;
					break;
				case "right-top":
					x=e.offset().left+e.outerWidth()+10;
					y=e.offset().top;
					break;
			}
			var classname="tips-"+config.align;
			$html.addClass(classname);
			$html.css({"left":x+"px","top":y+"px","position":"absolute"});
			var $tipsid=$("#tips_"+name);
			if(config.time>0)
			{
				setTimeout(function(){$tipsid.remove();},config.time*1000);
			}
		},
		toast:function(opt)
		{
			var defaults={
				'title':'',
				'text':'',
				'align':'center',
				'subject':false,
				'color':'',
				'icon':'',
				'progress':'true',
				'time':5,
				'type':0,
			};
			toastid++;
			var config=$.extend({},defaults,opt);
			var html='';
			if(config.type==1)
			{
				toastid='loading'
			}
			html+='<div class="toast ui-toast" id="toast_'+toastid+'">';
			if(config.subject||config.title!='')
			{
				html+='<div class="toast-header">';
				html+='<div class="toast-title">'+config.title+'</div>';
				html+='<div class="toast-close rotate">×</div>';          
				html+='</div>';
			}
			var icon='';
			var icon_progress='';
			switch(config.icon)
			{
				case "success":
					icon='<span class="ui-icon-check-circle success"></span>';
					icon_progress=' progress-success';
					break;
				case "error":
					icon='<span class="ui-icon-close-circle error"></span>';
					icon_progress=' progress-error';
					break;
				case "warn":
					icon='<span class="ui-icon-warning-circle warn"></span>';
					icon_progress=' progress-warn';
					break;
				case "reload":
					icon='<span class="ui-loading"></span>';
					icon_progress=' progress-loading';
					break;
			}
			html+='<div class="toast-body">'+icon+config.text+'</div>';
			
			if(config.progress=='true'&&config.time>0)
			{
				html+='<div class="toast-footer">';
				html+='<div class="progress progress-lt progress-toast"><div class="progress-bar'+icon_progress+'" style="width:100%" id="progress-bar-'+toastid+'"></div></div>';
				html+='</div>';
			}
			if(config.type==1)
			{
				html+='<div class="toast-footer">';
				html+='<div class="progress progress-lt progress-toast-loading"><div class="progress-bar'+icon_progress+'" style="width:0%"></div></div>';
				html+='</div>';
			}
			html+='</div>';
			$html=$(html);
			if(config.align=='center')
			{
				$(".toast").remove();
			}
			var warp='<div class="toast-warp toast-warp-'+config.align+'"></div>';
			$warp=$(warp);
			
			if($(".toast-warp-"+config.align).length==0&&config.align!='center')
			{
				$("body").append($warp);
			}
			if(config.align!='center')
			{
				$(".toast-warp-"+config.align).prepend($html);
			}
			if(config.color!='')
			{
				$html.addClass('toast-'+config.color);
			}
			if(config.align=='center')
			{
				$("body").append($html);
			}
			var total=$(".toast").length;
			var x=$(window).width()/2 -($html.outerWidth()/2);
			var y=$(window).height()/2 -($html.outerHeight()/2);
			if(config.align=='center')
			{
				$html.css({"top":y,"left":x,"position":"fixed","margin":"0 auto"});
			}
			var oldw=$html.outerWidth();
			var oldh=$html.outerHeight();
			$html.css({"width":0,"height":0});
			$html.animate({"width":oldw,"height":oldh});
			var $toast=$("#toast_"+toastid);
			if(config.time>0)
			{
				setTimeout(function(){$toast.slideUp(function(){$(this).remove()});},config.time*1000);
				if(config.progress=='true')
				{
					var step=100;
					function backprogress(id,num)
					{
						if(step>=0)
						{
							var p=100/num/10/2;
							$("#"+id).css({"width":step+"%"});
							step=step-p;
							setTimeout(function(){backprogress(id,num);},50); 
						}
					}
					backprogress("progress-bar-"+toastid,config.time);
				}
			}
			$toast.find(".toast-close").click(function()
			{
				$toast.slideUp(function(){$(this).remove()});
			})
		},
		toastclose:function()
		{
			$(".ui-toast").remove();
		},
		dialog:function(opt)
		{
			var that=this;
			var defaults=
			{
				'title':'',
				'text':'',
				'align':'center',
				'time':0,
				'ok':null,
				'okval':kuicms.language()['ok'],
				'oktheme':'btn-blue',
				'cancel':null,
				'cancelval':kuicms.language()['cancel'],
				'width':'',
				'height':'',
				'inputval':'',
				'inputholder':'',
				'type':0,/*0：文字，1：单行文本框，2：多行文本框，3：框架，4：图片*/
				'footer':true,
				'mask':true,
				'ismobile':0
			};
			/*关闭所有提示*/
			$.toastclose();
			
			dialogid++;
			var config=$.extend({},defaults,opt);
			$mask=$(".dialog-mask");
			if(config.mask)
			{
				if($(".dialog-mask").length==0)
				{
					$mask=$('<div class="dialog-mask"></div>');
					$("body").append($mask);
					$mask.fadeIn(function(){$(this).css("display","block")});
				}
				else
				{
					$mask=$(".dialog-mask");
				}
			}
			
			var html='';
			if(config.ismobile==0)
			{

				html+='<div class="dialog ui-dialog" id="dialog_'+dialogid+'">';
			}
			else
			{
				html+='<div class="dialog dialog-mobile ui-dialog" id="dialog_'+dialogid+'">';
			}
			
			if(config.subject||config.title!='')
			{
				html+='<div class="dialog-header">';
				html+='<div class="dialog-title">'+config.title+'</div>';
				html+='<div class="dialog-close rotate">×</div>';          
				html+='</div>';
			}
			var $dialogbody='';
			var dialogpadding='';
			switch(config.type)
			{
				case 1:
					$dialogbody='<input type="text" class="dialog-text form-ip" placeholder="'+config.inputholder+'" value="'+config.inputval+'">';
					break;
				case 2:
					$dialogbody=''+config.text+'<textarea rows="8" class="dialog-text form-ip">'+config.inputval+'</textarea>';
					break;
				case 3:
					$dialogbody='<iframe src="'+config.text+'" id="ui-dialog-iframe" frameborder="0" scrolling="auto" marginwidth="0" marginheight="0" allowtransparency="true"></></iframe>';
					dialogpadding=' dialog-body-iframe';
					break;
				default:
					$dialogbody=config.text;
					break;
			}
			html+='<div class="dialog-body'+dialogpadding+'">'+$dialogbody+'</div>';
			if(config.footer)
			{
				if(config.ismobile==0)
				{
					html+='<div class="dialog-footer"><button class="btn '+config.oktheme+' dialog-ok mr">'+config.okval+'</button><button class="btn dialog-cancel">'+config.cancelval+'</button></div>';
				}
				else
				{
					html+='<div class="dialog-footer-mobile"><button class="dialog-cancel">'+config.cancelval+'</button><button class="dialog-ok">'+config.okval+'</button></div>';
				}
			}
			html+='</div>';
			$dialog=$(html);
			$("body").append($dialog);
			if(config.width!=null)
			{
				$dialog.css({"width":config.width});
			}
			if(config.height!=null)
			{
				if(config.type==3)
				{
					if(config.height.indexOf("%")>=0)
					{
						var h=config.height.replace("%","");
						config.height=$(window).height()*h/100;
					}
					$dialog.find("#ui-dialog-iframe").css({"height":config.height});
					$dialog.find(".dialog-footer").css({"border-width":"1px"});
				}
				else
				{
					$dialog.css({"height":config.height});
				}
			}
			var x=0;
			var y=0;
			switch(config.align)
			{
				case "top-left":
					$dialog.css({"top":"-40px","left":"10px","position":"fixed"});
					break;
				case "top-right":
					$dialog.css({"top":"-40px","right":"10px","position":"fixed"});
					break;
				case "bottom-left":
					$dialog.css({"bottom":"60px","left":"10px","position":"fixed"});
					break;
				case "bottom-right":
					$dialog.css({"bottom":"60px","right":"10px","position":"fixed"});
					break;
				default:
					x=($(window).width()-$dialog.outerWidth())/2;
					y=($(window).height()-$dialog.outerHeight())/2-50;
					$dialog.css({"top":y,"left":x,"position":"fixed"});
					break;
			}
			
			$dialog.addClass("dialog-in").fadeIn();
			that.close=function()
			{
				$dialog.removeClass("dialog-in").addClass("dialog-out").fadeOut(100,function()
				{
					$dialog.removeClass("dialog-out").css("display","none");
					$dialog.remove();
				});
				if(config.mask)
				{
					$mask.fadeOut(50,function(){$(this).remove()});
				}
			};
			that.inputval=function()
			{
				return $dialog.find(".dialog-text").val();
			};
			that.iframe=function()
			{
				return $dialog.find("iframe");
			};
			$dialog.find(".dialog-close").click(function()
			{
				that.close();
			});
			$dialog.find(".dialog-cancel").click(function()
			{
				if(typeof config.cancel=="function")
				{
					config.cancel(that);
				}
				else
				{
					that.close();
				}
			});
			$dialog.find(".dialog-ok").click(function()
			{
				if(typeof config.ok=="function")
				{
					config.ok(that);
				}
			});
			if(config.time>0)
			{
				setTimeout(function(){that.close();},config.time*1000)
			};
		},
		dialogclose:function()
		{
			$mask=$('.dialog-mask');
			$dialog=$('.ui-dialog');

			$dialog.fadeOut(function(){$(this).remove()});
			$mask.fadeOut(function(){$(this).remove()});
		},
		dialogbox:function(opt)
		{
			$.dialog(
			{
				'title':opt.title,
				'text':opt.text,
				'align':(opt.align || 'center'),
				'time':opt.time,
				'ok':opt.ok,
				'okval':opt.okval,
				'oktheme':opt.oktheme,
				'cancel':opt.cancel,
				'cancelval':opt.cancelval,
				'width':opt.width,
				'height':opt.height,
				'inputval':opt.inputval,
				'inputholder':opt.inputholder,
				'type':(opt.type || 1),
				'footer':opt.footer,
				'mask':opt.mask,
				'ismobile':opt.ismobile
			});
		},
		success:function(opt)
		{
			$.toast(
			{
				'title':opt.title,
				'text':opt.text,
				'icon':'success',
				'align':opt.align,
				'color':opt.color,
				'progress':opt.progress,
				'time':opt.time || 3
			});
		},
		error:function(opt)
		{
			$.toast(
			{
				'title':opt.title,
				'text':opt.text,
				'icon':'error',
				'align':opt.align,
				'color':opt.color,
				'progress':opt.progress,
				'time':opt.time || 3
			});
		},
		warn:function(opt)
		{
			$.toast(
			{
				'title':opt.title,
				'text':opt.text,
				'icon':'warn',
				'align':opt.align,
				'color':opt.color,
				'progress':opt.progress,
				'time':opt.time || 3
			});
		},
		loading:function(opt)
		{
			$.toast(
			{
				'title':opt.title,
				'text':opt.text,
				'icon':'reload',
				'align':opt.align,
				'color':opt.color,
				'progress':opt.progress,
				'time':0,
				'type':1
			});
		},
		progress:function(opt)
		{
			if(opt=='close')
			{
				$("#toast_loading").slideUp(function(){$(this).remove()});
			}
			else
			{
				$(".progress-toast-loading .progress-bar").css({"width":opt})
			}
		},
	});
	
	/*表单验证*/

	$.fn.form=function(opt)
	{
		var defaults={
			'type':1,
			'hide':1,
			'show':0,
			'align':null,
			'result':function(){},
		};
		
		var config=$.extend({},defaults,opt);
		if(config.type==2)
		{
			config.show=0;
		}
		var e=$(this);
		/*添加相关属性*/
		e.attr("data-type",config.type);
		e.attr("data-hide",config.hide);
		e.attr("data-show",config.show);
		e.attr("data-align",config.align);
		$(e).submit(function()
		{
			var total=1;
			e.find(":input[data-rule]").each(function()
			{
				var result=$input($(this),config.type,config.hide,config.align);
				if(!result)
				{
					total=0;
					if(config.show==0)
					{
						$(this).first().focus().select();
						return false;
					}
				}
				else
				{
					total=total*1;
				}
			})
			if(total==1)
			{
				if(config.result&& typeof config.result=="function")
				{
					config.result(e);
				}
			}
			return false;
		}); 
    };
	$.fn.inputnumber=function(opt)
	{
		var defaults={
			'minval':1,
			'maxval':9999,
			'step':1,
			'value':1,
			'align':'right',
			'disabled':0
		};
		var config=$.extend({},defaults,opt);
		this.each(function()
		{
			var e=$(this);
			var $min=config.minval;
			var $max=config.maxval;
			var $step=config.step;
			var $align=config.align;
			var $disabled=config.disabled;
			if(e.attr("data-min")!=null)
			{
				$min=e.attr("data-min");
			}
			if(e.attr("data-max")!=null)
			{
				$max=e.attr("data-max");
			}
			if(e.attr("data-step")!=null)
			{
				$step=e.attr("data-step");
			}
			if(e.attr("data-align")!=null)
			{
				$align=e.attr("data-align");
			}
			if(e.attr("data-disabled")!=null)
			{
				$disabled=e.attr("data-disabled");
			}
			function changenum(d,e)
			{
				var value=Number($val)*10;
				var _val;
				if(d=='-')
				{
					_val=(value-parseFloat($step)*10)/10;
				}
				else
				{
					_val=(value+parseFloat($step)*10)/10;
				}
				if( _val<$min)
				{
					_val=$min;
				}
				if(_val>$max)
				{
					_val=$max;
				}
				$val=_val;
				if(parseFloat($val)<=parseFloat($min))
				{
					e.closest(".inputnumber-wrap").find(".inputnumber-min").addClass("inputnumber-disabled");
				}
				else
				{
					e.closest(".inputnumber-wrap").find(".inputnumber-min").removeClass("inputnumber-disabled");
				}
				if(parseFloat($val)>=parseFloat($max))
				{
					e.closest(".inputnumber-wrap").find(".inputnumber-max").addClass("inputnumber-disabled");
				}
				else
				{
					e.closest(".inputnumber-wrap").find(".inputnumber-max").removeClass("inputnumber-disabled");
				}
				e.val($val);
				e.closest(".inputnumber-wrap").find(".inputnumber-text").html($val);
			}
			var $val=e.val();
			e.attr("readonly",true).css({"width":0,"border":0,"margin-left":"-2px"})
			e.wrap('<div class="inputnumber-wrap inputnumber-'+$align+'"></div>');
			if($align=='right')
			{
				e.closest(".inputnumber-wrap").append('<span class="inputnumber-text">'+$val+'</span><span class="inputnumber-min"><i class="ui-icon-line"></i></span><span class="inputnumber-max"><i class="ui-icon-plus"></i></span>');
			}
			else
			{
				e.closest(".inputnumber-wrap").append('<span class="inputnumber-min"><i class="ui-icon-line"></i></span><span class="inputnumber-text">'+$val+'</span><span class="inputnumber-max"><i class="ui-icon-plus"></i></span>');
			}
			if(parseFloat($val)<=parseFloat($min))
			{
				e.closest(".inputnumber-wrap").find(".inputnumber-min").addClass("inputnumber-disabled");
			}
			if(parseFloat($val)>=parseFloat($max))
			{
				e.closest(".inputnumber-wrap").find(".inputnumber-max").addClass("inputnumber-disabled");
			}
			if($disabled==1)
			{
				e.closest(".inputnumber-wrap").addClass("disabled");
			}
			else
			{
				e.closest(".inputnumber-wrap").find(".inputnumber-min").click(function()
				{
					if(!$(this).hasClass("inputnumber-disabled"))
					{
						changenum('-',e);
					}
				})
				e.closest(".inputnumber-wrap").find(".inputnumber-max").click(function()
				{
					if(!$(this).hasClass("inputnumber-disabled"))
					{
						changenum('+',e);
					}
				})
			}
		})
		return this;
	};
	$.fn.step=function(opt)
	{
		var e=this;
		var defaults={
			'data':[],
			'theme':'blue',
			'align':'top',
			'index':1,
			'arrow':false,
			'time':500,
		};
		var config=$.extend({},defaults,opt);
		var total=config.data.length;
		var percent=(config.index/total)*100+"%";
		var tpl='';
		var aligns=(config.align=='top')?'':'step-bottom';
		tpl+='<div class="step-wrap '+aligns+' step-'+config.theme+'">';
		tpl+='	<div class="step-bg"></div>';
		tpl+='	<div class="step-progress"></div>';
		tpl+='	<div class="step">';
		$.each(config.data,function(i,t)
		{
			tpl+='<div class="step-item';
			if(i<=config.index-1)
			{
				tpl+=' active';
			}
			if(config.arrow)
			{
				if(i==config.index-1)
				{
					tpl+=' step-arrow';
				}
			}
			tpl+='">';
			if(config.align=='top')
			{
				tpl+='<div class="step-num">'+(i+1)+'</div>';
				tpl+='<div class="step-title">'+(t)+'</div>';
			}
			else
			{
				tpl+='<div class="step-title">'+(t)+'</div>';
				tpl+='<div class="step-num">'+(i+1)+'</div>';
			}
			tpl+='</div>';
		})
		tpl+='	</div>';
		tpl+='</div>';
		e.html(tpl);
		e.find(".step-progress").animate({"width":percent},config.time)
	};
	$.fn.backtime=function(opt)
	{
		var e=this;
		var defaults={'time':60};
		var config=$.extend({},defaults,opt);
		var oldtext=e['html']();
		var backgo=function(t0)
		{
			e['attr']("disabled",true);
			e['html']("<span class='text-red'>"+t0+"</span>"+kuicms.language()['backtime']+"");
			t0=t0-1;
			if(t0>=0)
			{
				window.setTimeout(function(){backgo(t0)},1000);
			}
			else
			{
				e['attr']("disabled",false);
				e['html'](oldtext);
			}
		};
		backgo(config.time);
	};
	$.fn.endtime=function(fn)
	{
		var e=this;
		var num=0;
		$(e).each(function()
		{
			num++;
			var that=$(this);
			var time=that.attr("data-time") || 0;
			var endTime=new Date(parseInt(time)*1000);
			var nMS=endTime.getTime()-new Date().getTime();
			if(parseFloat(nMS)<=0)
			{
				that.html(kuicms.language()['over']);
				if(fn&& typeof fn=="function")
				{
					fn(that);
				}
			}
			else
			{
				setInterval(function()
				{
					$(e).each(function()
					{
						var that=$(this);
						var time=that.attr("data-time") || 0;
						var endTime=new Date(parseInt(time)*1000);
						var nMS=endTime.getTime()-new Date().getTime();
						var myD=Math.floor(nMS/(1000 * 60 * 60 * 24));
						var myH=Math.floor(nMS/(1000*60*60)) % 24;
						var myM=Math.floor(nMS/(1000*60)) % 60;
						var myS=Math.floor(nMS/1000) % 60;
						var str='';
						if(myD>0)
						{
							str="<i>"+myD+"</i>"+kuicms.language()['day']+"<i>"+myH+"</i>"+kuicms.language()['hour']+"<i>"+myM+"</i>"+kuicms.language()['minute']+"<i>"+myS+"</i>"+kuicms.language()['second']+"";
						}
						else if(myH> 0)
						{
							str="<i>"+myH+"</i>"+kuicms.language()['hour']+"<i>"+myM+"</i>"+kuicms.language()['minute']+"<i>"+myS+"</i>"+kuicms.language()['second']+"";
						}
						else if(myM>0)
						{
							str="<i>"+myM+"</i>"+kuicms.language()['minute']+"<i>"+myS+"</i>"+kuicms.language()['second']+"";
						}
						else
						{
							str="<i>"+myS+"</i>"+kuicms.language()['second']+"";
						}
						if(nMS>0)
						{
							that.html(str);
						}
						else
						{
							if(fn&& typeof fn=="function")
							{
								fn(that);
							}
						}
					});
				},1000);
			}
		})
    };
	$.fn.page=function(opt)
	{
		var defaults=
		{
			'totalnum':0,
			'totalpage':0,
			'thispage':1,
			'num':3,
			'total':kuicms.language()['total'],
			'pre':kuicms.language()['pre'],
			'next':kuicms.language()['next'],
			'home':kuicms.language()['home'],
			'last':kuicms.language()['last'],
			'clickpage':1,
			'ismobile':0,
			'callback':function(){}
		};
		var config=$.extend({},defaults,opt);
		this.each(function()
		{
			var e=$(this);
			var show=function(e,$page,ismobile)
			{
				var total=parseInt(config.totalnum);
				var totalpage=parseInt(config.totalpage);
				if($page>totalpage)
				{
					$page=1;
				}
				var thispage=$page;
				if(total==0 || totalpage==1)
				{
					e.html('');
					return;
				}
				if(ismobile==0)
				{
					var $i=parseInt(config.num);
					var $begin=parseInt(thispage);
					var $end=parseInt(thispage);
				
					while(1==1)
					{
						if($begin>1)
						{
							$begin=$begin-1;
							$i=$i-1;
						}
						if($i>1 && $end<totalpage)
						{
							$end=$end+1;
							$i=$i-1;
						}
						
						if(($begin<=1 && $end>=totalpage) || $i<=1)
						{
							break;
						}
					}
					var html='<ul>';
					html+='<li><a data-page="0">'+config.total+config.totalnum+'</a></li>';
					if(thispage>1)
					{
						html+='<li><a href="javascript:;" data-page="'+(parseInt(thispage)-1)+'">'+config.pre+'</a></li>';
					}
					
					if($begin!=1)
					{
						html+='<li><a href="javascript:;" data-page="1">1...</a></li>';
					}
					
					for($i=$begin;$i<=$end;$i++)
					{
						if($i==thispage)
						{
							html+='<li class="active"><a href="javascript:;" data-page="'+$i+'">'+thispage+'</a></li>';
						}
						else
						{
							html+='<li><a href="javascript:;" data-page="'+$i+'">'+$i+'</a></li>';
						}
					}
					if($end!=totalpage)
					{
						html+='<li><a href="javascript:;" data-page="'+totalpage+'">...'+totalpage+'</a></li>';
					}
					if(thispage < totalpage)
					{
						html+='<li><a href="javascript:;" data-page="'+(parseInt(thispage)+1)+'">'+config.next+'</a></li>';
					}
					html+='<li><a data-page="0">'+thispage+'/'+config.totalpage+'</a></li>';
					html+='</ul>';
					e.html(html);
				}
				else
				{
					var html='<ul>';
					if(thispage==1)
					{
						html+='<li><a data-page="0">'+config.home+'</a></li>';
					}
					else
					{
						html+='<li><a href="javascript:;" data-page="1">'+config.home+'</a></li>';
					}
					
					if(thispage>1)
					{
						html+='<li><a href="javascript:;" data-page="'+(parseInt(thispage)-1)+'">'+config.pre+'</a></li>';
					}
					else
					{
						html+='<li><a data-page="'+(parseInt(thispage)-1)+'">'+config.pre+'</a></li>';
					}
					if(thispage < totalpage)
					{
						html+='<li><a href="javascript:;" data-page="'+(parseInt(thispage)+1)+'">'+config.next+'</a></li>';
					}
					else
					{
						html+='<li><a data-page="0">'+config.next+'</a></li>';
					}
					if(thispage!=totalpage)
					{
						html+='<li><a href="javascript:;" data-page="'+totalpage+'">'+config.last+'</a></li>';
					}
					else
					{
						html+='<li data-page="0"><a data-page="'+totalpage+'">'+config.last+'</a></li>';
					}
					html+='<li><a data-page="0">'+thispage+'/'+config.totalpage+'</a></li>';
					e.html(html);
				}

			}
			/*初次渲染*/
			show(e,config.thispage,config.ismobile);
			
			/*点击事件*/
			e.find("li a").click(function(event)
			{
				var pnum=$(this).attr("data-page");
				if(pnum!=0)
				{
					config.clickpage=pnum;
					event.preventDefault();
					e.html('');
					//重新渲染
					e.page(
					{
						'totalnum':config.totalnum,
						'totalpage':config.totalpage,
						'thispage':pnum,
						'num':config.num,
						'total':config.total,
						'pre':config.pre,
						'next':config.next,
						'home':config.home,
						'last':config.last,
						'clickpage':config.clickpage,
						'ismobile':config.ismobile,
						'callback':config.callback
					});
				}
			});
			
			/*回调事件*/
			if(typeof config.callback=="function")
			{
				config.callback(config);
			}
		});
		
	};
	$.fn.address=function(opt)
	{
		var e=$(this);
		var defaults={'get':function(){},'ismobile':0,'oktheme':'btn-blue'};
		var config=$.extend({},defaults,opt);
		e.click(function(fn)
		{
			var that=this;
			var defaultVal=($(that).attr("data-val") || '');
			$mask=$('<div class="dialog-mask" id="ui-address-mask"></div>');
			$("body").append($mask).parent().css("overflow","hidden");;
			$mask.fadeIn(function(){$(this).css("display","block")});

			var address=[];
			address.show=function(data,lever,val)
			{
				var area=data;
				var defaultVal=[];
				if(val!='')
				{
					defaultVal=val.split("/");
				}
				var thisVal=defaultVal[lever-1];
				var city=$(".address_data .col-4").eq(lever-1).children("ul");
				if(area.length>0)
				{
					var html='';
					for(var i=0;i<area.length;i++)
					{
						
						var active='';
						if((i==0 && thisVal=='') || (thisVal!='' && area[i].name==thisVal))
						{
							active=' class="active"';
						}
						html+='<li'+active+'>'+area[i].name+'</li>';
					}
					city.html(html)
					var num=city.find(".active").index();
					if(num<0)
					{
						num=0;
						city.find("li").eq(num).addClass("active");
					}
					if(lever<=3)
					{
						if(lever==1)
						{
							if(num>=6)
							{
								$(".address_data .col-4").eq(0).find("ul").animate({scrollTop:((num-3)*51)+'px'},'slow');
							}
							var db=area[num].city;
						}
						if(lever==2)
						{
							var f=$(".address_data .col-4").eq(1).children("ul").find(".active").index();
							if(f>=6)
							{
								$(".address_data .col-4").eq(1).find("ul").animate({scrollTop:((f-3)*51)+'px'},'slow');
							}
							else
							{
								$(".address_data .col-4").eq(1).find("ul").animate({scrollTop:0},'slow');
							}
							var db=area[num].district;
						}
						else
						{
							var f=$(".address_data .col-4").eq(2).children("ul").find(".active").index();
							if(f>=6)
							{
								$(".address_data .col-4").eq(2).find("ul").animate({scrollTop:(0+(f-3)*51)+'px'},'slow');
							}
							else
							{
								$(".address_data .col-4").eq(2).find("ul").animate({scrollTop:0},'slow');
							}
						}
						if(lever<3)
						{
							address.show(db,(lever+1),val);
						}
					}
				}
			};
			var html='';
				html+='<div class="dialog" id="dialog_address" style="z-index:999;">';
				html+='<div class="dialog-header">';
				html+='<div class="dialog-title">'+kuicms.language()['city']+'</div>';
				html+='<div class="dialog-close rotate">×</div>';          
				html+='</div>';
			
			var text='';
				text+='<div class="row ui-address address_data">';
				text+='	<div class="col-4">';
				text+='		<ul class="list" data-lever="1"></ul>';
				text+='	</div>';
				text+='	<div class="col-4">';
				text+='		<ul class="list" data-lever="2"></ul>';
				text+='	</div>';
				text+='	<div class="col-4">';
				text+='		<ul class="list" data-lever="3"></ul>';
				text+='	</div>';
				text+='</div>';
			html+='<div class="dialog-body dialog-body-address">'+text+'</div>';
			if(config.ismobile==0)
			{
				html+='<div class="dialog-footer"><button class="btn '+config.oktheme+' dialog-ok mr">'+kuicms.language()['ok']+'</button><button class="btn dialog-cancel">'+kuicms.language()['cancel']+'</button></div>';
			}
			else
			{
				html+='<div class="dialog-footer-mobile"><button class="dialog-cancel">'+kuicms.language()['cancel']+'</button><button class="dialog-ok">'+kuicms.language()['ok']+'</button></div>';
			}
			html+='</div>';
			$dialog=$(html);
			$("body").append($dialog);

			$dialog.css({"width":"30rem"});
			$dialog.find(".dialog-footer").css({"border-width":"1px"});
			var x=($(window).width()-$dialog.outerWidth())/2;
			var y=($(window).height()-$dialog.outerHeight())/2-50;
			$dialog.css({"top":y,"left":x,"position":"fixed","margin":"0 auto"});
			address.show(addressJson,1,defaultVal);
			$dialog.addClass("dialog-in").fadeIn();
			$(document).on("click",".ui-address .list li",function()
			{
				var e=$(this);
				var num=e.index();
				var lever=e.parent().attr("data-lever");
				e.siblings().removeClass('active').end().addClass('active');
				if(lever==1)
				{
					address.show(addressJson[num].city,2,'');
				}
				else if(lever==2)
				{
					var prov=$(".address_data .col-4").eq(0).children("ul").find(".active").index();
					address.show(addressJson[prov].city[num].district,3,'');
				}
			});
			that.close=function()
			{
				$("body").parent().css("overflow","auto");
				$dialog.removeClass("dialog-in").addClass("dialog-out").fadeOut(function(){$(this).remove();setTimeout(function(){$mask.fadeOut(function(){$(this).remove()});},100);})
			};
			that.getVal=function()
			{
				var data=[];
				var r1=$dialog.find(".address_data .col-4").eq(0).children("ul").find(".active").text();
				var r2=$dialog.find(".address_data .col-4").eq(1).children("ul").find(".active").text();
				var r3=$dialog.find(".address_data .col-4").eq(2).children("ul").find(".active").text();
				data['prov']=r1;
				data['city']=r2;
				data['district']=r3;
				return data;
			};
			$dialog.find(".dialog-close").click(function()
			{
				that.close();
			});
			$dialog.find(".dialog-cancel").click(function()
			{
				that.close();
			});
			$dialog.find(".dialog-ok").click(function()
			{
				var val=that.getVal();
				e.attr("data-val",val['prov']+'/'+val['city']+'/'+val['district']);
				e.val(val['prov']+val['city']+val['district']);
				config.get(val);
				that.close();
			});
		})
	};
	/*打开或关闭某个modal*/
	$.fn.modal=function(type)
	{
		var e=$(this);
		$modal(e,type);
	};
	/*打开或关闭某个offside*/
	$.fn.offside=function(type)
	{
		var e=$(this);
		$offside(e,type);
	};
	
	$(".bar").animate({"right":0},"slow");
	
	/*自动调用*/
	if($(".inputnumber").length>0)
	{
		$(".inputnumber").inputnumber();
	}
	
})