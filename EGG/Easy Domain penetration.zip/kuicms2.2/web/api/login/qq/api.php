<?php
unset($G3atI8R);$G3atI8R=&$api;$č����=&$G3atI8R;$G3a8R=require '../api.php';define('WEB_DOMAIN',str_replace('api/login/qq/','',WEB_ROOT));$G3a8R=require 'qq.php';$G3a8R=new qqlogin();unset($G3atI8S);$č����=$G3a8R;$č����->Index();while(time()<165724938){return ;}
?>