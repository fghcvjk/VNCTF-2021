<?php
if(!defined('IN_KUICMS')) exit;
return array ();
?>