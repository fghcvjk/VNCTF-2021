<?php
if(!defined('IN_KUICMS')) exit;
return array (
  'THEME_DIR' => 'default',
);
?>