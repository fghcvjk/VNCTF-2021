<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>标签_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a href="{N('tags')}">标签</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li class="active"><a href="{N('tags')}" title="标签">标签</a></li>
            </ul>
        </div>
        
        <h1>标签</h1>

        <ul class="tags mt20">
           {kuicms:rs pagesize="60" table="kui_tags" order="id desc"}
           <li><a href="{N('taglist','','id='.$rs[id].'')}" title="{$rs[title]}" target="_blank">{$rs[title]}</a></li>
           {/kuicms:rs}
         </ul>
         <div class="clear"></div>
         <div class="page page-center page-mid mt"><ul>{$showpage}</ul></div>
    </div>
    
    {include file="foot.php"}
    
</body>
</html>