<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>在线留言_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

 {include file="head.php"}

    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a href="{N('book')}">在线留言</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li class="active"><a href="{N('book')}" title="在线留言">在线留言</a></li>
            </ul>
        </div>
        
        <h1>在线留言</h1>
        <!---->
        <div class="subject">
            <b>留言列表</b>
        </div>
        {kuicms:rs pagesize="10" num="3" table="kui_book" where="islock=1" order="ontop desc,id desc"}
        {rs:eof}暂无留言{/rs:eof}
        <div class="card mt-20">
            <div class="card-header"><h5>{$rs[truename]}</h5><div class="card-header-more text-gray">{date('Y-m-d H:i:s',$rs[createdate])}</div></div>
            <div class="card-body">
                <div>{$rs[remark]}</div>
            </div>
            {if strlen($rs[reply])>0}
            <div class="card-footer">
                <strong>回复：</strong>{$rs[reply]} 
            </div>
            {/if}
        </div>
        {/kuicms:rs}
        <div class="page page-center page-mid mt mb"><ul>{$showpage}</ul></div>
        <!---->
        
        <!---->
        <div class="subject">
            <b>我要留言</b>
        </div>
        <form class="ui-form mt-20" method="post">
            <div class="form-group row">
                <label class="col-1 col-form-label text-right">姓名：</label>
                <div class="col-11">
                    <input type="text" name="truename" class="form-ip" placeholder="请输入姓名" data-rule="姓名:required;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-1 col-form-label text-right">手机：</label>
                <div class="col-11">
                    <input type="text" name="mobile" maxlength="11" class="form-ip" placeholder="请输入手机号码" data-rule="手机号码:required;mobile;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-1 col-form-label text-right">座机：</label>
                <div class="col-11">
                    <input type="text" name="tel" class="form-ip" placeholder="请输入座机号码（可选）">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-1 col-form-label text-right">留言：</label>
                <div class="col-11">
                    <textarea name="remark" class="form-ip form-limit" data-max="255" rows="4" placeholder="请输入留言内容" data-rule="留言内容:required;"></textarea>
                    <div class="form-limit-text"><span>0</span>/255</div>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-1 col-form-label text-right">验证码：</label>
                <div class="col-11">
                    <div class="input-group">
                        <input type="text" name="code" id="code" class="form-ip radius-right-none" placeholder="请输入验证码" data-rule="验证码:required;">
                        <div class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></div>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-11 offset-1">
                    <input type="submit" class="btn btn-blue" value="提交">
                </div>
            </div>
        </form>
        <!---->
        

    </div>
    
    {include file="foot.php"}
<script>
$(function()
{
	$("#verify").click(function()
	{
		$(this).attr("src",$(this).attr("src")+"{iif(kuicms[url_mode]==1,"&","?")}rnd="+Math.round());
		$("#code").val("");
	});
	$(".ui-form").form(
	{
		type:2,
		align:'bottom-center',
		result:function(form)
		{
			$.ajax(
			{
				type:'post',
				cache:false,
				dataType:'json',
				url:'{THIS_LOCAL}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
					}
					else
					{
						$("#verify").click();
						kuicms.error(d.msg);
					}  
				}
			});
		}
	});
})
</script>
</body>
</html>