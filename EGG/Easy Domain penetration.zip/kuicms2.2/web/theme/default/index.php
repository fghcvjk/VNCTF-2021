<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{if strlen(kuicms[seo_title])>0}{kuicms[seo_title]}_{/if}{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="bookmark" href="/favicon.ico"/>
</head>

<body>

    {include file="head.php"}
    
    <div class="carousel banner">
        <div class="carousel-inner">
            {kuicms:rs table="kui_ad" where="akey='pc' and islock=1"}
            {php $adlist=jsdecode($rs[datalist])}
            {php $step=0}
            {foreach $adlist as $num=>$val}
                <div class="carousel-item{if $step==0} active{/if}"><a style="background:url('{$val['image']}') no-repeat center;" href="{$val['url']}" title="{$val['desc']}"></a></div>
            {php $step++}
            {/foreach}
            {/kuicms:rs}
        </div>
    </div>
        
    <div class="width">
        <div class="subject m20 ui-am-slide-top ui-am-delay-1">
        	<span class="more"><a href="{cateurl(1)}">更多>></a></span><b>关于我们</b>
        </div>
        
        <div class="home_about">
            <div class="left ui-am-slide-left ui-am-delay-1-5">
            	{if is_video(kuicms[home_video])}
            	<video src="{kuicms[home_video]}" width="410" height="260" controls autoplay></video>
                {else}
                <img src="{kuicms[home_video]}" width="410" height="260">
                {/if}
            </div>
            <div class="right ui-am-slide-right ui-am-delay-1-5">
                {block("about")}
            </div>
        </div>
    </div>
    
    <div class="bg_gray">
        <div class="width">
            <div class="subject scrollspy" data-am="ui-am-slide-bottom" data-time="500">
                <span class="more"><a href="{cateurl(3)}">更多>></a></span><b>推荐产品</b>
            </div>
            <div class="home_nav mt30 scrollspy" data-am="ui-am-slide-bottom" data-time="500">
                <ul>
                	{kuicms:rs top="5" table="kui_category" where="followid=3" order="catenum,cateid"}
                    <li{if $i==1} class="hover"{/if} id="one{$i}" onmouseover="setTab('one',{$i},{$total_rs})"><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}">{$rs[catename]}</a></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
            </div>
            <div class="home_pro scrollspy" data-am="ui-am-slide-bottom" data-time="1500">
            	{kuicms:rp top="5" table="kui_category" where="followid=3" order="catenum,cateid" auto="j"}
                {php $sonid=get_sonid_all($rp[cateid])}
                <ul id="con_one_{$j}"{if $j>1} class="dis"{/if}>
                	{kuicms:rs top="8" table="kui_model_pro" join="left join kui_content on kui_model_pro.cid=kui_content.id" where="islock=1 and isnice=1 and classid in($sonid)" order="ontop desc,ordnum desc,id desc"}
                	<li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,280)}" alt="{$rs[title]}" height="280"></div><p class="title">{cutstr($rs[title],90,1)}</p><p class="price"><span>人气：{$rs[hits]}</span>{if $rs[price]!=0}¥ {$rs[price]}{else}面议{/if}</p></a></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
                {/kuicms:rp}
            </div>
        </div>
    </div>
    
    <div class="width">
        <div class="subject m20 scrollspy" data-am="ui-am-slide-bottom" data-time="500">
        	<span class="more"><a href="{cateurl(2)}">更多>></a></span><b>新闻中心</b>
        </div>
        <div class="home_news scrollspy" data-am="ui-am-slide-bottom" data-time="600">
             <ul class="home_news_list">
				{php $sonid=get_sonid_all(2)}
                {php $subid=deal_subid($sonid)}
                {kuicms:rs top="8" table="kui_content" where="islock=1 and classid in($sonid)" sub="$subid" order="ontop desc,ordnum desc,id desc"}
                <li><span class="date">{date('m-d',$rs[createdate])}</span><div><a href="{$rs[link]}" title="{$rs[title]}">{cutstr($rs[title],80,1)}</a>{cutstr(nohtml($rs[intro]),200,1)}</div></li>
                {/kuicms:rs}
             </ul>
             <div class="clear"></div>
        </div>
    </div>
    
    <div class="bg_gray">
        <div class="width">
            <div class="subject scrollspy" data-am="ui-am-slide-bottom" data-time="1000">
                <span class="more"><a href="{cateurl(4)}">更多>></a></span><b>客户案例</b>
            </div>
            <div class="list_pic scrollspy" data-am="ui-am-slide-bottom" data-time="1500">
                <ul>
                	{php $sonid=get_sonid_all(4)}
                    {kuicms:rs top="4" table="kui_content" where="islock=1 and classid in($sonid) and isnice=1" order="ontop desc,ordnum desc,id desc"}
                    <li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,200)}" alt="{$rs[title]}" height="200"></div><p class="title">{cutstr($rs[title],46,1)}</p></a></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
            </div>
            
        </div>
    </div>
    
    <div class="width">
        <div class="subject m20 scrollspy" data-am="ui-am-slide-bottom" data-time="1000">
        	<b>合作客户</b>
        </div>
        <div class="home_logo scrollspy" data-am="ui-am-slide-bottom" data-time="1500">
              <ul>
              	{kuicms:rs top="0" table="kui_link" where="islogo=1 and islock=1" order="ordnum,id"}
              	<li><a href="{$rs[weburl]}" title="{$rs[webname]}" target="_blank"><img src="{$rs[weblogo]}"></a></li>
                {/kuicms:rs}
              </ul>
              <div class="clear"></div>
        </div>
    </div>
    
    <div class="bg_link">
        <div class="width link">
            <!--<div class="link_title">友情链接：</div>-->
            <div class="link_list" id="link">
            {kuicms:rs top="0" table="kui_link" where="islogo=0 and islock=1" order="ordnum,id"}
            <a href="{$rs[weburl]}" title="{$rs[webname]}" target="_blank">{$rs[webname]}</a>
            {/kuicms:rs}
            </div>
            <div class="clear"></div>
        </div>
    </div>
    {include file="foot.php"}
    <script>
	$(function(){
		//首页链接添加选中效果
		$("#nav ul li:first-child").addClass("hover");
	})
	</script>
</body>
</html>