<?php
if(!defined('IN_KUICMS')) exit;
return array (
  0 => '<p>致力于产品的良好用户体验、有效的网络营销效果而努力</p>',
);
?>