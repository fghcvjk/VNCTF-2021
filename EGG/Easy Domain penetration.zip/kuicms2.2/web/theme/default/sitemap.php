<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>网站地图_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>网站地图</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li class="active">网站地图</li>
            </ul>
        </div>
                
            {kuicms:rp top="0" table="kui_category" where="followid=0 and isshow=1" order="catenum,cateid"}{php $map_sonid=$rp[cateid]}
            <div class="map_one"><a href="{cateurl($rp[cateid])}" title="{$rp[catename]}"{if $rp[isblank]==1} target="_blank"{/if}>{$rp[catename]}</a></div>
            <div class="map_two">
                {kuicms:rs top="0" table="kui_category" where="followid=$map_sonid and isshow=1" order="catenum,cateid"}
                <a href="{cateurl($rs[cateid])}" title="{$rs[catename]}"{if $rs[isblank]==1} target="_blank"{/if}>{$rs[catename]}</a>
                {/kuicms:rs}
            </div>
            {/kuicms:rp}
        
    </div>
    
    {include file="foot.php"}
    
</body>
</html>