<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{$tagname}_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a href="{N('tags')}">标签</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li><a href="{N('tags')}" title="标签">标签</a></li>
                <li class="active">{$tagname}</li>
            </ul>
        </div>
        
        <h1>{$tagname}</h1>

        <ul class="news_list mt20">
           {kuicms:rs pagesize="20" table="kui_content" where="$where" order="ontop desc,ordnum desc,id desc"}
           <li><span class="date">{date('d',$rs[createdate])}<em>{date('Y',$rs[createdate])}-{date('m',$rs[createdate])}</em></span><div><a href="{$rs[link]}" title="{$rs[title]}" target="_blank">{str_replace($tagname,"<font color=red>$tagname</font>",$rs[title])}</a>        {cutstr(nohtml($rs[intro]),500,1)}</div></li>
           {/kuicms:rs}
         </ul>
         <div class="clear"></div>
         <div class="page page-center page-mid mt"><ul>{$showpage}</ul></div>
    </div>
    
    {include file="foot.php"}
    
</body>
</html>