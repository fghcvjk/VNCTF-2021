<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>城市分站_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>城市分站</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li class="active">城市分站</li>
            </ul>
        </div>
        
        <!--城市选择开始-->
        <div class="filter mt-15">
            
            <div class="row">
                <div class="col-1 filter-left">全国：</div>
                <div class="col-11 filter-right">
                    <a href="{WEB_DOMAIN}"{if $city==''} class="active"{/if}>进入全国站</a>
                </div>
            </div>
            {kuicms:rp top="0" table="kui_city" where="site_open=1 and followid=0" order="ordnum,cateid"}
            {php $fid=$rp[cateid]}
            <div class="row">
                <div class="col-1 filter-left"><a href="{if $rp[site_domain]==1}{WEB_HTTP}{$rp[site_root]}.{C('city_domain')}{else}{N($rp[site_root],0,'',1,1)}{/if}">{$rp[name]}</a>：</div>
                <div class="col-11 filter-right">
                    {kuicms:rs top="0" table="kui_city" where="site_open=1 and followid=$fid" order="ordnum,cateid"}
                        <a href="{if $rs[site_domain]==1}{WEB_HTTP}{$rs[site_root]}.{C('city_domain')}{else}{N($rs[site_root],0,'',1,1)}{/if}"{if $city==$rs[site_root]} class="active"{/if}>{$rs[name]}</a>
                    {/kuicms:rs}
                </div>
            </div>
            {/kuicms:rp}
        </div>
        <!--城市选择结束-->

        
    </div>
    
    {include file="foot.php"}
    
</body>
</html>