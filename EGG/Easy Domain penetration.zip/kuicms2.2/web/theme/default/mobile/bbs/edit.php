<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>编辑主题_{if strlen(kuicms[bbs_seotitle])>0}{kuicms[bbs_seotitle]}_{/if}{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{kuicms[bbs_seokey]}">
<meta name="description" content="{kuicms[bbs_seodesc]}">
<script src="{WEB_ROOT}public/ueditor/ueditor.config.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.all.min.js"></script>
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	<section>
        	<div class="newpost">
                 <!---->
                 <form class="ui-form" method="post">
                    <div class="form-group">
                        <input type="text" name="title" class="form-ip" value="{$title}" size="60" maxlength="50" placeholder="请输入标题" data-rule="标题:required;">
                    </div>
                    <div class="form-group">
						<script id="content" name="content" type="text/plain" style="height:260px;">{$content}</script>
                        <script>UE.getEditor('content',{serverUrl:'{U('home/upload/index')}',toolbars:editorBbs});</script>
                    </div>
                    {if kuicms[bbs_post_code]==1}
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" class="form-ip radius-right-none" name="code" id="code" size="8" maxlength="8" placeholder="请输入验证码" data-rule="验证码:required;">
                            <span class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></span>
                        </div>
                    </div>
                    {/if}
                    <div class="form-group">
                        <button type="submit" class="btn btn-blue mr">保存</button>
                        <button type="button" class="btn" onClick="location.href='{PRE_URL}'">返回</button>
                    </div>
                </form>
                 <!---->
                </div>
        </section>
    </article>
    {include file="mobile/foot.php"}
    <script>
	$(function()
	{
		$("#verify").click(function()
		{
			$(this).attr("src",$(this).attr("src")+"{iif(kuicms[url_mode]==1,"&","?")}rnd="+Math.round());
			$("#code").val("");
		});
		
		$(".ui-form").form(
		{
			type:2,
			align:'bottom-center',
			result:function(form)
			{
				var content=UE.getEditor('content').getContent();
				if(content=='')
				{
					toastr.error('内容不能为空');
					return false;	
				}
				$.ajax(
				{
					type:'post',
					cache:false,
					dataType:'json',
					url:'{THIS_LOCAL}',
					data:$(form).serialize(),
					error:function(e){alert(e.responseText);},
					success:function(d)
					{
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{PRE_URL}';},1500);
						}
						else
						{
							kuicms.error(d.msg);
						}  
					}
				});
			}
		});
	})
	</script>
</body>
</html>