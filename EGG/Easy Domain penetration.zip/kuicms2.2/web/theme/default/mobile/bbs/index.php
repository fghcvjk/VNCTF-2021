<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{if strlen($seotitle)>0}{$seotitle}_{/if}{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{$seokey}">
<meta name="description" content="{$seodesc}">
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	
    	<section>
        	<div class="row mt">
            	<div class="col-6 text-left">
                    <a href="javascript:;" class="btn btn-blue dropdown-show" data-target="#dropdown-bbs">{if strlen($seotitle)>0}{$seotitle}{else}全部主题{/if}<i class="ui-icon-down ml-sm"></i></a>
                </div>
                <div class="col-6 text-right">
                    <a href="{N('bbsadd','','fid='.$fid.'')}" class="btn btn-yellow">发布主题</a>
                </div>
            
            </div>
            <div class="dropdown" id="dropdown-bbs">
                <a href="{N('bbs')}" class="dropdown-item {if $fid==0}active{/if}">全部主题</a>
                {foreach $bbscate as $key=>$val}
                <a href="{N('bbs','','fid='.$val['cateid'].'')}" class="dropdown-item {if $fid==$val['cateid']}active{/if}">{$val['catename']}</a>
                {/foreach}
            </div>
            
            <div class="clear"></div>
            <ul class="bbs_list">
                {kuicms:rs pagesize="20" num="3" table="kui_bbs" join="left join kui_user on kui_bbs.userid=kui_user.id" where="kui_bbs.islock=1 $where" order="ontop desc,bbs_id desc" key="bbs_id"}
                {rs:eof}<p>没有主题</p>{/rs:eof}
                <li>
                    <div class="face"><img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" alt="{$rs[uname]}"></div>
                    <div class="info">
                        <h5><a href="{N('bbsshow','','id='.$rs[bbs_id].'')}" title="{$rs[title]}">{$rs[title]}</a>{if $rs[ontop]==1}<em>置顶</em>{/if}{if $rs[isnice]==1}<em>精</em>{/if}</h5>
                        <div class="nickname"><a href="{U('home/bbs/mytopic','uid='.$rs[userid].'')}">{$rs[uname]}</a>　{formatTime($rs[createdate])}</div>
                        <div class="other"><span class="ui-icon-eye"></span>{$rs[hits]}　<span class="ui-icon-comment"></span>{$rs[replynum]} </div>
                    </div>
                </li>
                {/kuicms:rs}
             </ul>
             <div class="clear"></div>
             <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
             
             <div class="bbs_search">
                <form action="{U('home/bbs/search')}" method="get">
                    {if kuicms[url_mode]==1}<input type="hidden" name="c" value="bbs" /><input type="hidden" name="a" value="search" />{/if}
                    <input type="text" name="keyword" placeholder="请输入关键字"><input type="submit" value="搜索">
                </form>
            </div>
             
        </section>
    </article>
    {include file="mobile/foot.php"}

</body>
</html>