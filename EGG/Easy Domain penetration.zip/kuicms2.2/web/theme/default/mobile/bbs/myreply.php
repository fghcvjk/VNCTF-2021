<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>我的回复_{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{$seokey}">
<meta name="description" content="{$seodesc}">
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	<section>
            <div class="subject">
                <b>我的回复</b>
            </div>
            
            <ul class="media-list media-border mt-20 mb-20">
                {kuicms:rs pagesize="10" num="3" table="kui_bbs_reply" join="left join kui_user on kui_bbs_reply.userid=kui_user.id" where="kui_bbs_reply.islock=1 and istopic=0 and userid=$uid" order="replyid desc" key="replyid"}
                <li class="media">
                    <div class="media-img mr-20 radius">
                        <img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" alt="{$rs[uname]}" width="56" height="56" >
                    </div>
                    <div class="media-body">
                        <div class="media-header row align-items-center">
                            <div class="col-8 font-14">{$rs[uname]}<span class="pl text-gray">{formatTime($rs[createdate])}</span></div>
                            <div class="col-4 text-right font-13 text-gray">{switch ($i+15*($page-1))}{case 1}沙发{/case}{case 2}板凳{/case}{case 3}地板{/case}{default}{$i+15*($page-1)}楼{/switch}</div>
                        </div>
                        <div class="media-text">
                            {$rs[content]}
                        </div>
                    </div>
                </li>
                {/kuicms:rs}
            </ul>
    
            {if $pg->totalpage>1}
            <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
            {/if}
            
    	</section>
    </article>
    {include file="mobile/foot.php"}
</body>
</html>