<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{$keyword}_{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{$seokey}">
<meta name="description" content="{$seodesc}">
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	
    	<section>
        	<div class="subject">
                <b>主题搜索</b>
            </div>
            <div class="clear"></div>
            <ul class="bbs_list">
                {kuicms:rs pagesize="20" num="3" table="kui_bbs" join="left join kui_user on kui_bbs.userid=kui_user.id" where="kui_bbs.islock=1 $where" order="ontop desc,bbs_id desc" key="bbs_id"}
                {rs:eof}没有找到您要的结果{/rs:eof}
                <li>
                    <div class="face"><img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" alt="{$rs[uname]}"></div>
                    <div class="info">
                        <h5><a href="{N('bbsshow','','id='.$rs[bbs_id].'')}" title="{$rs[title]}">{str_replace($keyword,"<font color=red>$keyword</font>",$rs[title])}</a>{if $rs[ontop]==1}<em>置顶</em>{/if}{if $rs[isnice]==1}<em>精</em>{/if}</h5>
                        <div class="nickname"><a href="{U('home/bbs/mytopic','uid='.$rs[userid].'')}">{$rs[uname]}</a>　{formatTime($rs[createdate])}</div>
                        <div class="other"><span class="am-icon-eye am-icon-fw"></span>{$rs[hits]}　<span class="am-icon-comment-o am-icon-fw"></span>{$rs[replynum]} </div>
                    </div>
                </li>
                {/kuicms:rs}
             </ul>
             <div class="clear"></div>
             <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
        </section>
    </article>
    {include file="mobile/foot.php"}

</body>
</html>