<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>标签_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>
	{include file="mobile/head.php"}
    
    <article>
    	<section>
        	<div class="subject">
                <b>标签</b>
            </div>
            <div class="clear"></div>
            <ul class="tags mt20">
               {kuicms:rs pagesize="60" table="kui_tags" order="id desc"}
               <li><a href="{N('taglist','','id='.$rs[id].'')}" title="{$rs[title]}">{$rs[title]}</a></li>
               {/kuicms:rs}
             </ul>
             <div class="clear"></div>
             <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
        </section>
    </article>
    {include file="mobile/foot.php"}

</body>
</html>