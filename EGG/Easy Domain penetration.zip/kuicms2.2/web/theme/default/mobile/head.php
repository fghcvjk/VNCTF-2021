<?php if(!defined('IN_KUICMS')) exit;?><header class="header">
    <div class="fr"><a href="javascript:history.go(-1)" class="ui-icon-left"></a></div>
    <div class="fl"><a href="javascript:;" class="ui-icon-list offside-show" data-target="#nav_top"></a></div>
    <div class="logo"><a href="{WEB_ROOT}"><img src="{kuicms[mobile_logo]}" alt="{kuicms[web_name]}" /></a></div>
    <div class="clear"></div>
</header>

    <div class="offside offside-left offside-black" id="nav_top">   
        <ul class="collapse">
            <li><a href="{WEB_ROOT}">网站首页</a></li>
            {kuicms:rp top="0" table="kui_category" where="followid=0 and isshow=1" order="catenum,cateid"}{php $sub_sonid=$rp[cateid]}
            <li class="collapse-menu{if get_sonid_num($rp[cateid])!=0} hasson{/if}">
            	{if get_sonid_num($rp[cateid])!=0}<span class="ui-icon-right"></span>{/if}
            	<a href="{cateurl($rp[cateid])}" title="{$rp[catename]}">{$rp[catename]}</a>
                {if get_sonid_num($rp[cateid])!=0}
                <ul class="collapse-body hide">
                    {kuicms:rs top="0" table="kui_category" where="followid=$sub_sonid and isshow=1" order="catenum,cateid"}
                    <li><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}">{$rs[catename]}</a></li>
                    {/kuicms:rs}
                </ul>
                {/if}
            </li>
            {/kuicms:rp}
        </ul>
    </div>