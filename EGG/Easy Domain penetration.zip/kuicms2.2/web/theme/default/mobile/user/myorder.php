<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>我的订单_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body class="bg-white">
	{include file="mobile/head.php"}

    <article>
    	<div class="pl-15 pr-15">
        	<div class="menu menu-blue mb-20 mt">
            	<div class="menu-name">我的订单</div>
            </div>
            <div class="btn-group btn-group-blue btn-group-bg btn-group-full mb-20">
                <a class="btn-group-item{if $type==0} active{/if}" href="{N('myorder')}">全部</a>
                <a class="btn-group-item{if $type==1} active{/if}" href="{N('myorder','','type=1')}">已支付</a>
                <a class="btn-group-item{if $type==2} active{/if}" href="{N('myorder','','type=2')}">未支付</a>
            </div>
            
                {kuicms:rs pagesize="10" num="3" table="kui_order" where="$where" order="id desc"}
                {rs:eof}
                <p>暂无订单</p>
                {/rs:eof}
                <div class="card mb-15">
                    <div class="card-header"><a href="{U('home/other/ordershow','orderid='.$rs[orderid].'')}">订单号：{$rs[orderid]}</a></div>
                    <div class="card-body">
                        <ul>
                            <li>产品名称：{$rs[pro_name]}</li>
                            <li>购买数量：{$rs[pro_num]}</li>
                        </ul>
                    </div>
                    <div class="card-footer row">
                       <div class="col-6">订单金额：<span class="text-red">{$rs[pro_price]}</span></div>
                       <div class="col-6 text-right"> {if $rs[ispay]==0}<span class="badge badge-red">未支付</span>{/if} {if $rs[isover]==0}<span class="badge badge-green ml">未处理</span>{/if}</div>
                    </div>
                </div>
                {/kuicms:rs}
            <div class="page page-center page-mid"><ul>{$showpage}</ul></div>

        </div>
        
    </article>
    {include file="mobile/foot.php"}
	
</body>
</html>