<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>会员中心_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body class="bg-white">
	{include file="mobile/head.php"}

    <article class="user_center">
    	{kuicms:rs top="1" table="kui_user left join kui_user_group on kui_user.uid=kui_user_group.gid" where="id=$userid"}
        <div class="user_info">
            <div class="face"><img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" class="dropzone" id="uface" config="uface" url="{U('face','','',1)}" maxsize="{kuicms[upload_image_max]}" title="修改头像"></div>
            <div class="info">
                <p><span>{get_user_info('uname')}</span>{$welcome}</p>
            </div>
        </div>
        {/kuicms:rs}
    </article>
    
    <div class="mwidth wp">
        <div class="boxs pl pr">
        	{if C('bbs_open')==1}
        	<div class="menu menu-blue">
            	<div class="menu-name">我的社区</div>
            </div>
            <ul class="list mb">
                <li><a href="{U('home/bbs/mytopic','uid='.$userid.'')}"><span class="ui-icon-solution mr text-blue"></span>我的主题</a><span class="arrow"></span></li>
                <li><a href="{U('home/bbs/myreply','uid='.$userid.'')}"><span class="ui-icon-filedone mr text-blue"></span>我的帖子</a><span class="arrow"></span></li>
            </ul>
            {/if}
            <div class="menu menu-blue">
            	<div class="menu-name">个人中心</div>
            </div>
            <ul class="list mb">
                <li><a href="{N('myorder')}"><span class="ui-icon-cart mr text-blue"></span>我的订单</a><span class="arrow"></span></li>
                <li><a href="{N('editemail')}"><span class="ui-icon-mail mr text-blue"></span>修改邮箱</a><span class="arrow"></span></li>
                <li><a href="{N('editpass')}"><span class="ui-icon-lock mr text-blue"></span>修改密码</a><span class="arrow"></span></li>
                {if !(isweixin() && C('api_wx_open')==1)}<li><a href="{N('out')}"><span class="ui-icon-logout mr text-blue"></span>退出登录</a><span class="arrow"></span></li>{/if}
            </ul>
        </div>
    </div>

    {include file="mobile/foot.php"}
    <script src="{WEB_ROOT}public/js/dropzone.js"></script>
    <script>
	$(".dropzone").dropzone(
	{
		maxFiles:1,
		success:function(file,data,that)
		{
			data=jQuery.parseJSON(data);
			this.removeFile(file);
			if(data.state=="success")
			{
				kuicms.success("上传成功");
				$(that).attr("src",data.msg);
				$("#face").attr("src",data.msg);
			}
			else
			{
				kuicms.error("上传失败："+data.msg);
			}
		},
		sending:function(file)
		{
			kuicms.loading("正在上传，请稍等");
		},
		totaluploadprogress:function(progress)
		{
			$.progress((Math.round(progress*100)/100)+"%");
		},
		queuecomplete:function(progress)
		{
			$.progress('close');
		},
		error:function(file,msg)
		{
			kuicms.error(msg);
		}
	});
	</script>

</body>
</html>