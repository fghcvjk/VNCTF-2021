<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>修改邮箱_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body class="bg-white">
	{include file="mobile/head.php"}

    <article>
    	<div class="pl-15 pr-15">
            
            <div class="menu menu-blue mb-20 mt">
            	<div class="menu-name">修改邮箱</div>
            </div>
            {kuicms:rs top="1" table="kui_user left join kui_user_group on kui_user.uid=kui_user_group.gid" where="id=$userid"}
            <form method="post" class="ui-form">
                <div class="form-group">
                    <input type="text" name="email" class="form-ip" value="{$rs[uemail]}" placeholder="请输入邮箱" data-rule="邮箱:required;email;">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-blue btn-block btn-big" value="修改邮箱">
                </div>
            </form>
            {/kuicms:rs}
        </div>
        
    </article>
    {include file="mobile/foot.php"}
	<script>
	$(function()
	{
		$(".ui-form").form(
		{
			type:2,
			align:'bottom-center',
			result:function(form)
			{
				$.ajax(
				{
					type:'post',
					cache:false,
					dataType:'json',
					url:'{THIS_LOCAL}',
					data:$(form).serialize(),
					error:function(e){alert(e.responseText);},
					success:function(d)
					{
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
						}
						else
						{
							kuicms.error(d.msg);
						}  
					}
				});
			}
		});
	})
	</script>
</body>
</html>