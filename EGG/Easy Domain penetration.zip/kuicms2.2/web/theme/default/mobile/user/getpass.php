<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>忘记密码_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body class="bg-white">
	{include file="mobile/head.php"}
    <article>
        <div class="pl-15 pr-15">
        	<div class="menu menu-blue mb-20 mt">
            	<div class="menu-name">忘记密码</div>
            </div>

            <!--表单部分开始-->
            <form method="post" class="ui-form">
                <div class="form-group">
                    <input type="text" name="email" class="form-ip" placeholder="请输入注册时填写的邮箱" data-rule="邮箱:required;email;">
                </div>
                {if kuicms[user_getpass_auth]==1}
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" name="code" id="code" class="form-ip radius-right-none" placeholder="请输入验证码" data-rule="验证码:required;">
                        <div class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></div>
                    </div>
                </div>
                {/if}
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" name="ecode" id="ecode" class="form-ip radius-right-none" placeholder="请输入邮箱验证码" data-rule="邮箱验证码:required;">
                        <button type="button" class="after">发送验证码</button>
                    </div>
                </div>
                <div class="form-group">
                    <input type="password" name="password" id="password" class="form-ip" placeholder="请输入新密码" data-rule="新密码:required;password;">
                </div>
                <div class="form-group">
                    <input type="password" name="repass" class="form-ip" placeholder="请再次输入密码" data-rule="确认密码:required;password;match(password)">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-blue btn-block btn-big" value="修改密码">
                </div>
            </form>
            <!--表单部分结束-->
       </div>    

    </article>
    {include file="mobile/foot.php"}
<script>
$(function()
{
	{if kuicms[user_getpass_auth]==1}
	$("#verify").click(function()
	{
		$(this).attr("src",$(this).attr("src")+"{iif(kuicms[url_mode]==1,"&","?")}rnd="+Math.round());
		$("#code").val("");
	});
	{/if}
	$(".after").click(function(event)
	{
		var that=$(this);
		var email=that.closest("form").find("[name=email]").val();
		if(email=='')
		{
			kuicms.warn('请输入邮箱');
			return false;
		}			
		var code='';
		{if kuicms[user_getpass_auth]==1}
		var code=that.closest("form").find("[name=code]").val();
		if(code=='')
		{
			kuicms.warn('请输入验证码');
			return false;
		}
		{/if}
		$.ajax(
		{
			url:"{U('getpasscode')}",
			type:'post',
			cache:false,
			dataType:'json',
			data:'email='+encodeURIComponent(email)+'&code='+encodeURIComponent(code),
			error:function(e){alert(e.responseText);},
			success:function(d)
			{
				if(d.state=='success')
				{
					that.backtime();
					kuicms.success(d.msg);
				}
				else
				{
					kuicms.error(d.msg);
				}
			}
		});
		
	});
	$(".ui-form").form(
	{
		type:2,
		align:'center',
		result:function(form)
		{
			$.ajax({
				type:'post',
				cache:false,
				dataType:'json',
				url:'{THIS_LOCAL}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){location.href='{N('login')}';},1500);
					}
					else
					{
						{if kuicms[user_getpass_auth]==1}$("#verify").click();{/if}
						kuicms.error(d.msg);
					}
				}
			});
		}
	});
})
</script>
</body>
</html>