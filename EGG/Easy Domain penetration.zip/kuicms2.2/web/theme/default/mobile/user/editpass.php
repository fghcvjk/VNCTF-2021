<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>修改密码_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body class="bg-white">
	{include file="mobile/head.php"}

    <article>
    	<div class="pl-15 pr-15">
            
            <div class="menu menu-blue mb-20 mt">
            	<div class="menu-name">修改密码</div>
            </div>
            
            <form method="post" class="ui-form">
                <div class="form-group">
                    <input type="password" name="oldpass" class="form-ip" placeholder="请输入原密码" data-rule="原密码:required;password;">
                </div>
                <div class="form-group">
                    <input type="password" name="newpass" id="newpass" class="form-ip" placeholder="请输入新密码" data-rule="新密码:required;password;">
                </div>
                <div class="form-group">
                    <input type="password" name="repass" class="form-ip" placeholder="请再次输入新密码" data-rule="确认新密码:required;password;match(newpass)">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-blue btn-block btn-big" value="修改密码">
                </div>
            </form>
            
        </div>
        
    </article>
    {include file="mobile/foot.php"}
	<script>
	$(function()
	{
		$(".ui-form").form(
		{
			type:2,
			align:'bottom-center',
			result:function(form)
			{
				$.ajax(
				{
					type:'post',
					cache:false,
					dataType:'json',
					url:'{THIS_LOCAL}',
					data:$(form).serialize(),
					error:function(e){alert(e.responseText);},
					success:function(d)
					{
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
						}
						else
						{
							kuicms.error(d.msg);
						}  
					}
				});
			}
		});
	})
	</script>
</body>
</html>