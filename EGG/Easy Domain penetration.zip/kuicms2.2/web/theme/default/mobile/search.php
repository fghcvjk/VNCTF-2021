<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{$keyword}_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>
	{include file="mobile/head.php"}
    
    <article>
    	<section>
        	<div class="subject">
                <b>{$keyword}</b>
            </div>
            <div class="clear"></div>
            <ul class="home_news">
                {kuicms:rs pagesize="20" num="3" table="kui_content" where="$where" order="ontop desc,ordnum desc,id desc"}
                <li><span class="date">{date('m-d',$rs[createdate])}</span><div class="right"><a href="{$rs[link]}" title="{$rs[title]}" class="text-hide">{str_replace($keyword,"<font color=red>$keyword</font>",$rs[title])}</a><p class="text-hide">{str_replace($keyword,"<font color=red>$keyword</font>",cutstr(nohtml($rs[intro]),200,1))}</p></div></li>
                {/kuicms:rs}
             </ul>
             <div class="clear"></div>
             <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
        </section>
    </article>
    {include file="mobile/foot.php"}

</body>
</html>