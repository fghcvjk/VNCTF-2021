<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{if strlen($seotitle)>0}{$seotitle}_{/if}{$title}_{kuicms[web_name]}</title>
<meta name="keywords" content="{if strlen($seokey)>0}{$seokey}{else}{$title}{/if}">
<meta name="description" content="{if strlen($seodesc)>0}{$seodesc}{else}{$title}{/if}">
<script src="{WEB_ROOT}public/ueditor/ueditor.config.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.all.min.js"></script>
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	<section>
        	<div class="subject">
                <b>在线提交</b>
            </div>
            <div class="clear"></div>
            <!---->
            <form class="ui-form mt" method="post">
                {foreach $field as $rs}
                <div class="form-group row"{if $rs['field_type']==7} style="display:none;"{/if}>
                    <label class="col-3 col-form-label text-right">{$rs['field_title']}：</label>
                    <div class="col-9{if $rs['field_type']==9} col-form-label{/if}">
                        {switch $rs['field_type']}
                            {case 1}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 2}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip datepick"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}"  readonly {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 3}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 4}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 5}
                            <div class="input-group">
                            <input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip radius-right-none"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            <a class="after dropzone ui-icon-cloud-upload radius-none" config="{$rs['field_key']}" url="{U('upload/upfile','type='.$rs['field_upload_type'].'')}"maxsize="{if $rs['field_upload_type']==1}{C('upload_image_max')}{elseif $rs['field_upload_type']==2}{C('upload_video_max')}{else}{C('upload_file_max')}{/if}" title="上传">上传</a>
                                <a class="after fm-choose ui-icon-select{if $rs['field_upload_type']==1} radius-none{/if}" data-name="{$rs['field_key']}" data-url="{U('upload/imagelist','type='.$rs['field_upload_type'].'&multiple=0')}" data-type="{$rs['field_upload_type']}" data-multiple="0" title="选择">选择</a>
                                {if $rs['field_upload_type']==1}<a class="after lightbox ui-icon-zoomin" data-id="{$rs['field_key']}" data-name="lightbox-{$rs['field_key']}" title="{$rs['field_title']}">预览</a>{/if}
                             
                            </div>
                            {/case}
                            {case 6}<input type="password" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip" value="{deal_default($rs['field_default'])}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 7}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{deal_default($rs['field_default'])}">{/case}
                            {case 8}<textarea name="{$rs['field_key']}" class="form-ip" id="{$rs['field_key']}" rows="3" cols="50" {deal_rule($rs['field_rule'],$rs['field_title'])}>{deal_default($rs['field_default'])}</textarea>{/case}
                            {case 9}
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                                {if $rs['field_radio']==2}<div class="input-group-check">{/if}
                                <label class="radio"><input type="radio" name="{$rs['field_key']}" value="{$data[1]}" {deal_rule($rs['field_rule'],$rs['field_title'],1)} {if $rs['field_default']=="".$data[1].""} checked{/if}>
                                <i></i>{$data[0]}</label>
                                {if $rs['field_radio']==2}</div>{/if}
                            {/foreach}
                            {/case}
                            {case 10}
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                            <label class="checkbox"><input type="checkbox" name="{$rs['field_key']}[]" value="{$data[1]}" {deal_rule($rs['field_rule'],$rs['field_title'],1)} {if stristr(",".$rs['field_default'].",",",".$data[1].",")} checked{/if}><i></i>{$data[0]}</label>
                            {/foreach}
                            {/case}
                            {case 11}
                            <select name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            <option value="">请选择{$rs['field_title']}</option>
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                            <option value="{$data[1]}" {if $rs['field_default']=="".$data[1].""} selected{/if}>{$data[0]}</option>
                            {/foreach}
                            </select>
                            {/case}
                            {case 12}<script id="{$rs['field_key']}" name="{$rs['field_key']}" type="text/plain" style="height:260px;"></script>
                            <script>UE.getEditor('{$rs['field_key']}',{serverUrl:'{U('upload/index')}'{if $rs['field_editor']==1},toolbars:editorOption{/if}});</script>
                            {/case}
                            {case 13}
                            <div class="btn-group mt-sm">
                                <a class="btn-group-item dropzone-more ui-icon-cloud-upload" config="{$rs['field_key']}" url="{U('upload/upfile','type=1&thumb=1&water='.C('water_piclist').'')}" maxsize="{C('upload_image_max')}" title="上传">上传</a>
                                <a class="btn-group-item fm-choose ui-icon-select" data-name="{$rs['field_key']}" data-url="{U('upload/imagelist','type=1&multiple=1')}" data-type="{$rs['field_upload_type']}" data-multiple="1" title="选择">选择</a>
                            </div>
                            <div class="imagelist">
                                <ul id="list_{$rs['field_key']}"></ul>
                            </div>
                            {/case}
                            {case 14}
                            <select name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            {php $table=$rs['field_table']}
                            {php $join=$rs['field_join']}
                            {php $where=$rs['field_where']}
                            {php $order=$rs['field_order']}
                            {php $value=$rs['field_value']}
                            {php $label=$rs['field_label']}
                            {php $default=$rs['field_default']}
                            {if $where==''}
                            {php $where='1=1'}
                            {/if}
                            {if $order==''}
                            {php $order="$value desc"}
                            {/if}
                            <option value="">请选择{$rs['field_title']}</option>
                            {kuicms:ra top="0" table="$table" join="$join" where="$where" order="$order"}
                            <option value="{$ra['.$value.']}"{if $default==$ra['.$value.']} selected{/if}>{$ra['.$label.']}</option>
                            {/kuicms:ra}
                            </select>
                            {/case}
                            {/switch}
                            {if $rs['field_tips']<>''}<span class="input-tips">{$rs['field_tips']}</span>{/if}
                    </div>
                </div>
                {/foreach}
                {if $iscode==1}
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">验证码：</label>
                    <div class="col-9">
                        <div class="input-group">
                        <input type="text" name="code" class="form-ip radius-right-none" id="code" data-rule="验证码:required;">
                        <span class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></span>
                        </div>
                    </div>
                </div>
                {/if}
                <div class="form-group row">
                    <div class="col-9 offset-3">
                        <button type="submit" class="btn btn-blue">提交</button>
                    </div>
                </div>
            </form>
            <!---->
            
        </section>
    </article>
    {include file="mobile/foot.php"}
<script src="{WEB_ROOT}public/js/dropzone.js"></script>
<script src="{WEB_ROOT}public/datepick/laydate.js"></script>
<script>
$(function()
{
	$("#verify").click(function(){
		var img=$(this).attr("src");
		if(img.indexOf('?')>0)
		{
			$(this).attr("src",img+'&random='+Math.random());
		}
		else
		{
			$(this).attr("src",img.replace(/\?.*$/,'')+'?'+Math.random());
		}
		$("#code").val("");
	});
	$(document).on("click",".imagelist .img-left",function(){
		var $li=$(this).parent().parent();
		var $pre=$li.prev("li");
		$pre.insertAfter($li)
	})
	$(document).on("click",".imagelist .img-right",function(){
		var $li=$(this).parent().parent();
		var $next=$li.next("li");
		$next.insertBefore($li);
	});
	$(document).on("click",".imagelist .img-del",function(){
		$(this).parent().parent().remove();
	});

	lay('.datepick').each(function()
	{
		laydate.render(
		{
			elem:this,
		});
	});
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
				type:'post',
				cache:false,
				dataType:'json',
				url:'{U('add','fid='.$fid.'','',1)}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){location.href='{if $backway==1}{U('index','fid='.$fid.'','',1)}{else}{U('add','fid='.$fid.'','',1)}{/if}';},1500);
					}
					else
					{
						{if $iscode==1}$("#verify").click();{/if}
						kuicms.error(d.msg);
					}
				}
			});
		}
	});
});
$(".dropzone").dropzone(
{
	maxFiles: 1,
	success:function(file,data,that)
	{
		data=jQuery.parseJSON(data);
		this.removeFile(file);
		if(data.state=="success")
		{
			kuicms.success("上传成功");
			$("#"+$(that).attr("config")).val(data.msg);
		}
		else
		{
			kuicms.error("上传失败："+data.msg);
		}
	},
	sending:function(file)
	{
		kuicms.loading("正在上传，请稍等");
	},
	totaluploadprogress:function(progress)
	{
		$.progress((Math.round(progress*100)/100)+"%");
	},
	queuecomplete:function(progress)
	{
		$.progress('close');
	},
	error:function(file,msg)
	{
		kuicms.error(msg);
	}
});
$(".dropzone-more").dropzone(
{
	maxFiles:50,
	success:function(file,data,that)
	{
		data=jQuery.parseJSON(data);
        this.removeFile(file);
		if(data.state=="success")
		{
			var name=$(that).attr("config");
			var num=1;
			$("#list_"+name+" li").each(function()
			{
				var max=parseInt($(this).attr("num"));
				if (max>=num)
				{
					num=max+1;
				}
			});
			var html='';
			html+='<li num="'+num+'">';
			html+='	<div class="preview">';
			html+='		<input type="hidden" name="'+name+'['+num+'][image]" value="'+data.msg+'">';
			html+='		<u href="'+data.msg+'" class="lightbox"><img src="'+data.msg+'" /></u>';
			html+='	</div>';
			html+='	<div class="intro">';
			html+='		<textarea name="'+name+'['+num+'][desc]" placeholder="图片描述..."></textarea>';
			html+='	</div>';
			html+='	<div class="action"><a href="javascript:;" class="img-left"><i class="ui-icon-left"></i>左移</a><a href="javascript:;" class="img-right"><i class="ui-icon-right"></i>右移</a><a href="javascript:;" class="img-del"><i class="ui-icon-delete"></i>删除</a></div>';
			html+='</li>';
			$("#list_"+name).append(html);
		}
		else
		{
			kuicms.error("上传失败："+data.msg);
		}
	},
	sending:function(file)
	{
		kuicms.loading("正在上传，请稍等");
	},
	totaluploadprogress:function(progress)
	{
		$.progress((Math.round(progress*100)/100)+"%");
	},
	queuecomplete:function(progress)
	{
		$.progress('close');
	},
	error:function(file,msg)
	{
		kuicms.error(msg);
	}
});
</script>
</body>
</html>