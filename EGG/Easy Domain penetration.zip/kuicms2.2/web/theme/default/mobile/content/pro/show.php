<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{if strlen($seotitle)>0}{$seotitle}_{/if}{$title}_{$catename}_{kuicms[web_name]}</title>
<meta name="keywords" content="{if strlen($seokey)>0}{$seokey}{else}{$title}{/if}">
<meta name="description" content="{if strlen($seodesc)>0}{$seodesc}{else}{$title}{/if}">
{include file="mobile/wxshare.php"}
</head>

<body>
	{include file="mobile/head.php"}
    <article>
    	<section>
            <div class="pro_show">
                {php $piclist=jsdecode($piclist)}
                {if count($piclist)>0}                
                <div class="banner">
                    <div class="carousel" data-arrow="false" data-page="true">
                        <div class="carousel-inner">
                            {php $step=0}
                            {foreach $piclist as $index=>$val}
                            {php $step++}
                            <div class="carousel-item{if $step==1} active{/if}"><a href="{$val['image']}" class="lightbox" title="{$val['desc']}"><img src="{$val['image']}" alt="{$val['desc']}"></a></div>
                            {/foreach}
                        </div>
                    </div>
                </div>

                {/if}
                <h1>{$title}</h1>
                {if $price!=0}
                <div class="price">价格：<span>{$price}</span><em>元</em></div>
                {else}
                <div class="price">价格：<span>面议</span></div>
                {/if}
                {if strlen($intro)>0}
                <div class="intro">
                {$intro}
                </div>
                {else}
                <hr>
                {/if}
                <ul class="attribute">
                    {foreach $field as $key=>$rs}
                    {if !empty($rs)}
                    <li><em>{$key}：</em>{$rs}</li>
                    {/if}
                    {/foreach}
                </ul>
            </div>
        </section>
        {if $price!=0}
        <section>
        	<div class="subject">
                <b>询价订购</b>
            </div>
            <div class="clear"></div>
            <div class="text-center mt mb">
                <button class="btn btn-blue modal-show" data-target="#my-inquiry">我要询价</button>
                <button class="btn btn-yellow ml modal-show" data-target="#my-order">我要订购</button>
            </div>
        </section>
        {/if}
        <section>
        	<div class="subject">
                <b>产品介绍</b>
            </div>
            <div class="clear"></div>
            <div class="news_show">
                <div class="intro">
                    {$content}
                    <div class="clear"></div>
                </div>
                {if count($tagslist)>0}
                <div class="tags"><span class="ui-icon-tags"></span> {foreach $tagslist as $rs}<a href="{$rs['url']}" title="{$rs['name']}" target="_blank">{$rs['name']}</a>{/foreach}</div>
                {/if}
            </div>
        </section>
        {if count($edata)>0}
        <section>
        	<div class="subject">
                <b>规格参数</b>
            </div>
            <div class="clear"></div>
            <div class="pro_show">
                <ul class="extend">
                    {foreach $edata as $key=>$rs}
                    <li><em>{$rs['field_title']}：</em>{if isset($extend[$rs['field_key']])}{$extend[$rs['field_key']]}{/if}</li>
                    {/foreach}
                </ul>
            </div>
        </section>
        {/if}
        {if count($tags)>0}
        <section>
        	<div class="subject">
                <b>相关内容</b>
            </div>
            <div class="clear"></div>
            <div class="home_pro">
            <ul>
               {kuicms:rs top="6" table="kui_model_pro" join="left join kui_content on kui_model_pro.cid=kui_content.id" where="$like" order="ontop desc,ordnum desc,id desc"}
               {rs:eof}暂无资料{/rs:eof}
               <li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,280)}" alt="{$rs[title]}"></div><p class="title">{$rs[title]}</p><p class="price"><span>人气：{$rs[hits]}</span>¥ {$rs[price]}</p></a></li>
               {/kuicms:rs}
             </ul>
             <div class="clear"></div>
        </section>
        {/if}
    </article>
    
    {if $price!=0}
    <div class="modal" id="my-inquiry">
        <div class="modal-header">
            <div class="modal-title">我要询价</div>
            <div class="modal-close rotate">×</div>
        </div>
        <div class="modal-body">
        	<!---->
            <form class="ui-form" id="form_inquiry" method="post">
                <div class="form-group">
                    <input type="text" name="truename" class="form-ip" placeholder="请输入您的姓名" data-rule="姓名:required;">
                </div>
                <div class="form-group">
                    <input type="text" name="mobile" maxlength="11" class="form-ip" placeholder="请输入您的手机号码" data-rule="手机号码:required;mobile;">
                </div>
                <div class="form-group">
                    <textarea name="remark" class="form-ip" rows="5" placeholder="请输入询价内容" data-rule="询价内容:required;"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-blue btn-block btn-big">提交询价</button>
                </div>
            </form>
            <!---->
        </div>
    </div>
    
    <div class="modal" id="my-order">
        <div class="modal-header">
            <div class="modal-title">我要订购</div>
            <div class="modal-close rotate">×</div>
        </div>
        <div class="modal-body">
        	<!---->
            {if kuicms[web_order_login]==1 && USER_ID==0}
            	请先<a href="{N('login')}" class="text-red ml mr">登录</a>或<a href="{N('reg')}" class="text-red ml mr">注册</a>
            {else}
            <form class="ui-form" id="form_order" method="post">
                <div class="form-group">
                    <input type="text" name="truename" class="form-ip" placeholder="请输入您的姓名" data-rule="姓名:required;">
                </div>
                <div class="form-group">
                    <input type="text" name="mobile" maxlength="11" class="form-ip" placeholder="请输入您的手机号码" data-rule="手机号码:required;mobile;">
                </div>
                <div class="form-group">
                    <input type="text" name="pronum" maxlength="6" class="form-ip" placeholder="请输入订购数量" data-rule="订购数量:required;int;">
                </div>
                <div class="form-group">
                    <input type="text" name="address" maxlength="255" class="form-ip" placeholder="请输入收货地址" data-rule="收货地址:required;">
                </div>
                <div class="form-group">
                    <textarea name="remark" class="form-ip" rows="5" placeholder="请输入备注，可以为空"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-blue btn-block btn-big">提交订单</button>
                </div>
            </form>
            {/if}
            <!---->
        </div>
    </div>

    {/if}
    
    {include file="mobile/foot.php"}
    
    {if $price!=0}
    <script>
		$(function()
		{
			$("#form_inquiry").form(
			{
				type:2,
				align:'center',
				result:function(form)
				{
					$.ajax({
						type:'post',
						cache:false,
						dataType:'json',
						url:'{U("home/other/inquiry/","id=".$id."","",1)}',
						data:$(form).serialize(),
						error:function(e){alert(e.responseText);},
						success:function(d)
						{
							if(d.state=='success')
							{
								kuicms.success(d.msg);
								$("#form_inquiry")[0].reset();
								$("#my-inquiry").modal('close');
							}
							else
							{
								kuicms.error(d.msg);
							}
						}
					});
				}
			});
			$("#form_order").form(
			{
				type:2,
				align:'center',
				result:function(form)
				{
					$.ajax({
						type:'post',
						cache:false,
						dataType:'json',
						url:'{U("home/other/order/","id=".$id."","",1)}',
						data:$(form).serialize(),
						error:function(e){alert(e.responseText);},
						success:function(d)
						{
							if(d.state=='success')
							{
								location.href=d.msg;
							}
							else
							{
								kuicms.error(d.msg);
							}
						}
					});
				}
			});
	})
	</script>
    {/if}
   
</body>
</html>