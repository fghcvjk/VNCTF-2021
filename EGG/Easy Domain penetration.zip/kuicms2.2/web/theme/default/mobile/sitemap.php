<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>网站地图_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>
	{include file="mobile/head.php"}

    <article>
    	<section>
        	<div class="subject">
                <b>网站地图</b>
            </div>
            <div class="clear"></div>
            <div class="intro am-padding-top">
            	{kuicms:rp top="0" table="kui_category" where="followid=0 and isshow=1" order="catenum,cateid"}{php $map_sonid=$rp[cateid]}
                <div class="map_one"><a href="{cateurl($rp[cateid])}" title="{$rp[catename]}"{if $rp[isblank]==1}{/if}>{$rp[catename]}</a></div>
                <div class="map_two">
                    {kuicms:rs top="0" table="kui_category" where="followid=$map_sonid and isshow=1" order="catenum,cateid"}
                    <a href="{cateurl($rs[cateid])}" title="{$rs[catename]}"{if $rs[isblank]==1}{/if}>{$rs[catename]}</a>
                    {/kuicms:rs}
                </div>
                {/kuicms:rp}
            </div>
        </section>
        
        
    </article>
    {include file="mobile/foot.php"}

</body>
</html>