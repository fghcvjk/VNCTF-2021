<?php if(!defined('IN_KUICMS')) exit;?><footer><p>版权所有 © 2008-{date('Y')} {kuicms[ct_company]}　<a href="{N('sitemap')}" class="ui-icon-location" title="网站地图"></a></p></footer>

<div class="footnav footnav-bg-black fixed-bottom mwidth">
    <a href="{WEB_ROOT}"><i class="ui-icon-home"></i>首页</a>
    <a href="tel:{kuicms[ct_tel]}"><i class="ui-icon-tel"></i>电话</a>
    <a href="{N('book')}"><i class="ui-icon-message"></i>留言</a>
    <a href="{N('bbs')}"><i class="ui-icon-comment"></i>社区</a>
</div>

<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}theme/default/mobile/js/app.js"></script>