<?php if(!defined('IN_KUICMS')) exit;?>{include file="mobile/top.php"}
<title>{if strlen(kuicms[seo_title])>0}{kuicms[seo_title]}_{/if}{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
{include file="mobile/wxshare.php"}
</head>

<body>

	<header class="header">
    	<div class="fr"><a href="{N('user')}" class="ui-icon-user"></a></div>
    	<div class="fl"><a href="javascript:;" class="ui-icon-list offside-show" data-target="#nav_top"></a></div>
        <div class="logo"><a href="{WEB_ROOT}"><img src="{kuicms[mobile_logo]}" alt="{kuicms[web_name]}" /></a></div>
        <div class="clear"></div>
    </header>
    
    <div class="offside offside-left offside-black" id="nav_top">   
        <ul class="collapse">
            <li><a href="{WEB_ROOT}">网站首页</a></li>
            {kuicms:rp top="0" table="kui_category" where="followid=0 and isshow=1" order="catenum,cateid"}{php $sub_sonid=$rp[cateid]}
            <li class="collapse-menu{if get_sonid_num($rp[cateid])!=0} hasson{/if}">
            	{if get_sonid_num($rp[cateid])!=0}<span class="ui-icon-right"></span>{/if}
            	<a href="{cateurl($rp[cateid])}" title="{$rp[catename]}">{$rp[catename]}</a>
                {if get_sonid_num($rp[cateid])!=0}
                <ul class="collapse-body hide">
                    {kuicms:rs top="0" table="kui_category" where="followid=$sub_sonid and isshow=1" order="catenum,cateid"}
                    <li><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}">{$rs[catename]}</a></li>
                    {/kuicms:rs}
                </ul>
                {/if}
            </li>
            {/kuicms:rp}
        </ul>
    </div>
       
    <div class="mwidth banner">
    	<div class="carousel" data-arrow="false">
            <div class="carousel-inner">
            	{kuicms:rs table="kui_ad" where="akey='mobile' and islock=1"}
                    {php $adlist=jsdecode($rs[datalist])}
                	{php $step=0}
                    {foreach $adlist as $num=>$val}
                    	<div class="carousel-item{if $step==0} active{/if}"><a href="{$val['url']}"><img src="{$val['image']}" alt="{$val['desc']}"></a></div>
                    {php $step++}
                    {/foreach}
                {/kuicms:rs}
            </div>
        </div>
    </div>

    
    <article>
    	       
        <section>
        	<div class="subject">
                <span class="more"><a href="{cateurl(3)}">更多>></a></span><b>推荐产品</b>
            </div>
            <div class="clear"></div>
            <div class="home_pro">
            	<ul>
                	{php $sonid=get_sonid_all(3)}
                	{kuicms:rs top="4" table="kui_model_pro" join="left join kui_content on kui_model_pro.cid=kui_content.id" where="islock=1 and isnice=1 and classid in($sonid)" order="ontop desc,ordnum desc,id desc"}
                	<li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,280)}" alt="{$rs[title]}"></div><p class="title">{$rs[title]}</p><p class="price"><span>人气：{$rs[hits]}</span>{if $rs[price]!=0}¥ {$rs[price]}{else}面议{/if}</p></a></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
            </div>
        </section>
        
        <section>
        	<div class="subject">
                <span class="more"><a href="{cateurl(2)}">更多>></a></span><b>新闻中心</b>
            </div>
            <div class="clear"></div>
            <ul class="home_news">
                {php $sonid=get_sonid_all(2)}
                {kuicms:rs top="6" table="kui_content" where="islock=1 and classid in($sonid)" order="ontop desc,ordnum desc,id desc"}
                <li><span class="date">{date('m-d',$rs[createdate])}</span><div class="right"><a href="{$rs[link]}" title="{$rs[title]}" class="text-hide">{$rs[title]}</a><p class="text-hide">{cutstr(nohtml($rs[intro]),200)}</p></div></li>
                {/kuicms:rs}
             </ul>
             <div class="clear"></div>
        </section>
        
        <section>
        	<div class="subject">
                <span class="more"><a href="{cateurl(4)}">更多>></a></span><b>客户案例</b>
            </div>
            <div class="clear"></div>
            <div class="home_case">
            	<ul>
                	{php $sonid=get_sonid_all(4)}
                    {kuicms:rs top="4" table="kui_content" where="islock=1 and classid in($sonid) and isnice=1" order="ontop desc,ordnum desc,id desc"}
                	<li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,200)}" alt="{$rs[title]}"></div><p class="text-hide">{$rs[title]}</p></a></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
            </div>
        </section>
        
        <section>
            <div class="subject">
                <span class="more"><a href="{cateurl(1)}">更多>></a></span><b>关于我们</b>
            </div>
            <div class="clear"></div>
            <div class="about">
                {block("about")}
            </div>
        </section>

        <section>
        	<div class="subject">
                <span class="more"><a href="{cateurl(5)}">更多>></a></span><b>人才招聘</b>
            </div>
            <div class="clear"></div>
            <div class="job_list">
            	<ul>
                	{php $sonid=get_sonid_all(5)}
                    {kuicms:rs top="4" table="kui_model_job" join="left join kui_content on kui_model_job.cid=kui_content.id" where="islock=1 and classid in($sonid)" order="ontop desc,ordnum desc,id desc"}
                	<li><a href="{$rs[link]}" title="{$rs[title]}">{$rs[title]}</a><div class="money">{$rs[work_money]}<span>{$rs[work_address]}</span></div></li>
                    {/kuicms:rs}
                </ul>
                <div class="clear"></div>
            </div>
        </section>
        
    </article>
    {include file="mobile/foot.php"}
</body>
</html>