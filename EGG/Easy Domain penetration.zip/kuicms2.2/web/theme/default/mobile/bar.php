<?php if(!defined('IN_KUICMS')) exit;?>

<div class="offside offside-right offside-black" id="nav">   
    <ul class="collapse">
        {kuicms:rp top="0" table="kui_category" where="followid=$topid and isshow=1" order="catenum,cateid"}{php $sub_sonid=$rp[cateid]}
        <li class="collapse-menu{if get_sonid_num($rp[cateid])!=0} hasson{/if}">
            {if get_sonid_num($rp[cateid])!=0}<span class="ui-icon-right"></span>{/if}
            <a href="{cateurl($rp[cateid])}" title="{$rp[catename]}">{$rp[catename]}</a>
            {if get_sonid_num($rp[cateid])!=0}
            <ul class="collapse-body hide">
                {kuicms:rs top="0" table="kui_category" where="followid=$sub_sonid and isshow=1" order="catenum,cateid"}
                <li><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}">{$rs[catename]}</a></li>
                {/kuicms:rs}
            </ul>
            {/if}
        </li>
        {/kuicms:rp}
    </ul>
</div>