<?php if(!defined('IN_KUICMS')) exit;?><div class="bg_foot" data-am-scrollspy="{animation:'slide-bottom',repeat:false}">
    	<div class="width footer">
        	{kuicms:rp top="4" table="kui_category" where="followid=0 and isshow=1" order="catenum,cateid"}
            {php $foot_sonid=$rp[cateid]}
        	<div class="left">
                <dl>
                    <dd>{$rp[catename]}</dd>
                    {kuicms:rs top="3" table="kui_category" where="followid=$foot_sonid and isshow=1" order="catenum,cateid"}
                    <dt><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}"{if $rs[isblank]==1} target="_blank"{/if}>{$rs[catename]}</a></dt>
                    {/kuicms:rs}
                </dl>
            </div>
            {/kuicms:rp}
            <div class="left">
                <dl>
                    <dd>联系方式</dd>
                    <dt><p>客服电话：{kuicms[ct_tel]}<br>工作时间：9:00-18:00 (工作日)<br>意见建议：{kuicms[ct_email]}</p></dt>
                </dl>
            </div>
            <div class="search">
            	<form action="{N('search')}" method="get">
                	{if !isempty(kuicms[pathinfo])&&kuicms[url_mode]>1}<input type="hidden" name="s" value="search{kuicms[url_ext]}" />{/if}
                	{if kuicms[url_mode]==1}<input type="hidden" name="c" value="other" /><input type="hidden" name="a" value="search" />{/if}
                	<span>站内搜索：</span><input type="text" name="keyword" placeholder="请输入关键字" /><button type="submit">搜索</button>
                </form>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copyright">{kuicms[ct_company]}　版权所有 © 2008-{date('Y')} Inc.　<a href="http://www.beian.miit.gov.cn" target="_blank">{kuicms[web_icp]}</a>　<a href="{N('sitemap')}">网站地图</a>　{kuicms[count_code]}<div>{runtime()}</div></div>
    </div>
    
    <div class="plug_service">
        <ul>
        	{foreach $plug_service as $key=>$val}
        	<li><a href="http://wpa.qq.com/msgrd?v=3&uin={$val['qq']}&site=qq&menu=yes" target="_blank"><span class="ui-icon-qq"></span>{$val['title']}</a></li>
            {/foreach}
            <li><a href="{N('book')}"><span class="ui-icon-edit"></span>在线留言</a></li>
            {if kuicms[mobile_open]==1&&!isempty(kuicms[mobile_domain])}
            <li><a href="{kuicms[mobile_http]}{kuicms[mobile_domain]}" title="手机站" target="_blank"><span class="ui-icon-mobile"></span>手机站</a></li>
            {/if}
            <li><a href="javascript:;"><span class="ui-icon-tel"></span>客服热线</a><div class="hotline"><b>{kuicms[ct_tel]}</b>工作时间：8：00 - 18：00</div></li>
            {if strlen(kuicms[weixin_qrcode])}<li><a href="javascript:;"><span class="ui-icon-weixin"></span>官方微信</a><div class="weixin_pic"><img src="{kuicms[weixin_qrcode]}" width="200"><p>微信号：<span>{kuicms[weixin_id]}</span></p></div></li>{/if}
            <li class="hover dis ui-backtop" id="backtop"><a href="javascript:;"><span class="ui-icon-top"></span>返回顶部</a></li>
        </ul>
    </div>
    
    <!--[if lt IE 9]>
    <div class="notsupport">
        <h1>:( 非常遗憾</h1>
        <h2>您的浏览器版本太低，请升级您的浏览器</h2>
    </div>
    <![endif]-->
    <script src="{WEB_ROOT}public/js/jquery.js"></script>
    <script src="{WEB_ROOT}public/js/ui.js"></script>
    <script src="{WEB_ROOT}theme/default/js/app.js"></script>