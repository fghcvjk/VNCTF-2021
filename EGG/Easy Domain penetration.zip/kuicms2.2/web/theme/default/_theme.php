<?php
return [
  'title' => '蓝色经典',
  'author' => '极品模板',
  'url' => 'http://www.nicemb.com',
  'image'=>'theme.jpg'
];