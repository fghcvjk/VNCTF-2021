<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{$keyword}_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>站内搜索</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li><a>站内搜索</a></li>
                <li class="active">{$keyword}</li>
            </ul>
        </div>
        
        <h1>{$keyword}</h1>
        
        <ul class="news_list mt20 mb-20">
           {kuicms:rs pagesize="20" table="kui_content" where="$where" order="ontop desc,ordnum desc,id desc"}
           <li><span class="date">{date('d',$rs[createdate])}<em>{date('Y',$rs[createdate])}-{date('m',$rs[createdate])}</em></span><div><a href="{$rs[link]}" title="{$rs[title]}" target="_blank">{str_replace($keyword,"<font color=red>$keyword</font>",$rs[title])}</a>        {str_replace($keyword,"<font color=red>$keyword</font>",cutstr(nohtml($rs[intro]),500,1))}</div></li>
           {/kuicms:rs}
         </ul>
         <div class="clear"></div>
         <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
         
    </div>
    
    {include file="foot.php"}
    
</body>
</html>