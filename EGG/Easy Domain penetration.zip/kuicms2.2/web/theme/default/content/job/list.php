<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{if strlen($catetitle)>0}{$catetitle}_{/if}{$catename}{$filter_key}_{if $page>1}第{$page}页_{/if}{kuicms[web_name]}</title>
<meta name="keywords" content="{if strlen($catekey)>0}{$catekey}{else}{$catename}{/if}">
<meta name="description" content="{if strlen($catedesc)>0}{$catedesc}{else}{$catename}{/if}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>{get_catename($topid)}</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                {foreach $position as $rs}
                <li><a href="{$rs['url']}" title="{$rs['url']}">{$rs['name']}</a></li>
                {/foreach}
                <li>列表</li>
            </ul>
        </div>
        
        <div class="home_nav">
            <ul id="subnav">
                {kuicms:rp top="0" table="kui_category" where="followid=$topid" order="catenum,cateid"}{php $sub_sonid=$rp[cateid]}
                <li{is_active($rp[cateid],$parentid)}><a href="{cateurl($rp[cateid])}" title="{$rp[catename]}">{$rp[catename]}</a><dl>
                    {kuicms:rs top="0" table="kui_category" where="followid=$sub_sonid" order="catenum,cateid"}
                    <dt><a href="{cateurl($rs[cateid])}" title="{$rs[catename]}"{if $rs[isblank]==1} target="_blank"{/if}>{$rs[catename]}</a></dt>
                    {/kuicms:rs}
                </dl></li>
                {/kuicms:rp}
            </ul>
            <div class="clear"></div>
        </div>
        
        {if count($filter)>0&&$isfilter==1}
        <div class="filter">
            {foreach $filter as $rs}
                <dl>
                    <dd>{$rs['field_title']}：</dd>
                    <dt>
                        <a href="{filter_url($cateurl,$classid,deal_filter($filter_data,$rs['field_key'],0))}"{if getint(F('get.'.$rs['field_key'].''),0)==0} class="hover"{/if}>全部</a>
                        {if $rs['field_type']==14}
                        {php $table_=$rs['field_table']}{php $join_=$rs['field_join']}{php $where_=$rs['field_where']}{php $order_=$rs['field_order']}{php $value=$rs['field_value']}{php $label=$rs['field_label']}
						{if $where_==''}{php $where_='1=1'}{/if}
						{if $order_==''}{php $order_="$value desc"}{/if}
                        {kuicms:ra top="0" table="$table_" join="$join_" where="$where_" order="$order_"}
                        <a href="{filter_url($cateurl,$classid,''.deal_filter($filter_data,$rs['field_key'],$ra['.$value.']))}"{if getint(F('get.'.$rs['field_key'].''),0)==$ra['.$value.']} class="hover"{/if}>{$ra['.$label.']}</a>
                        {/kuicms:ra}
                        {else}
                        {php $arr=explode(",",$rs['field_list'])}
                        {foreach $arr as $j=>$key}
                        {php $data=explode("|",$key)}
                        <a href="{filter_url($cateurl,$classid,deal_filter($filter_data,$rs['field_key'],$data[1]))}"{if getint(F('get.'.$rs['field_key'].''),0)==$data[1]} class="hover"{/if}>{$data[0]}</a>
                        {/foreach}
                        {/if}
                    </dt>
                    <div class="clear"></div>
                </dl>
            {/foreach}
        </div>
        {/if}
        
        <table class="table table-border table-hover table-striped mb">
        	<thead class="thead-gray">
                <tr>
                    <th>职位名称</th>
                    <th width="150">工作地点</th>
                    <th width="150">招聘人数</th>
                    <th width="180">薪资待遇</th>
                    <th width="150">发布日期</th>
                </tr>
            </thead>
            <tbody>
            	{kuicms:rs pagesize="$catepage" table="kui_content" join="$join" where="$where" order="ontop desc,ordnum desc,id desc"}
                <tr>
                    <td class="text-left"><a href="{$rs[link]}" title="{$rs[title]}" target="_blank">{$rs[title]}</a></td>
                    <td>{$rs[work_address]}</td>
                    <td>{$rs[work_num]}</td>
                    <td>{$rs[work_money]}</td>
                    <td>{date('Y-m-d',$rs[createdate])}</td>
                </tr>
                {/kuicms:rs}
            </tbody>
        </table>
        
         
        <div class="clear"></div>
         <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
    </div>
    
    {include file="foot.php"}
    
</body>
</html>