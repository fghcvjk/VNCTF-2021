<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{if strlen($seotitle)>0}{$seotitle}_{/if}{$title}_{$catename}_{kuicms[web_name]}</title>
<meta name="keywords" content="{if strlen($seokey)>0}{$seokey}{else}{$title}{/if}">
<meta name="description" content="{if strlen($seodesc)>0}{$seodesc}{else}{$title}{/if}">
</head>

<body>

    {include file="head.php"}

    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>{get_catename($topid)}</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                {foreach $position as $rs}
                <li><a href="{$rs['url']}" title="{$rs['url']}">{$rs['name']}</a></li>
                {/foreach}
                <li>内容</li>
            </ul>
       	</div>
        
        {php $piclist=jsdecode($piclist)}
        <div class="pro_show mt-20">
            <div class="left">
            	{if count($piclist)>0}
                {php $big=reset($piclist)}
            	<div id="zoom_pic" class="zoom"><img src="{$big['image']}" alt="{$big['desc']}" width="500" id="zoom"></div>
                <div class="thumb_pic">
                    <ul>
                    	{php $step=0}
                    	{foreach $piclist as $index=>$val}
                        {php $step++}
                    	<li{if $step==1} class="hover"{/if}><img src="{thumb($val['image'],60,60)}" data-url="{$val['image']}" alt="{$val['desc']}" width="60" height="60"></li>
                        {/foreach}
                    </ul>
                </div>
                {/if}
            </div>
            <div class="right">
            	<h1>{$title}</h1>
                <hr>
                {if strlen($intro)>0}
                <h5>{$intro}</h5>
                <hr>
                {/if}
                <ul class="attribute">
                    {foreach $field as $key=>$rs}
                    {if !empty($rs)}
                    <li><em>{$key}：</em>{$rs}</li>
                    {/if}
                    {/foreach}
                </ul>
                {if $price==0}
                <div class="price">价格：<span>面议</span></div>
                {else}
                <div class="price">价格：<span>{$price}</span><em>元</em></div>
                <div class="action">
                    <button class="btn btn-blue modal-show" data-target="#my-inquiry">我要询价</button>
                    <button class="btn btn-yellow ml modal-show" data-target="#my-order">我要订购</button>
                </div>
                {/if}
                {if count($tagslist)>0}
                <div class="tags"><span class="ui-icon-tags"></span> 标签：{foreach $tagslist as $rs}<a href="{$rs['url']}" title="{$rs['name']}" target="_blank">{$rs['name']}</a>{/foreach}</div>
                {/if}
            </div>
            <div class="clear"></div>
        </div>
        
        <div class="pro_intro">
            <div class="left">
            	<div class="tabs">
                    <ul>
                        <li class="hover"><a href="">推荐产品</a></li>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="plist">
                    <ul>
                        {kuicms:rs top="6" table="kui_model_pro" join="left join kui_content on kui_model_pro.cid=kui_content.id" where="islock=1 and isnice=1" order="ontop desc,ordnum desc,id desc"}
                    	{rs:eof}暂无资料{/rs:eof}
                        <li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,280)}" alt="{$rs[title]}"></div><p>{cutstr($rs[title],20,0)}</p></a></li>
                        {/kuicms:rs}
                    </ul>
                    <div class="clear"></div>
                </div>
                {if count($tags)>0}
                <div class="tabs">
                    <ul>
                        <li class="hover"><a href="">相关产品</a></li>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="plist">
                    <ul>
                    	{kuicms:rs top="6" table="kui_model_pro" join="left join kui_content on kui_model_pro.cid=kui_content.id" where="$like" order="ontop desc,ordnum desc,id desc"}
                    	{rs:eof}暂无资料{/rs:eof}
                        <li><a href="{$rs[link]}" title="{$rs[title]}"><div><img src="{thumb($rs[pic],280,280)}" alt="{$rs[title]}"></div><p>{cutstr($rs[title],20,0)}</p></a></li>
                        {/kuicms:rs}
                    </ul>
                    <div class="clear"></div>
                </div>
                {/if}
            </div>
            <div class="right">
            	<div class="tabs">
                    <ul>
                        <li class="hover"{if count($edata)>0} id="one1" onClick="setTab('one',1,2)"{/if}><a href="javascript:;">产品介绍</a></li>
                        {if count($edata)>0}
                        <li id="one2" onClick="setTab('one',2,2)"><a href="javascript:;">规格参数</a></li>{/if}
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="intro" id="con_one_1">
                    {$content}
                </div>
                <div class="intro dis" id="con_one_2">
                    <ul class="extend">
                        {foreach $edata as $key=>$rs}
                        <li><em>{$rs['field_title']}：</em>{if isset($extend[$rs['field_key']])}{$extend[$rs['field_key']]}{/if}</li>
                        {/foreach}
                    </ul>
                </div>
            </div>
            <div class="clear"></div>
        </div>
        
    </div>
    {if $price!=0}
    <div class="modal" id="my-inquiry">
        <div class="modal-header">
            <div class="modal-title">我要询价</div>
            <div class="modal-close rotate">×</div>
        </div>
        <div class="modal-body">
        	<!---->
            <form class="ui-form" id="form_inquiry" method="post">
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">姓名：</label>
            		<div class="col-9">
                    	<input type="text" name="truename" class="form-ip" placeholder="请输入您的姓名" data-rule="姓名:required;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">手机号码：</label>
            		<div class="col-9">
                    	<input type="text" name="mobile" maxlength="11" class="form-ip" placeholder="请输入您的手机号码" data-rule="手机号码:required;mobile;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">询价内容：</label>
            		<div class="col-9">
                    	<textarea name="remark" class="form-ip" rows="5" placeholder="请输入询价内容" data-rule="询价内容:required;"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right"></label>
            		<div class="col-9">
                    	<button type="submit" class="btn btn-blue">提交询价</button>
                    </div>
                </div>
            </form>
            <!---->
        </div>
    </div>
    
    <div class="modal" id="my-order">
        <div class="modal-header">
            <div class="modal-title">我要订购</div>
            <div class="modal-close rotate">×</div>
        </div>
        <div class="modal-body">
        	<!---->
            {if kuicms[web_order_login]==1 && USER_ID==0}
            	请先<a href="{N('login')}" class="text-red ml mr">登录</a>或<a href="{N('reg')}" class="text-red ml mr">注册</a>
            {else}
            <form class="ui-form" id="form_order" method="post">
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">姓名：</label>
            		<div class="col-9">
                    	<input type="text" name="truename" class="form-ip" placeholder="请输入您的姓名" data-rule="姓名:required;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">手机号码：</label>
            		<div class="col-9">
                    	<input type="text" name="mobile" maxlength="11" class="form-ip" placeholder="请输入您的手机号码" data-rule="手机号码:required;mobile;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">订购数量：</label>
            		<div class="col-9">
                    	<input type="text" name="pronum" maxlength="6" class="form-ip" placeholder="请输入订购数量" data-rule="订购数量:required;int;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">收货地址：</label>
            		<div class="col-9">
                    	<input type="text" name="address" maxlength="255" class="form-ip" placeholder="请输入收货地址" data-rule="收货地址:required;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right">备注：</label>
            		<div class="col-9">
                    	<textarea name="remark" class="form-ip" rows="5" placeholder="请输入备注，可以为空"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-3 col-form-label text-right"></label>
            		<div class="col-9">
                    	<button type="submit" class="btn btn-blue">提交订单</button>
                    </div>
                </div>
            </form>
            {/if}
            <!---->
        </div>
    </div>

    {/if}
    {include file="foot.php"}
    {if $price!=0}
    <script>
		$(function()
		{
			$("#form_inquiry").form(
			{
				type:2,
				align:'center',
				result:function(form)
				{
					$.ajax({
						type:'post',
						cache:false,
						dataType:'json',
						url:'{U("home/other/inquiry/","id=".$id."","",1)}',
						data:$(form).serialize(),
						error:function(e){alert(e.responseText);},
						success:function(d)
						{
							if(d.state=='success')
							{
								kuicms.success(d.msg);
								$("#form_inquiry")[0].reset();
								$("#my-inquiry").modal('close');
							}
							else
							{
								kuicms.error(d.msg);
							}
						}
					});
				}
			});
			$("#form_order").form(
			{
				type:2,
				align:'center',
				result:function(form)
				{
					$.ajax({
						type:'post',
						cache:false,
						dataType:'json',
						url:'{U("home/other/order/","id=".$id."","",1)}',
						data:$(form).serialize(),
						error:function(e){alert(e.responseText);},
						success:function(d)
						{
							if(d.state=='success')
							{
								location.href=d.msg;
							}
							else
							{
								kuicms.error(d.msg);
							}
						}
					});
				}
			});
	})
	</script>
    {/if}
</body>
</html>