<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>{if strlen($seotitle)>0}{$seotitle}_{/if}{$title}_{if $page>1}第{$page}页_{/if}{$catename}_{kuicms[web_name]}</title>
<meta name="keywords" content="{if strlen($seokey)>0}{$seokey}{else}{$title}{/if}">
<meta name="description" content="{if strlen($seodesc)>0}{$seodesc}{else}{$title}{/if}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>{get_catename($topid)}</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
    	
        <div class="bread bread-1">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                {foreach $position as $rs}
                <li><a href="{$rs['url']}" title="{$rs['url']}">{$rs['name']}</a></li>
                {/foreach}
                <li>内容</li>
            </ul>
       	</div>

        <div class="news_show">
            <h1>{$title}</h1>
            <div class="info">作者：{kuicms:rs table="kui_admin" where="adminid=$adminid"}{$rs[penname]}{/kuicms:rs}　日期：{date('Y-m-d',$createdate)}　人气：{$hits}</div>
            <div class="intro">
                {if $view_lever<2}
                    <fieldset>
                        <legend>友情提示</legend>
                        {if $view_lever==0}请先<a href="{N('login')}" class="text-red ml mr">登录</a>或<a href="{N('reg')}" class="text-red ml mr">注册</a>{else}您的账户权限不足，无法查看！{/if}
                    </fieldset>
                {else}
                    {$content}
                {/if}
                <div class="clear"></div>
            </div>
            {if $pagenum>1 && $view_lever>=2}
            <div class="page page-center page-mid"><ul>{pagelist($page,$pagenum)}</ul></div>
            {/if}
            <div class="other">
                <p>你觉得这篇文章怎么样？</p><a title="赞一下" class="digs" data-url="{U('home/other/digs/','id='.$id.'&act=up','',1)}"><span class="ui-icon-like"></span><em>{$upnum}</em></a><a title="踩一下" class="digs"  data-url="{U('home/other/digs/','id='.$id.'&act=down','',1)}"><span class="ui-icon-unlike"></span><em>{$downnum}</em></a>
            </div>
            {if count($tagslist)>0}
            <div class="tags mt-20"><span class="ui-icon-tags"></span> 标签：{foreach $tagslist as $rs}<a href="{$rs['url']}" title="{$rs['name']}" target="_blank">{$rs['name']}</a>{/foreach}</div>
            {/if}
        </div>
        {if count($tags)>0}
        <div class="subject m20">
        	<b>相关内容</b>
        </div>
        <ul class="home_news_list">
           {kuicms:rs top="10" table="kui_content" where="$like" order="ontop desc,ordnum desc,id desc"}
           {rs:eof}暂无资料{/rs:eof}
           <li><span class="date">{date('m-d',$rs[createdate])}</em></span><div><a href="{$rs[link]}" title="{$rs[title]}">{$rs[title]}</a>        {cutstr(nohtml($rs[intro]),100,1)}</div></li>
           {/kuicms:rs}
         </ul>
         <div class="clear"></div>
         {/if}
    </div>
    
    {include file="foot.php"}
    
</body>
</html>