<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>我的订单_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
<style>
.table_list{border:1px solid #eee;width:100%;}
.table_list th{padding:6px 10px;border:1px solid #eee;text-align:center;color:#333;background:#fafafa;font-family:microsoft yahei;font-weight:normal;}
.table_list td{padding:6px 10px;border:1px solid #eee;text-align:center;color:#666;font-family:microsoft yahei;font-size:14px;}
.table_list .textleft{text-align:left;}
.table_list .textleft span{color:#999;margin-left:10px;font-family:宋体;font-size:12px;}
.table_list .textleft span em{color:#06f;font-size:14px;padding:0 5px;}
.table_list td em{font-style:normal;color:#999;}
.table_list a{color:#06f;}
.table_list a:hover{color:#f30;}
</style>
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>我的订单</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
        <div class="bread bread-1">
        	<ul>
                <li><a href="{WEB_ROOT}">首页</a></li>
                <li><a href="{N('user')}">会员中心</a></li>
                <li class="active">我的订单</li>
            </ul>
        </div>
        <div class="user_center mt">
            <div class="lefter">
            	{include file="user/nav.php"}
            </div>
            <div class="righter">
                
                <div class="subject m20 am-animation-slide-bottom">
                    <b>我的订单</b>
                </div>
                <div class="btn-group btn-group-yellow btn-group-bg mb-15">
                    <a class="btn-group-item{if $type==0} active{/if}" href="{N('myorder')}">全部</a>
                    <a class="btn-group-item{if $type==1} active{/if}" href="{N('myorder','','type=1')}">已支付</a>
                    <a class="btn-group-item{if $type==2} active{/if}" href="{N('myorder','','type=2')}">未支付</a>
                </div>

                <table class="table_list">
                    <thead>
                        <tr>
                        	<th width="120">订单号</th>
                            <th>产品名称</th>
                            <th width="70">数量</th>
                            <th width="80">金额</th>
                            <th width="70">付款</th>
                            <th width="70">状态</th>
                            <th width="160">日期</th>
                            <th width="100">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                    {kuicms:rs pagesize="20" table="kui_order" where="$where" order="id desc"}
                    {rs:eof}
                    <tr>
                        <td colspan="8">暂无订单</td>
                    </tr>
                    {/rs:eof}
                    <tr>
                        <td>{$rs[orderid]}</td>
                        <td class="textleft">{$rs[pro_name]}</td>
                        <td>{$rs[pro_num]}</td>
                        <td>{$rs[pro_price]}</td>
                        <td>{iif($rs[ispay]==1,'已支付','<em>未支付</em>')}</td>
                        <td>{iif($rs[isover]==1,'已处理','<em>未处理</em>')}</td>
                        <td>{date('Y-m-d H:i:s',$rs[createdate])}</td>
                        <td><a href="{U('home/other/ordershow','orderid='.$rs[orderid].'')}" target="_blank">查看订单</a></td>
                    </tr>
                    {/kuicms:rs}
                    </tbody>
                </table>
                <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
            </div>
        </div>
        
    </div>
    
    {include file="foot.php"}
</body>
</html>