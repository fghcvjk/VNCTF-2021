<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>修改密码_{if strlen(kuicms[seo_title])>0}{kuicms[seo_title]}_{/if}{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>修改密码</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
        <div class="bread bread-1">
        	<ul>
                <li><a href="{WEB_ROOT}">首页</a></li>
                <li><a href="{N('user')}">会员中心</a></li>
                <li class="active">修改密码</li>
            </ul>
        </div>
        <div class="user_center mt">
            <div class="lefter">
            	{include file="user/nav.php"}
            </div>
            <div class="righter">
                
                <div class="subject m20 am-animation-slide-bottom">
                    <b>修改密码</b>
                </div>
                <form method="post" class="ui-form mt-40">
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">用户名：</label>
                        <div class="col-5">
                            <input type="text" name="username" class="form-ip" value="{get_user_info('uname')}" disabled>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">原密码：</label>
                        <div class="col-5">
                            <input type="password" name="oldpass" class="form-ip" placeholder="请输入原密码" data-rule="原密码:required;password;">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">新密码：</label>
                        <div class="col-5">
                            <input type="password" name="newpass" id="newpass" class="form-ip" placeholder="请输入新密码" data-rule="新密码:required;password;">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">确认新密码：</label>
                        <div class="col-5">
                            <input type="password" name="repass" class="form-ip" placeholder="请再次输入新密码" data-rule="确认新密码:required;password;match(newpass)">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right"></label>
                        <div class="col-5">
                            <input type="submit" class="btn btn-blue" value="修改密码">
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
        
    </div>
    
    {include file="foot.php"}
    <script>
	$(function()
	{
		$(".ui-form").form(
		{
			type:2,
			align:'bottom-center',
			result:function(form)
			{
				$.ajax(
				{
					type:'post',
					cache:false,
					dataType:'json',
					url:'{THIS_LOCAL}',
					data:$(form).serialize(),
					error:function(e){alert(e.responseText);},
					success:function(d)
					{
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
						}
						else
						{
							kuicms.error(d.msg);
						}  
					}
				});
			}
		});
	})
	</script>
</body>
</html>