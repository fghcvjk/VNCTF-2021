<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>修改邮箱_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>修改邮箱</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="width inner_container">
        <div class="bread bread-1">
        	<ul>
                <li><a href="{WEB_ROOT}">首页</a></li>
                <li><a href="{N('user')}">会员中心</a></li>
                <li class="active">修改邮箱</li>
            </ul>
        </div>
        <div class="user_center mt">
            <div class="lefter">
            	{include file="user/nav.php"}
            </div>
            <div class="righter">
                
                <div class="subject m20 am-animation-slide-bottom">
                    <b>修改邮箱</b>
                </div>
                {kuicms:rs top="1" table="kui_user left join kui_user_group on kui_user.uid=kui_user_group.gid" where="id=$userid"}
                <form method="post" class="ui-form mt-40">
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">用户名：</label>
                        <div class="col-5">
                            <input type="text" name="username" class="form-ip" value="{get_user_info('uname')}" disabled>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right">邮箱：</label>
                        <div class="col-5">
                            <input type="text" name="email" class="form-ip" value="{$rs[uemail]}" placeholder="请输入邮箱" data-rule="邮箱:required;email;">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label text-right"></label>
                        <div class="col-5">
                            <input type="submit" class="btn btn-blue" value="修改邮箱">
                        </div>
                    </div>
                </form>
                {/kuicms:rs}
            </div>
        </div>
        
    </div>
    
    {include file="foot.php"}
    <script>
	$(function()
	{
		$(".ui-form").form(
		{
			type:2,
			align:'bottom-center',
			result:function(form)
			{
				$.ajax(
				{
					type:'post',
					cache:false,
					dataType:'json',
					url:'{THIS_LOCAL}',
					data:$(form).serialize(),
					error:function(e){alert(e.responseText);},
					success:function(d)
					{
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
						}
						else
						{
							kuicms.error(d.msg);
						}  
					}
				});
			}
		});
	})
	</script>
</body>
</html>