<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>会员登录_{kuicms[web_name]}</title>
<meta name="keywords" content="{kuicms[seo_key]}">
<meta name="description" content="{kuicms[seo_desc]}">
</head>

<body>

    {include file="head.php"}
    
    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>会员登录</a></li>
                </ul>
            </div>
        	<div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>
    
    <div class="bg_body bg_body_inner">
    	<div class="width">
            <div class="bread bread-1">
                <ul>
                    <li><a href="{WEB_ROOT}">首页</a></li>
                    <li class="active">会员登录</li>
                </ul>
            </div>
    
            <!--会员登录开始-->
            <div class="box-base row min-400">
                <div class="col-8 pl">
                    <!--左侧开始-->
                    <div class="menu menu-blue ">
                        <div class="menu-name">{if $ispai==1}账户绑定{else}会员登录{/if}</div>
                    </div>
                    <div class="pt-40">
                        {if $ispai==1}
                        <div class="api_user"><span>{$api_info.nickname}</span>，请完成账户绑定，如还没有账户，请先完善资料。　【<a href="{U('user/apiout')}">退出</a>】</div>
                        {/if}
                        <!--表单部分开始-->
                        <form method="post" class="ui-form ml-40">
                            <div class="form-group row">
                                <label class="col-2 col-form-label text-right">用户名：</label>
                                <div class="col-5">
                                    <input type="text" name="username" class="form-ip" placeholder="请输入用户名" data-rule="用户名:required;username;">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label text-right">密码：</label>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input type="password" name="password" class="form-ip radius-right-none" placeholder="请输入密码" data-rule="密码:required;password;">
                                        <div class="after"><a href="{N('getpass')}" class="pl pr" tabindex="-1">忘记密码</a></div>
                                    </div>
                                </div>
                            </div>
                            {if kuicms[user_login_auth]==1}
                            <div class="form-group row">
                                <label class="col-2 col-form-label text-right">验证码：</label>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input type="text" name="code" id="code" class="form-ip radius-right-none" placeholder="请输入验证码" data-rule="验证码:required;">
                                        <div class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></div>
                                    </div>
                                </div>
                            </div>
                            {/if}
                            <div class="form-group row">
                                <label class="col-2 col-form-label text-right"></label>
                                <div class="col-5">
                                    <input type="submit" class="btn btn-blue" value="{if $ispai==1}确定绑定{else}登录{/if}">
                                </div>
                            </div>
                        </form>
                        <!--表单部分结束-->
                    </div>
                    <!--左侧结束-->
                </div>
                <div class="col-4 pr pl-40 form-right">
                    <!--右侧开始-->
                    <h3>没有账户？</h3>
                    <a href="{N('reg')}" class="btn btn-yellow">{if $ispai==1}完善资料{else}立即注册{/if}</a>
                    {if $ispai==0 && (kuicms[api_qq_open]==1 || kuicms[api_weibo_open]==1 || kuicms[api_weixin_open]==1)}
                    <div class="quick">
                        <h3>快捷登录</h3>
                        {if kuicms[api_qq_open]==1}<a href="{WEB_URL}{WEB_ROOT}api/login/qq/api.php" title="QQ登录"><span class="ui-icon-qq blue"></span>QQ登录</a>{/if}
                        {if kuicms[api_weibo_open]==1}<a href="{WEB_URL}{WEB_ROOT}api/login/weibo/api.php" title="微博登录"><span class="ui-icon-weibo red"></span>微博登录</a>{/if}
                        {if kuicms[api_weixin_open]==1}<a href="{WEB_URL}{WEB_ROOT}api/login/weixin/api.php" title="微信登录"><span class="ui-icon-weixin green"></span>微信登录</a>{/if}
                    </div>
                    {/if}
                    <!--右侧结束-->
                </div>
            </div>
            <!--会员登录结束-->
        </div>
        
    </div>
    
    {include file="foot.php"}
    <script>
    $(function()
    {
    	{if kuicms[user_login_auth]==1}
    	$("#verify").click(function()
    	{
    		$(this).attr("src",$(this).attr("src")+"{iif(kuicms[url_mode]==1,"&","?")}rnd="+Math.round());
    		$("#code").val("");
    	});
    	{/if}
    	$(".ui-form").form(
    	{
    		type:2,
    		align:'center',
    		result:function(form)
    		{
    			$.ajax({
    				type:'post',
    				cache:false,
    				dataType:'json',
    				url:'{THIS_LOCAL}',
    				data:$(form).serialize(),
    				error:function(e){alert(e.responseText);},
    				success:function(d)
    				{
    					if(d.state=='success')
    					{
    						kuicms.success(d.msg);
    						setTimeout(function(){location.href='{$lasturl}';},1500);
    					}
    					else
    					{
                            {if kuicms[user_login_auth]==1}$("#verify").click();{/if}
    						kuicms.error(d.msg);
    					}
    				}
    			});
    		}
    	});
    })
    </script>
</body>
</html>