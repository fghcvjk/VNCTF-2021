<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>我的回复_{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{$seokey}">
<meta name="description" content="{$seodesc}">
</head>

<body>
	
    {include file="head.php"}

    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>{kuicms[bbs_webname]}</a></li>
                </ul>
            </div>
            <div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>

    <div class="width">
        <div class="bread bread-1 mt">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li><a href="{N('bbs')}">社区首页</a></li>
                <li class="active"><a href="{THIS_LOCAL}">我的回复</a></li>
            </ul>
        </div>
    </div>
    
	<div class="width minheight">
    	<!---->
        <div class="bbs">
            <div class="lefter">                     
                 <div class="box reply">
                 	<div class="title">我的回复</div>
                    
                    
                    <ul class="media-list media-border mb-20">
                    	{kuicms:rs pagesize="15" table="kui_bbs_reply" join="left join kui_user on kui_bbs_reply.userid=kui_user.id" where="kui_bbs_reply.islock=1 and istopic=0 and userid=$uid" order="replyid desc" key="replyid"}
                        <li class="media">
                            <div class="media-img mr-20 radius">
                                <img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" alt="{$rs[uname]}" width="64" height="64" >
                            </div>
                            <div class="media-body">
                                <div class="media-header row align-items-center">
                                    <div class="col-8 font-14">{$rs[uname]}<span class="pl text-gray">{switch ($i+15*($page-1))}{case 1}沙发{/case}{case 2}板凳{/case}{case 3}地板{/case}{default}{$i+15*($page-1)}楼{/switch}</span></div>
                                    <div class="col-4 text-right font-13 text-gray">{formatTime($rs[createdate])}</div>
                                </div>
                                <div class="media-text">
                                    {$rs[content]}
                                    {if $rs[reply]<>''}<div class="line line-left"><span class="text-red">管理员回复：</span></div>{$rs[reply]}</blockquote>{/if}
                                </div>
                            </div>
                        </li>
                        {/kuicms:rs}
                    </ul>

                    {if $pg->totalpage>1}
                    <div class="page page-center page-mid"><ul>{$showpage}</ul></div>
                    {/if}
                 </div>
                 
            </div>

            <div class="righter box">
            	<div class="searchs">
                	<h2>论坛搜索</h2>
                    <form action="{U('home/bbs/search')}" method="get">
                        {if kuicms[url_mode]==1}<input type="hidden" name="c" value="bbs" /><input type="hidden" name="a" value="search" />{/if}
                    	<input type="text" name="keyword" placeholder="请输入关键字"><input type="submit" value="搜索">
                    </form>
                </div>
                
                <div class="topic">
                	<h2>热门主题</h2>
                    <ul>
                    	{kuicms:rs top="20" table="kui_bbs" where="islock=1" order="hits desc,replynum desc,bbs_id desc"}
                    	<li><span{if $i<4} class="hover"{/if}>{substr("0".$i,-2)}</span><a href="{N('bbsshow','','id='.$rs[bbs_id].'')}" title="{$rs[title]}">{$rs[title]}</a></li>
                        {/kuicms:rs}
                    </ul>
                </div>
                
            </div>
        </div>
        <!---->
    </div>
    
    {include file="foot.php"}
    <script>
	$(function(){
		$("#nav_bbs").addClass("hover");
	})
	</script>
</body>
</html>