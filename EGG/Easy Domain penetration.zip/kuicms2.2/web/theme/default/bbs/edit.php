<?php if(!defined('IN_KUICMS')) exit;?>{include file="top.php"}
<title>编辑主题_{if strlen(kuicms[bbs_seotitle])>0}{kuicms[bbs_seotitle]}_{/if}{kuicms[bbs_webname]}</title>
<meta name="keywords" content="{kuicms[bbs_seokey]}">
<meta name="description" content="{kuicms[bbs_seodesc]}">
<script src="{WEB_ROOT}public/ueditor/ueditor.config.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.all.min.js"></script>
</head>

<body>
	
    {include file="head.php"}

    <div class="bg_inner">
        <div class="width banner_inner">
            <div class="left">
                <ul>
                    <li class="hover"><a>{kuicms[bbs_webname]}</a></li>
                </ul>
            </div>
            <div class="right"><span class="am-icon-phone am-icon-fw"></span>{kuicms[ct_tel]}{block("inner_text")}</div>
        </div>
    </div>

    <div class="width">
        <div class="bread bread-1 mt">
        	<ul>
                <li><a href="{$webroot}">首页</a></li>
                <li><a href="{N('bbs')}">社区首页</a></li>
                <li class="active"><a href="{THIS_LOCAL}">编辑主题</a></li>
            </ul>
        </div>
    </div>
    
	<div class="width minheight">
    	<!---->
        <div class="bbs">
            <div class="lefter box">
                <div class="navs">
                	<a href="{THIS_LOCAL}" class="hover">编辑主题</a>
                </div>
                <div class="newpost">
                	 <!---->
                    <form class="ui-form" method="post">
                    <div class="form-group row">
                    	<label class="col-2 col-form-label">标题：</label>
                        <div class="col-10">
                        	<input type="text" name="title" class="form-ip" value="{$title}" size="60" maxlength="50" data-rule="标题:required;">
                        </div>
                    </div>
                    <div class="form-group row">
                    	<label class="col-2 col-form-label">内容：</label>
                        <div class="col-10">
							<script id="content" name="content" type="text/plain" style="height:260px;">{$content}</script>
                            <script>UE.getEditor('content',{serverUrl:'{U('home/upload/index')}',toolbars:editorBbs});</script>
                        </div>
                    </div>
                    {if kuicms[bbs_post_code]==1}
                    <div class="form-group row">
                    	<label class="col-2 col-form-label">验证码：</label>
                        <div class="col-6">
                            <div class="input-group">
                                <input type="text" class="form-ip radius-right-none" name="code" id="code" size="8" maxlength="8" data-rule="验证码:required;">
                                <span class="code"><img src="{U('code')}" height="40" id="verify" title="点击更换验证码"></span>
                            </div>
                        </div>
                    </div>
                    {/if}
                    <div class="form-group row">
                    	<label class="col-2 col-form-label"></label>
                        <div class="col-4">
                            <button type="submit" class="btn btn-blue mr">保存</button>
                            <button type="button" class="btn" onClick="location.href='{PRE_URL}'">返回</button>
                        </div>
                    </div>
                    </form>
                     <!---->
                </div>
                
            </div>
            <div class="righter box">
            	<div class="searchs">
                	<h2>论坛搜索</h2>
                    <form action="{U('home/bbs/search')}" method="get">
                        {if kuicms[url_mode]==1}<input type="hidden" name="c" value="bbs" /><input type="hidden" name="a" value="search" />{/if}
                    	<input type="text" name="keyword" placeholder="请输入关键字"><input type="submit" value="搜索">
                    </form>
                </div>
                
                <div class="topic">
                	<h2>热门主题</h2>
                    <ul>
                    	{kuicms:rs top="20" table="kui_bbs" where="islock=1" order="hits desc,replynum desc,bbs_id desc"}
                    	<li><span{if $i<4} class="hover"{/if}>{substr("0".$i,-2)}</span><a href="{N('bbsshow','','id='.$rs[bbs_id].'')}" title="{$rs[title]}">{$rs[title]}</a></li>
                        {/kuicms:rs}
                    </ul>
                </div>
                
            </div>
        </div>
        <!---->
    </div>
    
    {include file="foot.php"}
<script>
$(function()
{
	$("#nav_bbs").addClass("hover");
	
	$("#verify").click(function(){
		$(this).attr("src",$(this).attr("src")+"{iif(kuicms[url_mode]==1,"&","?")}rnd="+Math.round());
		$("#code").val("");
	});
	
	$(".ui-form").form(
	{
		type:2,
		align:'bottom-center',
		result:function(form)
		{
			var content=UE.getEditor('content').getContent();
			if(content=='')
			{
				toastr.error('内容不能为空');
				return false;	
			}
			$.ajax(
			{
				type:'post',
				cache:false,
				dataType:'json',
				url:'{THIS_LOCAL}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){location.href='{PRE_URL}';},1500);
					}
					else
					{
						kuicms.error(d.msg);
					}  
				}
			});
		}
	});
})
</script>
</body>
</html>