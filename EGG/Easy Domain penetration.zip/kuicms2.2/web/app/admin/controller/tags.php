<?php
/**
 * 作用：标签管理
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

class Tags extends AdminsController
{
	public function index()
	{
		$this->display("module/extend/tags.php");	
	}

	public function del()
	{
		$id=getint(F('get.id'),0);
		if(!APP_DEMO) $this->db->del('kui_tags','id='.$id.'');
		$this->success('删除成功');
		$this->add_log($this->msg);
	}

	public function clear()
	{
		if(!APP_DEMO) $this->db->del('kui_tags','hits<=0');
		$this->success('删除成功');
		$this->add_log($this->msg);
	}

}