<?php
/**
 * 作用：网站设置
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

class Config extends AdminsController
{

	public function index()
	{
		$id=getint(F('get.id'),0);
		if($id==0)
		{
			$rs=$this->db->row("select id from kui_config_group where islock=1 and gkey='0' and types=1 order by ordnum,id limit 1");
			if($rs)
			{
				$id=$rs['id'];
			}
		}
		if(IS_POST)
		{
			$data=$this->db->load("select id,ckey,ctype from kui_config where islock=1 and gid=$id order by ordnum,id");
			if(count($data)==0)
			{
				$this->error('没有数据可保存');
			}
			else
			{
				foreach ($data as $key=>$rs)
				{
					$cid=$rs['id'];
					$var='';
					if($rs['ctype']==7)
					{
						$array=F($rs['ckey']);
						if(is_array($array))
						{
							$var=implode(',',$array);
						}
						unset($array);
					}
					else
					{
						if($rs['ckey']=='count_code')
						{							
							$var=$_POST[$rs['ckey']];
						}
						else
						{
							$var=F($rs['ckey']);
						}	
					}
					if(!APP_DEMO) $this->db->update('kui_config','id='.$cid.'',['cvalue'=>$var]);
				}
				$this->success('保存成功');
				
				$rs=$this->db->load("select ckey,cvalue from kui_config where islock=1 and ctype<9 order by ordnum,id");
				$data=[];
		        foreach ($rs as $c)
		        {
		            $data[strtoupper($c['ckey'])]=$c['cvalue'];
		        }
				$data="<?php\nif(!defined('IN_KUICMS')) exit;\nreturn ".var_export($data, true).";\n?>";
				if(!APP_DEMO) file_put_contents('data/config/config.php', $data);
			}
			$this->add_log($this->msg);
		}
		else
		{
			$this->assign('id',$id);
			$this->display("module/config/config.php");
		}
	}
}