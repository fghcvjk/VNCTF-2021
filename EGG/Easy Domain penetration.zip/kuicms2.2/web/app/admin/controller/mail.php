<?php
/**
 * 作用：邮件模板
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

class Mail extends AdminsController
{
	public function switchs()
	{
		$id=getint(F('get.id'),0);
		$state=getint(F('state'),0);
		$rs=$this->db->row("select id from kui_temp_mail where id=".$id." limit 1");
		if($rs)
		{
			if(!APP_DEMO) $this->db->update('kui_temp_mail','id='.$id.'',['islock'=>$state]);
		}
		$this->success('修改成功');
		$this->add_log($this->msg);	
	}
	
	public function index()
	{
		$this->display("module/theme/mail/index.php");
	}

	public function add()
	{
		if(IS_POST)
		{
			$data=[[F('t0'),'null','标题不能为空']];
			$v=new kuicms_verify($data);
			if($v->result())
			{
				$rs=$this->db->row("select * from kui_temp_mail where title='".F('t0')."' limit 1");
				if($rs)
				{
					$this->error('标题已存在');
				}
				else
				{
					$d['title']=F('t0');
					$d['mail_title']=F('t1');
					$d['mail_content']=isset($_POST['t2'])?$_POST['t2']:'';
					$d['islock']=getint(F('t3'),0);
					$d['mkey']='';
					if(!APP_DEMO) $this->db->add('kui_temp_mail',$d);
					$this->success('添加成功');
				}
			}
			else
			{
				$this->error($v->msg);
			}
			$this->add_log($this->msg);
		}
		else
		{
			$this->display("module/theme/mail/add.php");
		}
	}

	public function edit()
	{
		$id=getint(F('get.id'),0);
		if(IS_POST)
		{
			$data=[[F('t0'),'null','标题不能为空']];
			$v=new kuicms_verify($data);
			if($v->result())
			{
				$d['title']=F('t0');
				$d['mail_title']=F('t1');
				$d['mail_content']=isset($_POST['t2'])?$_POST['t2']:'';
				$d['islock']=getint(F('t3'),0);
				if(!APP_DEMO) $this->db->update('kui_temp_mail','id='.$id.'',$d);
				$this->success('保存成功');
			}
			else
			{
				$this->error($v->msg);
			}
			$this->add_log($this->msg);
		}
		else
		{
			$rs=$this->db->row("select * from kui_temp_mail where id=".$id." limit 1");
			if($rs)
			{
				foreach($rs as $key=>$val)
				{
					$this->assign($key,$val);
				}
				$this->display("module/theme/mail/edit.php");
			}
		}
	}

	public function del()
	{
		$id=getint(F('get.id'),0);
		if(!APP_DEMO) $this->db->del('kui_temp_mail',"id=$id and mkey=''");
		$this->success('删除成功');
		$this->add_log($this->msg);
	}
	
}