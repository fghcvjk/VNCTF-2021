<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>管理首页</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/scroll/jquery.nicescroll.min.js"></script>
<script src="{WEB_ROOT}public/js/highcharts.js"></script>
</head>

<body>
    <div class="position">当前位置：<a href="{THIS_LOCAL}">管理首页</a></div>
    
    <div class="home">
        <div class="count">
            <a class="box" href="{U('bbs/index')}">
                <h3>社区</h3>
                <div class="num">{$data['bbs']['total']}</div>
                <div class="total">待审主题：<span class="red">{$data['bbs']['topic']}</span>　待审帖子：<span class="red">{$data['bbs']['reply']}</span></div>
                <div class="icon icon-1"><span class="ui-icon-file-word"></span></div>
            </a>
            
            <a class="box" href="{U('order/index')}">
                <h3>订单</h3>
                <div class="num">{$data['order']['total']}</div>
                <div class="total">待处理：<span class="red">{$data['order']['num']}</span></div>
                <div class="icon icon-2"><span class="ui-icon-linechart"></span></div>
            </a>
            
            <a class="box" href="{U('inquiry/index')}">
                <h3>询价</h3>
                <div class="num">{$data['inquiry']['total']}</div>
                <div class="total">待处理：<span class="red">{$data['inquiry']['num']}</span></div>
                <div class="icon icon-3"><span class="ui-icon-evaluate"></span></div>
            </a>
            
            <a class="box" href="{U('book/index')}">
                <h3>留言</h3>
                <div class="num">{$data['book']['total']}</div>
                <div class="total">待处理：<span class="red">{$data['book']['num']}</span></div>
                <div class="icon icon-4"><span class="ui-icon-comment"></span></div>
            </a>
        </div>
      
        <div class="row mt-20">
            <div class="col-4">
            <!---->
            <div class="box">
                <div class="subject">服务器环境</div>
                <ul class="list server">
                    {foreach $services as $key=>$val}
                    <li><a><span>{$key}：</span>{$val}</a></li>
                    {/foreach}
                </ul>
            </div>
            <!---->
            </div>
            <div class="col-4">
            	<!---->
                <div class="box">
                    <div class="subject"><a href="http://www.kuicms.com" target="_blank">更多>></a>官方资讯</div>
                    <ul class="list" id="notice">
                    </ul>
                 </div> 
                <!---->
            </div>
            <div class="col-4">
            	<!---->                 
                 <div class="box">   
                    <div class="subject"><a href="{U('loginlog/index')}">更多>></a>登录日志</div>
                    <div class="log">
                        {kuicms:rs top="20" table="kui_admin_login_log" where="$where" order="id desc"}
                        <p><strong><span>{date('Y-m-d H:i',$rs[logindate])}</span>{$rs[loginname]}</strong>{$rs[loginip]}<span>{$rs[loginmsg]}</span></p>
                        {/kuicms:rs}
                    </div>
                </div>
                <!---->
            </div>
        </div>
            
    </div>

    <div class="foottop"></div>
    <div class="copyright"><span>当前版本：{C('version')}</span>Powered By <a href="http://www.kuicms.com" target="_blank">kuicms.com</a> @ 2008-{date('Y')} Inc.</div>
    <script src="http://www.kuicms.com/home/index/notice/"></script>
    <script>
	$(function()
	{
		$(".log").niceScroll({cursorborder:"",cursorcolor:"#7CB5EC"});
	});
	</script>
</body>
</html>