<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>管理首页</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/scroll/jquery.slimscroll.js"></script>
<base target="iframe_body">
</head>

<body>

    <div class="ui-north">
        <div class="logo"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAArCAYAAAA9iMeyAAAMQ0lEQVR4nO2dedQWVR3HPy87KoiILC6IGW4oiEsKlqIYUaahoiR1xOVkZnS0xCULj3rMJZdcjxql4nEv18olIjNCQUHBEAMCN3hVRAQFBAV+/fG9c5557nufZ2ae5X3R5nPOnJnnzp1755lnfnN/250HcnJyStJQbqeZpW2nK3A88BnwV+Btb393YCjQDfgLsCjTWebkVEhDQ9lbPJFWVfbfG5gITAJ2BqbRVDgAlgL/AjoBfwT+BAyssu+cnLpTqYC0Ba4D3gT2BE4BzgFeLXPM28BlwLeB1sBLwH1AzwrPISen7lSiYh0M3AXsCPwK+GWFfZ8K/A74FPgeGllycmpKtSpWVgEZBdzvtr8O/K2q3qEP8LrbPhe4qsr2cnKKaE4BGQE84rYvBz4A3gXuqbDvk5Hd8h5wgys7D/h1he3l5DShuQSkN/CGq38vsA7d4AC7AvMDh7d29dcH9vWNHXM/sAAY7z4PAZ5Nce45OYk0l4BMAb7qtrsDewF3IMGZDeyNBKILGlkATgDaIS8XyMW7ErmCZwL7IMH4EfAPNJJs7dY7IiHMyamK5nDzfpOCcNwDvA/8HQnJDGAAsk02AAfFjjsaOC72eTASjpFIOGYB+wKT3bGR/dEDGJvivNogYY0v3UgQesdmgWN7II9cdVe0OrpS2ffJaQnMDDN7wgoMdGXx5U2371YzOydWvtDMlsU+n2VmE81srZmtMbOtvHY6mdk619YiM2sI9BVf+pvZZ97ylpm1Sziur5m9FzjWzOx6M2uVcHw9l5kVfJ98KbNUS9II0pnC6LEAeDm2bwzwOAXD/YeuPugJvRNSmbq6sg7AiUB74EjgQ6+vj4Gn3fZO6GlejjaBZauEY0CR/u6BY6cBZwEbU7RRLzqT/fvk1JEkAdkBRb9BtsThyB7ZGtkgQ1FM5ExgLbrJQOpXpBoMcOspwHIUUJwc66M1MBc4Crg9Vv7lhHPbECj7OOGYB5Br2WcuUg+rf+RUx2rvc+ToyGkh2iTsj9+ELwOD0IgyGf1wP0ER8ZfQSLLE1d01dtzuwDPAVFe+zOvjXlfnEOD3sfJaG+k/Q/liPh8hwW/JkSPCF9BFyG7LaSGSRpBuFG7oj5AhC4VR4ZVY3WUojQSKn/47u/UxgfbHU7hpe7s+ItZRu6fngcA1JfYdDrxTo36qJbq+jSh9J0nNzKkzSQJyAEoyBA3/Xb39I2Pbv0DBRLx6kV1yKHBxrPwC4JLY5y7AKrc9Ddie5BEuDZ0p2DY+o4AXa9BHLWiPYkPjgO1Q1vNF5HZIi5J0A44Gnkcq0m7ANighcQXS2c8D9nBl5wO3uePaxtro6NYrkRAZChQOc+UPIWHoDOwCTHd9jqYQQ6mGJykIaZzxwIMZ2rkB6BX7/A6yvUJ2S1+UmBnnKYpVSB9DQdIOyOU9zpVfnuEcOyC3fF+gH3KWlGIlOn/f7ok4k4KDpha8iVz7k1CsKwvD0LXpm+GY+eh+qx9mNtvMlprZKDPrY2ZDnfvscAtzqdt/S6zsLld2tld3lZkdFnPJDTKz7mb2DZOLeHqCC29AoP9GK3aLXlPiPCdW4DJc77Wx3kq7hIcE+nwwRR8XmdnG2DGLzaxtyvM73Qou97R0K9PeMxnbSssKMxtTpl9/ebjCfpZYM7h5X0WjxhVIbYq8T1Hm7Wiv/hq3Xhco+9SrOxQFHCOeRzr4FcCXvH1ZiK7Kscgw95mCXNRZ8Sd5lZv09UmgLM1TcyzFdlcr0tlhvwFuQXZcWozyXrvGDG1lYUvgTmT7JXETCjhXQpJHMxVJKtYbbt0HpYf8FpiAVIDZwJ+R2hEZwLPdOm70LnXrmbGyc5EqFTEQ+DFKgY+YmnTyAdogr093wurTYmB4Be02F4uRCz0LJ6H4TYg1FK6/zweE8+TK0UjTB902wOZl6rVBKrTPzRR7O312RveEz2qUzZFEublJtcHMDgoMXRtNKtQIM9vFDYMnmtmFsWHxO7H6J8TKz4h97meKrj8b6ONDM2ufMPSGVKy5ZraZmc0o0eZOCW2WW+Z77c230irWAYH+b0zRxyzvGF9l9JcOZrYy0NfbZnaymW1bxfe9J9DunoF6dyfUa2Vm3zWzjwP19ivT/2mB+jPMrFeW71EtSSrWVJo+yRuA01HcYx5KNGyNZhhGzC6xfTd62kwF5iDV4OBAv2OoLA6yHGUH7+uVGzL0Xm9yxOebI2jqgFiGct3uoPZqkj96QDhgG6+3Ef0mNwbqDQiURYRG0gdoZpd8mmTFo1FSYikOQRHwlUi3bIdUs8hlOxcNsxNdnQkocTHEIuDnSDjapTg3n7aEVbMGNm3VqlKGBMquI50KUgkdA2UhNT1ULzQlYssyfX0QKGv23zBNnOF9YH+URzUMBQE3QykofVydFSiOMQbFO3ZEOU9RmspCCgZkIzJi1yN7YTXSk6eiEen7ro1SsYty9ASuRHrx2d6+S4C3qI3reFMhpMNPDpRtCoTutXIP6ND3OAzNFSo1X+jfKG5Xs1EmSyDuLrdEXIae9gtQTKQr8DWkNo1z+9sjg7wLMianIUN0LeGh+TUUbzk/w3nFae/W41CEfgdv/50oZeYVvhh0CZTVa/SolpAwlEvvWYiSYY/yyg8mrJZHfIKcSaUcF5mo5rU/J7r1behHmYdewtAJ+C/yWj2HhtYt0ZN7HhoxQsLRg0JaStZAUsRGCqqZf2Ejnqap1+WLRLWvctqUOBXdM1noiIKcj1ODa1FpA8ejdIgNyBiM2BUlHj4aK3sURUCT8oq2ohCBX17hecWZhTKHfXoi93RW/GuVFEdoDkLXKaubeFNmGXK4XI7UpywJpUeit+VURRoB2RfZFHEucOsHKPxIw1Fe0xaBNtojG2NkYF9E69h2TYI8wNUoTcZnCNlfDuFn1W6g5QXkP4GyI5r9LOrLanS/9Ucqc2jZC3gscOy3qu08jYAcSHFEegQF99z1bt0B5TzNJJz8NwcZXX+gtOdiVWy7lineIwkL3DkoWTEtH3mfewRrieZKnX8yUHYW2SLqnycakQ3rL3NomtUBNUj0TCMgS1HcoxdKJrzTlb/gFigYRNORNN8aO/4WFCmPBOe8Ev28j9zAac8rLcspLQj3oe+UhgXe566Ufo9XLVTENDyNkgDjbIGcIcdSPlnxi8awQNm71Taaxou1Chm+c9FI0cGVXxmrc4pbj6UgAAPRSHAQErBohBiDMml9Q30N+rH7U3sj+kmU2uCnLjSg7NK+hINgcR6jqU47DuWU+Z6jcv79WvMD5FKP0wvlyy1Gv1uIFcgIXlVif0uzO8XB5yQODZQ9EijLRBoBiW7WuEtxHvCw2+5HIQ05fmN/xWsnsk22BfajOBdrOPJ2zUECUo/39Y5FQU3fWdAbORKS9NWH0MzJfbzyln4J9yTkFr8isG97wnlQEWew6QpIT8KjQlqeIGyXZCKNKhOqE5/otHtsew6KhRyIRpir0QgyiOJo/G5ee9ELHxa7zyFD36dtoKwX5bNfQ7MaQXMoys3VANkVRyAhqYRQzMLHt2uSvk/ElcBphKPPleJPjoPwNU9bL6QVdAqURVRjxy1EcbeqSTOC+MYpFN/gkcr1DpqBGKW3T6eYQUiP70NxKsIAZPifSuHChrwzofOa7ZUto/yFXYAu3E+98lYoSjsYxW5K8S7y6p2ERqP+FHvfypEmu3QKxTZR0veJMwGpVaPQJLa9CU8Ui1hOeWfILIoniEH4Xkhb7y2a/l7lpgysCNRPYgGydW+icB/WD5cRuV0gq3KtmXVx+4e5sqtSZFeOd3WPiZU978owsxfMbIOZtcmSsVnDZfMW6jdf6rRUSxoVawnSv0GTmkBxjZvddjRnPc2TNBqx/unWxyF17Ck0euyPnoBZ5ynUilLTT3P+T0n7bt4eKHp+I0oCvNqVH4eG9QluO0nPbkQqzEikpr3myvdAxn4/il/skJNTFc39/yARFwMXuu1ByO/+kFtfS1MXbivkMRmOXg20C7IzGpDAXYvSVLLm3eTklKWlBAT09wfRmxBHIJfaYGRY+apKR+QOfQ7NRZ7kykejYF1OTl1oSQEBvVzhejQqTCTZtXY7EqyH0VsZ6/VigJwcoOX/5XYRypocioKFM1CqcTzQty1So15EQbnBKA0iF46cTZ5a/U96xN4o+rkEvRmwAQXXeqJ0j/q/aSInJ0a1I0hOTk4Z/gdyxj9T23QruQAAAABJRU5ErkJggg=="></div>
        <div class="user_base">{get_admin_info('penname')}<span class="ui-icon-down"></span>
            <ul>
                <li><a href="javascript:;" class="editpass" data-url="{U('pass')}">修改密码</a></li>
                <li><a href="{U('out')}" target="_parent">退出登录</a></li>
            </ul>
        </div>
        <div class="other_left"><a href="javascript:;" class="ui-icon-Import"></a></div>
        <div class="other_link">
            <ul>
                <li><a href="{WEB_ROOT}" target="_blank">预览网站</a></li>
                <li><a href="http://www.kuicms.com" target="_blank">官方网站</a></li>
                <li><a href="javascript:;" class="bizcode">录入授权码</a></li>
            </ul>
        </div>
    </div>
    
    <div class="ui-body">
        <div class="ui-west">
        	<!---->
            <div class="leftwarp">
                <ul class="accordion">
                    <li class="active">
                        <div class="title"><a href="{THIS_LOCAL}" target="_parent"> 管理首页</a></div>
                    </li>
                    {kuicms:rp top="0" table="kui_admin_menu" where="islock=1 and followid=0 $where" order="ordnum,id" auto="j"}
                    {php $classid=$rp[id]}
                    <li>
                        <div class="title"><a href="javascript:;"> {$rp[title]}<span class="ui-icon-right"></span></a></div>
                        <ul class="sub_nav">
                            {kuicms:rs top="0" table="kui_admin_menu" where="islock=1 and followid=$classid $where" order="ordnum,id"}
                            <li><a href="{get_admin_menu_url($rs[cname],$rs[aname],$rs[dname])}"> {$rs[title]}</a></li>
                            {/kuicms:rs}
                        </ul>
                    </li>
                    {/kuicms:rp}
                </ul>
            </div>
            <!---->
        </div>
        
        <div class="ui-center{if isipad()} ipad{/if}"></div>
        
    </div>

    <script>
	function editbiz()
	{
		$.dialogbox({
			'title':"录入授权码",
			'text':'<div class="mb-15">当前使用的域名：<span style="color:#f30;">{$domain}</span></div>',
			'inputval':'{C("BIZ_ID")}',
			'type':2,
			'width':'450px',
			'align':'',
			'mask':true,
			'okval':'保存授权码',
			'oktheme':'btn-info',
			'ok':function(e)
			{
				var code=e.inputval();
				if(code=='')
				{
					kuicms.error("请输入授权码");
				}
				else
				{
					$.ajax({
						type:'post',
						cache:false,
						dataType:'json',
						url:'{THIS_LOCAL}',
						data:'code='+code,
						error:function(e){alert(e.responseText);},
						success:function(d)
						{
							kuicms.success(d.msg);
							if(d.state=='success')
							{
								setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
							}
						}
					})
				};
			},
			'cancelval':'购买授权码',
			'cancel':function(e)
			{
				location.href='https://www.kuicms.com';
			}
		})
	}
    $(function()
	{
		{if APP_DEMO}
		$.dialog(
		{
			'title':"友情提示",
			'text':"您的账户权限为：只读。<div class='text-red'>您所做的任何修改均不会生效！！！</div>",
			'ok':function(e)
			{
				e.close();
			}
		});
		{/if}
		{if $isbiz==0}
		$.dialog(
		{
			'title':"授权提示",
			'text':'<div style="padding:0 20px;font-size:15px;line-height:30px;"><b style="color:#f30;font-size:18px;font-weight:400;">友情提示：</b><br>您的域名：<span style="color:#f30;">{$domain}</span> 暂未授权。</div><div style="text-align:center;padding:15px;"><button class="btn btn-info btn-block bizcode">录入授权码</button></div>',
			'align':'bottom-right',
			'okval':'录入授权码',
			'mask':false,
			'footer':false,
			'oktheme':'btn-info',
			'ok':function(e)
			{
				e.close();
				$(".bizcode").click();
			}
		});
		{/if}
		$(".bizcode").click(function()
		{
			//关闭所有窗口
			$.dialogclose();
			editbiz();
		});

        $(".user_base").hover(function(){
            $("ul",this).css("display","block");},
            function(){$("ul",this).css("display","none");
        });
		var Accordion=function(el,multiple)
        {
            this.el=el||{};
            this.multiple=multiple||false;
            var links=this.el.find('.title');
            links.on('click',{el:this.el,multiple:this.multiple},this.dropdown)
        }
        Accordion.prototype.dropdown = function(e)
        {
            var $el=e.data.el;
			$this=$(this),
			$next=$this.next();
			$next.slideToggle();
			$this.parent().toggleClass('active');
			$this.parent().siblings(".active").removeClass("active");
			if (!e.data.multiple)
			{
				$el.find('.sub_nav').not($next).slideUp();
			};
        }
        var accordion = new Accordion($('.accordion'), false);
		 $('.sub_nav li').bind('click', function(){
            $('.sub_nav li').removeClass('hover');
            $(this).addClass('hover');
        });
		//模拟滚动条
		$(".leftwarp").slimscroll({height:"auto",size:"5px",color:"#9CABC3",opacity:0.6,wheelStep:5,touchScrollStep:50})
        $(".ui-center").html('<iframe name="iframe_body" src="{U('right')}" width="100%" height="100%" frameborder="0"></iframe>');
		$(".other_left a").click(function()
		{
			if($(".ui-body").hasClass("ui-mobile"))
			{
				$(".ui-body").removeClass("ui-mobile");
			}
			else
			{
				$(".ui-body").addClass("ui-mobile");
			}
		})
		$(".editpass").click(function()
		{
			var url=$(this).attr("data-url");
			$.dialogbox(
			{
				'title':"修改密码",
				'text':url,
				'width':'450px',
				'height':'230px',
				'type':3,
				'oktheme':'btn-info',
				'ok':function(e)
				{
					e.iframe().contents().find("#kuicms-submit").click();
				}
			});
		});
    })
    </script>
</body>
</html>