<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>编辑分类</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：社区管理 > <a href="{U('index')}">社区分类</a> > <a href="{THIS_LOCAL}">编辑分类</a></div>
    <div class="border">
        <!---->
        <form class="ui-form" method="post">
            <div class="form-group row">
                <label class="col-2 col-form-label">分类名称：</label>
                <div class="col-4">
                    <input type="text" name="t0" class="form-ip" value="{$catename}" placeholder="请输入分类名称" data-rule="分类名称:required;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">优化标题：</label>
                <div class="col-4">
                    <input type="text" name="t1" class="form-ip" value="{$seotitle}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">关键字：</label>
                <div class="col-4">
                    <input type="text" name="t2" class="form-ip" value="{$seokey}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">描述：</label>
                <div class="col-4">
                    <textarea name="t3" class="form-ip" rows="3" cols="50">{$seodesc}</textarea>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">查看权限：</label>
                <div class="col-4">
                	{if strlen($view_group)}
                		{php $view_data=jsdecode($view_group)}
                    {else}
                    	{php $view_data=[]}
                    {/if}
                    {kuicms:rs top="0" table="kui_user_group" order="ordnum,gid"}
                    <label class="checkbox"><input type="checkbox" name="t6[]" value="{$rs[gid]}" {if in_array($rs[gid],$view_data)} checked{/if}><i></i>{$rs[gname]}</label>
                    {/kuicms:rs}
                    <span class="input-tips">如果未勾选，则所有人都可以查看帖子</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">发帖权限：</label>
                <div class="col-4">
                	{if strlen($post_group)}
                		{php $post_data=jsdecode($post_group)}
                    {else}
                    	{php $post_data=[]}
                    {/if}
                    {kuicms:rs top="0" table="kui_user_group" order="ordnum,gid"}
                    <label class="checkbox"><input type="checkbox" name="t7[]" value="{$rs[gid]}" {if in_array($rs[gid],$post_data)} checked{/if}><i></i>{$rs[gname]}</label>
                    {/kuicms:rs}
                    <span class="input-tips">如果未勾选，则所有用户均可发帖</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">回帖权限：</label>
                <div class="col-4">
                	{if strlen($reply_group)}
                		{php $reply_data=jsdecode($reply_group)}
                    {else}
                    	{php $reply_data=[]}
                    {/if}
                    {kuicms:rs top="0" table="kui_user_group" order="ordnum,gid"}
                    <label class="checkbox"><input type="checkbox" name="t8[]" value="{$rs[gid]}"  {if in_array($rs[gid],$reply_data)} checked{/if}><i></i>{$rs[gname]}</label>
                    {/kuicms:rs}
                    <span class="input-tips">如果未勾选，则所有用户均可回帖</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">排序：</label>
                <div class="col-4">
                    <input type="text" name="t4" class="form-ip" value="{$ordnum}">
                    <span class="input-tips">数字越小越靠前</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">状态：</label>
                <div class="col-4">
                    <label class="radio"><input type="radio" name="t5" id="t5_1" value="1"{if $isshow==1} checked{/if}><i></i>启用</label>
                    <label class="radio"><input type="radio" name="t5" id="t5_2" value="0"{if $isshow==0} checked{/if}><i></i>锁定</label>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label"></label>
                <div class="col-4">
                    <button type="submit" class="btn btn-info mr">保存</button>
                    <button type="button" class="btn ui-back">返回</button>
                </div>
            </div>
        </form>
        <!---->
    </div>

<script>
$(function()
{
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>