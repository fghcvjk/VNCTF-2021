<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>模板管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：模板插件 > <a href="{THIS_LOCAL}">模板管理</a></div>
    <div class="border">
        <!---->
        <div class="form-subject">模板管理</div>
        <div class="piclist piclist-col-4 piclist-1-1 piclist-100">
        	{foreach $folder as $key=>$val}
            {php list($name,$key,$info)=$val}
            <div class="piclist-item">
                <div class="piclist-image"><a href="{U('lists','root='.$key.'')}"><img src="{WEB_ROOT}theme/{$val[0]}/{$info['image']}" alt="{$info['title']}"  class="tips" data-align="top" data-title="点击管理模板文件"></a>{if $name==C('theme_dir')}<em class="bg-yellow">使用中</em>{/if}</div>
                <div class="piclist-body">
                        <div class="piclist-flex">
                            <div class="piclist-price"><div>{$info['title']}</div><div>作者：<a href="{$info['url']}" target="_blank">{$info['author']}</a></div></div>
                            <div class="action">
                                  <a href="javascript:;" config="{$name}" class="apply btn btn-blue">应用模板</a>
                            </div>
                        </div>
                </div>
            </div>
            {/foreach}
            <div class="piclist-item">
                <div class="piclist-image"><a href="Https://www.kuicms.com/template.html" target="_blank"><img src="{WEB_ROOT}public/admin/images/more.gif" /></a></div>
                <div class="piclist-body">
                    <div class="piclist-title text-hide"></div>
                        <div class="piclist-flex">
                        	<div class="piclist-price"><div>模板中心</div><div>作者：Kuicms</div></div>
                            <div class="action"><a href="https://www.kuicms.com/themes/" target="_blank" class="btn btn-yellow">更多模板</a></div>
                        </div>
                </div>
            </div>

        </div>
        
        <!---->
    </div>
<script>
$(function()
{
	$(".apply").click(function()
	{
		var e=$(this);
		var config=$(this).attr("config");
		$.dialog(
		{
			'title':"模板应用",
			'text':'确定要使用此模板？',
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
					type:'post',
					url:'{U("config")}',
					data:'config='+encodeURIComponent(config),
					dataType:'json',
					success:function(d)
					{
						e.close();
						if(d.state=='success')
						{
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
						}
						else
						{
							kuicms.error(d.msg);
						}
					}
				});
			}
		});
	});
})
</script>
</body>
</html>