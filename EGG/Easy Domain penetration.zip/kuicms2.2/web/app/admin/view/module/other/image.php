<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>附件选择</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/js/dropzone.js"></script>
<script src="{WEB_ROOT}public/admin/js/base.js"></script>
</head>

<body class="bg-white">

 <div class="borders">

    <div class="tabs" data-href="1">
            <div class="tabs-header-nav">
                <ul class="tabs-nav">
                	{if $iseditor==0}
                    <li class="active"><a href="{THIS_LOCAL}">附件选择</a></li>
                    {else}
                    <li{if $type==0} class="active"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type=0&iseditor='.$iseditor.'&islocal='.$islocal.'')}">全部文件</a></li>
                    <li{if $type==1} class="active"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type=1&iseditor='.$iseditor.'&islocal='.$islocal.'')}">图片文件</a></li>
                    <li{if $type==2} class="active"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type=2&iseditor='.$iseditor.'&islocal='.$islocal.'')}">视频文件</a></li>
                    <li{if $type==3} class="active"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type=3&iseditor='.$iseditor.'&islocal='.$islocal.'')}">其他文件</a></li>
                    {/if}
                </ul>
                <div class="tabs-header-more"><a href="javascript:;" class="dropzone btn btn-info" config="piclist" url="{U('upload/upfile','type=3&gid='.$gid.'&iseditor='.$iseditor.'&islocal='.$islocal.'')}" maxsize="{C('upload_file_max')}">上传文件</a></div>
            </div>
            
        </div>
        
        <div class="row mt-15 mb">
        	<div class="filelist-left">
            	<ul>
                	<li{if $gid==0} class="actice"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type='.$type.'&iseditor='.$iseditor.'&islocal='.$islocal.'')}"><span>{$total}</span>未分组</a></li>
                    {kuicms:rs top="0" field="aid,gname,(select count(1) from kui_attachment where gid=a.aid $where_query) as num" table="kui_attachment_group a" where="islock=1" order="ordnum,aid"}
                    <li{if $gid==$rs[aid]} class="actice"{/if}><a href="{U('imagelist','multiple='.$multiple.'&type='.$type.'&iseditor='.$iseditor.'&islocal='.$islocal.'&gid='.$rs[aid].'')}"><span>{$rs[num]}</span>{$rs[gname]}</a></li>
                    {/kuicms:rs}
                </ul>
            </div>
            <div class="filelist-right">
            	<!---->
                 <div class="piclist piclist-16-9 piclist-col-4" id="list">
                 	<div id="list_pre"></div>
                 	{kuicms:rs pagesize="20" table="kui_attachment" where="$where" order="$order"}
                    {rs:eof}
                        <div class="pt pl font-14 nothing">暂无文件</div>
                    {/rs:eof}
                    <div class="piclist-item" data-url="{$rs[file_url]}" title="{$rs[file_name]}">
                        <div class="piclist-image{if $rs[file_type]>1} file-preview file-type-{trim($rs[file_ext],".")}{/if}">
                        {if $rs[file_type]==1}
                            <a><img src="{$rs[file_url]}" /></a>
                        {else}
                        	<a></a>
                        {/if}
                        </div>
                        <div class="piclist-body">
                            <div class="piclist-title text-hide">{$rs[file_name]}</div>
                        </div>
                    </div>
                	{/kuicms:rs}
                </div>
            	<!---->
            </div>
        </div>

        {if $total_rs!=0}
        <div class="page page-center page-info mt">
            <ul>{$showpage}</ul>
        </div>
        {/if}

 	<input type="hidden" id="piclist">
    
</div>

<script>
$(function()
{
	$(document).on("click","#list .piclist-item",function()
	{
		var val=$(this).attr("data-url");
		{if $multiple==0}
		$("#list .piclist-item").each(function()
		{
			$(this).removeClass("hover");
		})
		{/if}
		$(this).toggleClass("hover");
		choose();
	});
});
function choose()
{
	var str='';
	$("#list .piclist-item").each(function(){
		var val=$(this).attr("data-url");
		if($(this).hasClass("hover"))
		{
			if(str!='')
			{
				str=str+'|';
			}
			str=str+val;
		}
	})
	$('#piclist').val(str);
}
$(".dropzone").dropzone(
{
	maxFiles:{if $multiple==0}1{else}50{/if},
	success:function(file,data,that)
	{
		data=jQuery.parseJSON(data);
        this.removeFile(file);
		if(data.state=="success")
		{
			var url=data.msg;
			var name=url.substr(url.lastIndexOf('/') + 1);
			var filetype=name.substr(name.lastIndexOf('.') + 1);
			var html='';
			if("png|jpg|jpeg|gif|bmp".indexOf(filetype) != -1 )
			{
				html='<div class="piclist-item hover" data-url="'+url+'" title="'+name+'"><div class="piclist-image"><a><img src="'+url+'" /></a></div><div class="piclist-body"><div class="piclist-title text-hide">'+name+'</div></div>';
			}
			else
			{
				html='<div class="piclist-item hover" data-url="'+url+'" title="'+name+'"><div class="piclist-image file-preview file-type-'+filetype+'"><a></a></div><div class="piclist-body"><div class="piclist-title text-hide">'+name+'</div></div>';
			}
			{if $multiple==0}
				$("#list .piclist-item").removeClass("hover");
			{/if}
			$("#list_pre").append(html);
			$(".nothing").remove();
			choose();
		}
		else
		{
			kuicms.error("上传失败："+data.msg);
		}
	},
	sending:function(file)
	{
		kuicms.loading("正在上传，请稍等");
	},
	totaluploadprogress:function(progress)
	{
		$.progress((Math.round(progress*100)/100)+"%");
	},
	queuecomplete:function(progress)
	{
		$.progress('close');
	},
	error:function(file,msg)
	{
		kuicms.error(msg);
	}
});
</script>
</body>
</html>