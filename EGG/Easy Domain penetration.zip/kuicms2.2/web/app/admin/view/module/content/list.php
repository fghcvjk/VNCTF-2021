<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>内容管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：<a href="{U('lists')}">内容管理</a>{if $classid>0}{get_content_postion($classid)}{/if}</div>
    <div class="border">
        <!---->
        <div class="navbar">
            <div class="lefter">
                {if $classid>0}
                <a href="{U('add','classid='.$classid.'')}" class="btn btn-info mr-sm">添加内容</a>
                {/if}
                
                <a href="javascript:;" class="btn btn-info dropdown-show mr-sm" data-target="#dropdown-1">批量操作</a>
                <div class="dropdown" id="dropdown-1">
                    <a href="javascript:;" class="dropdown-item btach" type="1">设为发布</a>
                    <a href="javascript:;" class="dropdown-item btach" type="2">设为草稿</a>
                    <div class="dropdown-line"></div>
                    <a href="javascript:;" class="dropdown-item btach" type="3">设为推荐</a>
                    <a href="javascript:;" class="dropdown-item btach" type="4">取消推荐</a>
                    <div class="dropdown-line"></div>
                    <a href="javascript:;" class="dropdown-item btach" type="5">设为置顶</a>
                    <a href="javascript:;" class="dropdown-item btach" type="6">取消置顶</a>
                    <div class="dropdown-line"></div>
                    {if $classid>0}<a href="javascript:;" class="dropdown-item move">批量移动</a>{/if}
                    <a href="javascript:;" class="dropdown-item btach" type="7">放入回收站</a>
                </div>
                <span class="btn-group btn-group-yellow btn-group-bg">
                    <a class="btn-group-item{if $type==0} active{/if}" href="{U('lists','classid='.$classid.'&type=0')}">全部</a>
                    <a class="btn-group-item{if $type==1} active{/if}" href="{U('lists','classid='.$classid.'&type=1')}">草稿</a>
                    <a class="btn-group-item{if $type==2} active{/if}" href="{U('lists','classid='.$classid.'&type=2')}">已发</a>
                </span>
            </div>
            
            <div class="righter">
                <form action="{THIS_LOCAL}">
                    <div class="form-group">
                        <div class="input-group">
                            {if kuicms[url_mode]==1}
                                <input type="hidden" name="m" value="{C('ADMIN')}" />
                                <input type="hidden" name="c" value="content" />
                                <input type="hidden" name="a" value="lists" />
                                <input type="hidden" name="type" value="{$type}">
                            {/if}
                            <input type="text" name="keyword" class="form-ip radius-right-none" value="{$keyword}" placeholder="请输入关键字">
                            <button type="submit" class="after"><div class="ui-icon-search"></div></button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    
        <form method="post" class="ui-form">
        <table class="table table-border table-hover table-striped mb">
            <thead class="thead-gray">
                <tr>
                    <th width="30" height="30"><label class="checkbox tips" data-align="right-top" data-title="全选/取消"><input type="checkbox" class="checkall" value=""><i></i></label></th>
                    <th width="80">排序</th>
                    <th>标题</th>
                    <th width="150">栏目名称</th>
                    <th width="50">人气</th>
                    <th width="50">缩图</th>
                    <th width="50">外链</th>
                    <th width="50">置顶</th>
                    <th width="50">推荐</th>
                    <th width="50">状态</th>
                    <th width="100">操作</th>
                </tr>
            </thead>
            <tbody>
            {kuicms:rs pagesize="20" table="kui_content" where="$where" order="ontop desc,ordnum desc,id desc"}
            {rs:eof}
            <tr>
                <td colspan="11">暂无数据</td>
            </tr>
            {/rs:eof}
            <tr>
                <td><label class="checkbox"><input type="checkbox" name="id" value="{$rs[id]}"><i></i></label></td>
                <td><input type="hidden" name="mid[]" value="{$rs[id]}"><input type="text" class="form-ip" name="ordnum[]" id="ordnum_{$rs[id]}" value="{$rs[ordnum]}" data-rule="required;int;"></td>
                <td class="text-left"><a href="{$rs[link]}" target="_blank" title="查看">{$rs[title]}</a> {if $rs[isauto]==1}<span class="ui-icon-reloadtime text-yellow" title="定时发布：{date('Y-m-d H:i:s',$rs[createdate])}"></span>{/if}</td>
                <td><a href="{geturl($rs[classid],0)}">{get_catename($rs[classid])}</a></td>
                <td>{$rs[hits]}</td>
                <td>{iif($rs[ispic]==1,"是","<em>否</em>")}</td>
                <td>{iif($rs[isurl]==1,"是","<em>否</em>")}</td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs[ontop]==1} checked{/if} data-url="{U('switchs','type=1&id='.$rs[id].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs[isnice]==1} checked{/if} data-url="{U('switchs','type=2&id='.$rs[id].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs[islock]==1} checked{/if} data-url="{U('switchs','type=3&id='.$rs[id].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><a href="javascript:;" class="copy" data-url="{U('copy',"classid=".$rs[classid]."&id=".$rs[id]."")}" title="复制"><span class="ui-icon-file-copy"></span></a>　<a href="{U('edit',"classid=".$rs[classid]."&id=".$rs[id]."")}" title="编辑"><span class="ui-icon-edit"></span></a>　<a href="javascript:;" class="del" data-url="{U('del','classid='.$classid.'&id='.$rs[id].'')}" title="删除"><span class="ui-icon-delete"></span></a></td>
            </tr>
            {/kuicms:rs}
            </tbody>
        </table>
        {if $total_rs!=0}
        <div class="page page-right page-info">
            <div class="page-other"><button type="submit" class="btn btn-yellow">保存排序</button></div>
            <div class="page-list"><ul>{$showpage}</ul></div>
        </div>
        {/if}
        </form>
        <!---->
    </div>
<script>
$(function()
{
	$('.switch input[type=checkbox]').on('click',function()
	{
		var url=$(this).attr("data-url");
		var result=($(this).is(':checked'))?1:0;
		$.ajax(
		{
			url:url,
			type:"post",
			dataType:'json',
			data:"state="+result,
			error:function(e){alert(e.responseText);},
			success:function(d)
			{
				if(d.state=='success')
				{
					kuicms.success(d.msg);
				}
				else
				{
					kuicms.error(d.msg);
				}
			}
		});
	});
	$(".btach").click(function()
	{
		var type=$(this).attr("type");
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条内容');
        }
        else
        {
            $.ajax(
			{
                type:'get',
                cache:false,
                dataType:'json',
                url:'{U("btach")}{iif(kuicms[url_mode]==1,"&","?")}id='+data.join(",")+'&type='+type,
                data:"",
                error:function(e){alert(e.responseText);},
                success:function(d)
				{
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
        }
    });
	
    $(".move").click(function()
	{
        var type=$(this).attr("type");
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条内容');
        }
        else
        {
			var list=data.join(",");
			$.dialogbox(
			{
				'title':"批量移动",
				'text':'{U('tree','classid='.$classid.'')}',
				'width':'500px',
				'height':'370px',
				'type':3,
				'oktheme':'btn-info',
				'ok':function(e)
				{
					var t0=e.iframe().contents().find("#go").val();
					if(t0=='')
                    {
                        kuicms.error('请选择目标栏目');
                        return false;
                    }
					$.ajax(
					{
                         type:'post',
                         url:'{U("move")}',
                         dataType:'json',
                         data:'id='+list+'&go='+t0,
                         error:function(e){alert(e.responseText);},
                         success:function(d)
						 {
                            if(d.state=='success')
                            {
								e.close();
                                kuicms.success(d.msg);
                                setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                            }
                            else
                            {
                                kuicms.error(d.msg);
                            }
                        }
                    });
				}
			});
        }
    });
	
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{U("order","classid=".$classid."")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
	
	$(".copy").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要复制此内容？",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
	
	$(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要放入回收站？",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>