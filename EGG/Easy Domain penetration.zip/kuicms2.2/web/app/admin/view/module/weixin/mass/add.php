<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>新建群发</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/admin/js/base.js"></script>
</head>

<body>
    <div class="position">当前位置：微信公众号 > <a href="{U('index')}">群发管理</a> > <a href="{THIS_LOCAL}">新建群发</a></div>
    <div class="border">
        <!---->
        <div class="form-subject">新建群发</div>
        <form class="ui-form" method="post">
            <div class="form-group row">
                <label class="col-2 col-form-label">消息类型：</label>
                <div class="col-4">
                    <select name="t1" id="t1" class="form-ip" data-rule="消息类型:required;">
                    	<option value="">请选择消息类型</option>
                        <option value="1">文本消息</option>
                        <option value="2">图文素材</option>
                    </select>
                </div>
            </div>
            <div class="form-group row dis" id="reply_content">
                <label class="col-2 col-form-label">消息内容：</label>
                <div class="col-4">
                    <textarea name="t2" rows="5" class="form-ip" data-rule="消息内容:required;"></textarea>
                </div>
            </div>
            <div class="form-group row dis" id="reply_id">
                <label class="col-2 col-form-label">素材选择：</label>
                <div class="col-4">
                	<div class="btn-group">
                        <a class="btn-group-item" href="javascript:;" id="select_master" data-name="t3" data-url="{U('all')}">选择素材</a>
                        <a class="btn-group-item" href="javascript:;" id="delete_master" data-name="t3">清空素材</a>
                    </div>
                    <input type="hidden" name="t3" id="t3" value="0">
                    <div class="master_box">
                    </div>
                </div>
            </div>
            <div class="form-group row">
            	<label class="col-2 form-label"></label>
                <div class="col-4">
                    <button type="submit" id="kuicms-submit" class="btn btn-info">执行</button>
                    <button type="button" class="btn ui-back">返回</button>
                </div>
            </div>
        </form>
        <!---->
    </div>

<script>
$(function()
{
	$("#t1").change(function()
	{
		switch ($(this).val())
		{
			case "1":
				$("#reply_content").removeClass("dis");$("#reply_id").addClass("dis");
				break;
			case "2":
				$("#reply_content").addClass("dis");$("#reply_id").removeClass("dis");
				break;
			default:
				$("#reply_content,#reply_id").addClass("dis");
				break;
		}
	});
	$("#delete_master").click(function()
	{
		$(".master_box").html("");
		$("#t3").val("0");
	});
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$("#kuicms-submit").attr("disabled",true);
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
						setTimeout(function(){location.href='{U("index")}';},1500);
                    }
                    else
                    {
						$("#kuicms-submit").attr("disabled",false);
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>