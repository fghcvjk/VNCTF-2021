<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>订单管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：扩展管理 > <a href="{U('index')}">订单管理</a></div>
    <div class="border">
        <!---->
        <div class="navbar">
            <div class="lefter">
                
                <a href="javascript:;" class="btn btn-info dropdown-show mr-sm" data-target="#dropdown-1">批量操作</a>
                <div class="dropdown" id="dropdown-1">
                    <li><a href="javascript:;" class="dropdown-item btach" type="1">设为已处理</a></li>
                    <li><a href="javascript:;" class="dropdown-item btach" type="2">设为未处理</a></li>
                    <div class="dropdown-line"></div>
                    <li><a href="javascript:;" class="dropdown-item btach" type="3">批量删除</a></li>
                </div>
                <span class="btn-group btn-group-yellow btn-group-bg">
                    <a class="btn-group-item{if $type==0} active{/if}" href="{U('index','type=0')}">全部</a>
                    <a class="btn-group-item{if $type==1} active{/if}" href="{U('index','type=1')}">未付款</a>
                    <a class="btn-group-item{if $type==2} active{/if}" href="{U('index','type=2')}">已付款</a>
                    <a class="btn-group-item{if $type==3} active{/if}" href="{U('index','type=3')}">未处理</a>
                    <a class="btn-group-item{if $type==4} active{/if}" href="{U('index','type=4')}">已处理</a>
                </span>
            </div>
            
            <div class="righter">
                <form action="{THIS_LOCAL}">
                    <div class="form-group">
                        <div class="input-group">
                            {if kuicms[url_mode]==1}
                                <input type="hidden" name="m" value="{C('ADMIN')}" />
                                <input type="hidden" name="c" value="order" />
                                <input type="hidden" name="a" value="index" />
                                <input type="hidden" name="type" value="{$type}">
                            {/if}
                            <input type="text" name="keyword" class="form-ip radius-right-none" value="{$keyword}" placeholder="请输入关键字">
                            <button type="submit" class="after"><div class="ui-icon-search"></div></button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
        
       
        <form method="post" class="ui-form">
        <table class="table table-border table-hover table-striped mb">
            <thead class="thead-gray">
                <tr>
                	<th width="30" height="30"><label class="checkbox tips" data-align="right-top" data-title="全选/取消"><input type="checkbox" class="checkall" value=""><i></i></label></th>
                    <th width="60">ID</th>
                    <th width="140">订单号</th>
                    <th>产品名称</th>
                    <th width="80">数量</th>
                    <th width="100">总金额</th>
                    <th width="100">姓名</th>
                    <th width="110">手机</th>
                    <th width="130">下单日期</th>
                    <th width="80">是否付款</th>
                    <th width="80">状态</th>
                    <th width="130">操作</th>
                </tr>
            </thead>
            <tbody>
            {kuicms:rs pagesize="20" table="kui_order" where="$where" order="id desc"}
            {rs:eof}
            <tr>
                <td colspan="12">暂无资料</td>
            </tr>
            {/rs:eof}
            <tr>
            	<td><label class="checkbox"><input type="checkbox" name="id" value="{$rs[id]}"><i></i></label></td>
                <td>{$rs[id]}</td>
                <td class="text-left">{$rs[orderid]}</td>
                <td class="text-left">{$rs[pro_name]}</td>
                <td>{$rs[pro_num]}</td>
                <td>{$rs[pro_price]}</td>
                <td>{$rs[truename]}</td>
                <td>{$rs[mobile]}</td>
                <td>{date('Y-m-d H:i:s',$rs[createdate])}</td>
                <td>{iif($rs[ispay]==1,'已付款','<em>未付款</em>')}</td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs[isover]==1} checked{/if} data-url="{U('switchs','id='.$rs[id].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><a href="javascript:;" data-url="{U('edit',"id=".$rs[id]."")}" class="edit-iframe"><span class="ui-icon-edit"></span> 查看</a>　<a href="javascript:;" class="del" data-url="{U('del','id='.$rs[id].'')}"><span class="ui-icon-delete"></span> 删除</a></td>
            </tr>
            {/kuicms:rs}
            </tbody>
        </table>
        {if $total_rs!=0}
        <div class="page page-center page-info">
            <div class="page-list"><ul>{$showpage}</ul></div>
        </div>
        {/if}
        </form>
        <!---->
    </div>

<script>
$(function()
{
	$(".edit-iframe").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialogbox(
		{
			'title':"订单处理",
			'text':url,
			'width':'650px',
			'height':'400px',
			'type':3,
			'oktheme':'btn-info',
			'ok':function(e)
			{
				e.iframe().contents().find("#kuicms-submit").click();
			}
		});
	});
	$('.switch input[type=checkbox]').on('click',function()
	{
		var url=$(this).attr("data-url");
		var result=($(this).is(':checked'))?1:0;
		$.ajax(
		{
			url:url,
			type:"post",
			dataType:'json',
			data:"state="+result,
			error:function(e){alert(e.responseText);},
			success:function(d)
			{
				if(d.state=='success')
				{
					kuicms.success(d.msg);
				}
				else
				{
					kuicms.error(d.msg);
				}
			}
		});
	});
    $(".btach").click(function()
	{
		var type=$(this).attr("type");
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条内容');
        }
        else
        {
            $.ajax(
			{
                type:'get',
                cache:false,
                dataType:'json',
                url:'{U("btach")}{iif(kuicms[url_mode]==1,"&","?")}id='+data.join(",")+'&type='+type,
                data:"",
                error:function(e){alert(e.responseText);},
                success:function(d)
				{
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
        }
    });
    $(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要删除？不可恢复！",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>