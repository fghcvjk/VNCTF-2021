<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>群发管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：微信公众号 > <a href="{THIS_LOCAL}">群发管理</a></div>
    <div class="border">
        <!---->
        <a href="{U('add')}" class="btn btn-info mr-sm">新建群发</a>
        <form method="post" class="ui-form">
        <table class="table table-border table-hover table-striped mb mt">
            <thead class="thead-gray">
                <tr>
                    <th width="80">ID</th>
                    <th>日期</th>
                    <th width="100">类型</th>
                    <th width="80">状态</th>
                    <th width="230">结果</th>
                    <th width="80">操作</th>
                </tr>
            </thead>
            <tbody>
            {kuicms:rs pagesize="20" table="kui_mass" where="1=1" order="id desc"}
            {rs:eof}
            <tr>
                <td colspan="7">暂无资料</td>
            </tr>
            {/rs:eof}
            <tr>
                <td>{$rs[id]}</td>
                <td class="text-left">{date('Y-m-d H:i:s',$rs[title])}</td>
                <td>{iif($rs[mass_type]==1,'文本回复','<em>图文素材</em>')}</td>
                <td>{iif($rs[isover]==1,'完成','<em>发送中</em>')}</td>
                <td>总计：{$rs[total_num]}　成功：{$rs[success_num]}　失败：{$rs[fail_num]}</td>
                <td><a href="javascript:;" class="del" data-url="{U('del','id='.$rs[id].'')}"><span class="ui-icon-delete"></span> 删除</a></td>
            </tr>
            {/kuicms:rs}
            </tbody>
        </table>
        {if $total_rs!=0}
        <div class="page page-center page-info">
            <ul>{$showpage}</ul>
        </div>
        {/if}
        </form>
        <!---->
    </div>

<script>
$(function()
{
   $(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要删除？不可恢复！",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>
