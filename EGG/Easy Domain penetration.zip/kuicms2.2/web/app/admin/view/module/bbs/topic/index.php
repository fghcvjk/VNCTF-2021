<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>帖子管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：论坛管理 > <a href="{U('index')}">帖子管理</a></div>
    <div class="border">
        <!---->
        <div class="navbar">
            <div class="lefter">

                <span class="btn-group btn-group-yellow btn-group-bg">
                    <a class="btn-group-item{if $type==0} active{/if}" href="{U('index','type=0')}">全部</a>
                    <a class="btn-group-item{if $type==1} active{/if}" href="{U('index','type=1')}">未审</a>
                    <a class="btn-group-item{if $type==2} active{/if}" href="{U('index','type=2')}">已审</a>
                </span>
            </div>
            
            <div class="righter">
                <form action="{THIS_LOCAL}">
                    <div class="form-group">
                        <div class="input-group">
                            {if kuicms[url_mode]==1}
                                <input type="hidden" name="m" value="{C('ADMIN')}" />
                                <input type="hidden" name="c" value="bbstopic" />
                                <input type="hidden" name="a" value="index" />
                                <input type="hidden" name="type" value="{$type}">
                            {/if}
                            <input type="text" name="keyword" class="form-ip radius-right-none" value="{$keyword}" placeholder="请输入关键字">
                            <button type="submit" class="after"><div class="ui-icon-search"></div></button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>

        {kuicms:rs pagesize="15" field="bbsid,uface,uname,createdate,kui_bbs_reply.islock,replyid,content,reply" table="kui_bbs_reply" join="left join kui_user on kui_bbs_reply.userid=kui_user.id" where="istopic=0 $where" order="replyid desc" key="replyid"}
        <ul class="media-list  media-border-none mb-15 bd p-15">
            <li class="media">
                <div class="media-img mr-20 radius">
                    <img src="{if strlen($rs[uface])}{$rs[uface]}{else}{WEB_ROOT}upfile/noface.gif{/if}" width="64" height="64">
                </div>
                <div class="media-body">
                    <div class="media-header">{$rs[uname]} <span class="font-14 text-gray ml-15">发表于：{date('Y-m-d H:i:s',$rs[createdate])} {if $rs[islock]==0}<span class="text-red">【未审】</span>{/if}</span>
                            <div class="fr font-14">
                            	<a href="{N('bbsshow','','id='.$rs[bbsid].'')}" class="mr" target="_blank"><i class="ui-icon-link text-gray"></i> 查看主题</a>
                                <a href="{U('edit','id='.$rs[replyid].'')}" class="mr"><i class="ui-icon-edit text-gray"></i> 编辑</a>
                                <a href="javascript:;" class="del" data-url="{U('del','id='.$rs[replyid].'')}"><i class="ui-icon-delete text-gray"></i> 删除</a>
                            </div>
                    </div>
                    <div class="media-text pb">
                    	<div class="line"></div>
                        
                       	<p class="pt">{str_replace("\r\n",'<br>',$rs[content])}</p>
                        {if $rs[reply]<>''}
                            <div class="line line-left"><span class="text-red">回复：</span></div>
                            {$rs[reply]}
                        {/if}
                    </div>
                </div>
            </li>
        </ul>

        {/kuicms:rs}
        
        {if $total_rs!=0}
        <div class="page page-center page-info">
            <div class="page-list"><ul>{$showpage}</ul></div>
        </div>
        {/if}
        <!---->
    </div>
<script>
$(function()
{
	$(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要删除？不可恢复！",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>