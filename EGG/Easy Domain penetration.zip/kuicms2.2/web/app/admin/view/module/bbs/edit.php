<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>编辑主题</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script>var ue_url="{U('upload/imagelist','type=0&multiple=1&iseditor=1')}";</script>
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/admin/js/base.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.config.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.all.min.js"></script>
</head>

<body>
    <div class="position">当前位置：社区管理 > <a href="{U('index')}">主题管理</a> > <a href="{THIS_LOCAL}">编辑主题</a></div>
    <div class="border">
        <!---->
        <div class="form-subject">编辑主题</div>
        <form class="ui-form" method="post">
            <div class="form-group row">
                <label class="col-2 col-form-label">分类：</label>
                <div class="col-4">
                    <select name="t6" data-rule="分类:required;int;" class="form-ip">
                        <option value="">请选择分类</option>
                        {foreach C('bbscate') as $key=>$val}
                        <option value="{$val['cateid']}"{if $fid==$val['cateid']} selected{/if}>{$val['catename']}</option>
                        {/foreach}
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">主题：</label>
                <div class="col-4">
                    <input type="text" name="t0" class="form-ip" value="{$title}" data-rule="主题:required;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">内容：</label>
                <div class="col-10">
                    <script id="t1" name="t1" type="text/plain" style="height:260px;">{$content}</script>
                    <script>UE.getEditor('t1',{serverUrl:"{U('upload/index')}"});</script>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">人气：</label>
                <div class="col-4">
                    <input type="text" name="t2" class="form-ip" value="{$hits}" data-rule="人气:required;int;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">属性设置：</label>
                <div class="col-4">
                    <label class="checkbox"><input type="checkbox" name="t3[]" id="t3" value="1"{if $isnice==1} checked{/if}><i></i>设置精华</label>
                    <label class="checkbox"><input type="checkbox" name="t4[]" id="t4" value="1"{if $ontop==1} checked{/if}><i></i>设置置顶</label>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">状态：</label>
                <div class="col-4">
                    <label class="radio"><input type="radio" name="t5" id="t5_1" value="1"{if $islock==1} checked{/if}><i></i>启用</label>
                    <label class="radio"><input type="radio" name="t5" id="t5_2" value="0"{if $islock==0} checked{/if}><i></i>锁定</label>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label"></label>
                <div class="col-4">
                    <button type="submit" class="btn btn-info mr">保存</button>
                    <button type="button" class="btn ui-back">返回</button>
                </div>
            </div>
        </form>
        <!---->
    </div>

<script>
$(function()
{
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index","")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>