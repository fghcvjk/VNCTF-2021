<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>栏目管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：<a href="{U('index')}">栏目管理</a>{$position}</div>
    <div class="border">
        <!---->
        <a href="{U('add','fid='.$fid.'')}" class="btn btn-info mr-sm">添加分类</a>
        {if $fid!=0}
        <a href="{U('index','fid='.$pid.'')}" class="btn btn-yellow">返回上级</a>
        {else}
        <a href="javascript:;" class="refresh btn btn-yellow">更新缓存</a>
        {/if}
        
        <form method="post" class="ui-form">
        <table class="table table-border table-hover table-striped mt mb">
            <thead class="thead-gray">
                <tr>
                    <th width="80">排序</th>
                    <th width="80">栏目ID</th>
                    <th>栏目名称</th>
                    <th width="120">模型</th>
                    <th width="90">导航显示</th>
                    <th width="90">新窗口</th>
                    <th width="90">列表筛选</th>
                    <th width="360">操作</th>
                </tr>
            </thead>
            <tbody>
            {if empty($data)}
            <tr>
                <td colspan="8">暂无数据</td>
            </tr>
            {/if}
            {foreach $data as $rs}
            <tr>
                <td><input type="hidden" name="mid[]" value="{$rs['cateid']}"><input type="text" class="form-ip" name="ordnum[]" id="ordnum_{$rs['cateid']}" value="{$rs['catenum']}" data-rule="required;int;"></td>
                <td>{$rs['cateid']}</td>
                <td class="text-left">{$rs['catename']}</td>
                <td>{switch $rs['catetype']}{case -1}单页{/case}
                {case -2}链接{/case}
                {default}{if isset($model[$rs['catetype']]['title'])}{$model[$rs['catetype']]['title']}{/if}
                {/switch}</td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs['isshow']==1} checked{/if} data-url="{U('switchs','type=1&id='.$rs['cateid'].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs['isblank']==1} checked{/if} data-url="{U('switchs','type=2&id='.$rs['cateid'].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><label class="switch switch-info"><input type="checkbox" {if $rs['isfilter']==1} checked{/if} data-url="{U('switchs','type=3&id='.$rs['cateid'].'')}"><span class="switch-checkbox switch-text"></span></label></td>
                <td><a href="{U('index',"fid=".$rs['cateid']."")}"><span class="ui-icon-apartment"></span> 子分类（{$rs['snum']}）</a>　<a href="{cateurl($rs['cateid'])}" target="_blank"><span class="ui-icon-link"></span> 访问</a>　<a href="{U('edit',"id=".$rs['cateid']."&fid=".$rs['followid']."")}"><span class="ui-icon-edit"></span> 编辑</a>　<a href="javascript:;" data-url="{U('move',"id=".$rs['cateid']."")}" class="move"><span class="ui-icon-block"></span> 移动</a>　<a href="javascript:;" class="del" data-url="{U('del','id='.$rs['cateid'].'')}"><span class="ui-icon-delete"></span> 删除</a></td>
            </tr>
            {/foreach}
            </tbody>
        </table>
        {if !empty($data)}
        <button type="submit" class="btn btn-yellow">保存排序</button>
        {/if}
        </form>
        <!---->
    </div>
    
<script>
$(function()
{
	$('.switch input[type=checkbox]').on('click',function()
	{
		var url=$(this).attr("data-url");
		var result=($(this).is(':checked'))?1:0;
		$.ajax(
		{
			url:url,
			type:"post",
			dataType:'json',
			data:"state="+result,
			error:function(e){alert(e.responseText);},
			success:function(d)
			{
				if(d.state=='success')
				{
					kuicms.success(d.msg);
				}
				else
				{
					kuicms.error(d.msg);
				}
			}
		});
	});
	
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
	
	$(".refresh").click(function()
	{
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要更新分类缓存？",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:'{U("refresh")}',type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
	
	$(".move").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialogbox(
		{
			'title':"移动分类",
			'text':url,
			'width':'550px',
			'height':'320px',
			'type':3,
			'oktheme':'btn-info',
			'ok':function(e)
			{
				e.iframe().contents().find("#kuicms-submit").click();
			}
		});
	});

	$(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要删除？不可恢复！",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>