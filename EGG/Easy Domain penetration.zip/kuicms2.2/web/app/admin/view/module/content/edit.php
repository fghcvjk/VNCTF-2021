<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>编辑内容</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/select/select.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script>var ue_url="{U('upload/imagelist','type=1&multiple=1&iseditor=1')}";</script>
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/select/select.js"></script>
<script src="{WEB_ROOT}public/js/dropzone.js"></script>
<script src="{WEB_ROOT}public/admin/js/base.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.config.js"></script>
<script src="{WEB_ROOT}public/ueditor/ueditor.all.min.js"></script>
</head>

<body>
    <div class="position">当前位置：<a href="{U('lists')}">内容管理</a>{get_content_postion($classid)} > <a href="{U('edit','classid='.$classid.'&id='.$id.'')}">编辑内容</a></div>
    <div class="borders">
        <!---->
        <form class="ui-form" method="post">
        <div class="tabs tabs-white">
            <ul class="tabs-nav">
            	{foreach $group as $index=>$key}
                {php $arr=explode("|",$key)}
                <li{if $index==0} class="active"{/if}><a href="javascript:void(0)">{$arr[0]}</a></li>
                {/foreach}
                {if count($edata)>0}
                <li><a href="javascript:void(0)">内容扩展</a></li>{/if}
            </ul>
            
            <div class="tabs-content">
                
                {foreach $group as $index=>$key}
                {php list(,$num)=explode("|",$key)}
                <div class="tabs-pane{if $index==0} active{/if}">
                    <!--aaa-->
                    {if $index==0}
                    <div class="form-group row{if C('content_subid')==0} dis{/if}">
                        <label class="col-2 col-form-label">发布到其他栏目：</label>
                        <div class="col-4">
                            <select name="subid[]" placeholder="请选择" class="form-ip selectbox" multiple>
                            {php $cate=C('category')}
                            {foreach $cate as $jc=>$rs}
                                {if get_admin_info('pid')!=0}
                                    {php $lever=explode(',',CATE_LEVER)}
                                    {if in_array($jc,$lever)}
                                         <option value="{$rs['cateid']}"{if $rs['catetype']<0||strpos($rs['sonid'],',')||$rs['cateid']==$classid} disabled{/if}{if in_array($rs['cateid'],explode(",",trim($record['subid'],",")))} selected{/if}>{str_repeat("　",$rs['depth'])}{$rs['catename']}</option>
                                    {/if}
                                {else}
                                     <option value="{$rs['cateid']}"{if $rs['catetype']<0||strpos($rs['sonid'],',')||$rs['cateid']==$classid} disabled{/if}{if in_array($rs['cateid'],explode(",",trim($record['subid'],",")))} selected{/if}>{str_repeat("　",$rs['depth'])}{$rs['catename']}</option>
                                {/if}
                            {/foreach}
                            </select>
                        </div>
                    </div>
                    {/if}
                    {if isset($field[$num])}
                    {foreach $field[$num] as $rs}
                    {if $rs['field_key']=='createdate'}
                    <div class="form-group row">
                        <label class="col-2">定时发布：</label>
                        <div class="col-4">
                            <label class="radio"><input type="radio" name="isauto" id="isauto_0" value="0"{if $record['isauto']==0} checked{/if}><i></i>否</label>
                            <label class="radio"><input type="radio" name="isauto" id="isauto_1" value="1"{if $record['isauto']==1} checked{/if}><i></i>是</label>                                                        							
                        </div>
                    </div>
                    {/if}
                    <div class="form-group row"{if $rs['field_type']==7} style="display:none;"{/if}>
                        <label class="col-2 col-form-label">{$rs['field_title']}：</label>
                        <div class="col-{if $rs['field_type']==12 || $rs['field_type']==13}10{else}4{/if}{if $rs['field_type']==9} col-form-label{/if}">
                            {switch $rs['field_type']}
                            {case 1}
                            {if in_array($rs['field_key'],['url','tags','showskin'])}<div class="input-group">{/if}
                            <input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip{if in_array($rs['field_key'],['url','tags','showskin'])} radius-right-none{/if}"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{$record[$rs['field_key']]}" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            {if $rs['field_key']=='url'}
                            <a class="after dropzone ui-icon-cloud-upload radius-none" config="{$rs['field_key']}" url="{U('upload/upfile','type='.$rs['field_upload_type'].'')}" maxsize="{if $rs['field_upload_type']==1}{C('upload_image_max')}{elseif $rs['field_upload_type']==2}{C('upload_video_max')}{else}{C('upload_file_max')}{/if}" data-thumb="0" title="上传">上传</a>
                            <a class="after fm-choose ui-icon-select" data-name="{$rs['field_key']}" data-url="{U('upload/imagelist','type='.$rs['field_upload_type'].'')}" data-type="{$rs['field_upload_type']}" data-multiple="0" title="选择">选择</a>
                            {/if}
                            {if $rs['field_key']=='tags'}
                            <a class="after ui-icon-select fm-tags" data-name="{$rs['field_key']}" data-url="{U('taglist')}" title="选择">选择</a>
                            {/if}
                            {if $rs['field_key']=='showskin'}
                            <a class="after ui-icon-select template" data-name="{$rs['field_key']}" data-url="{U('theme/template')}" title="选择">选择</a>
                            {/if}
                            {if in_array($rs['field_key'],['url','tags','showskin'])}</div>{/if}
                            {/case}

                            {case 2}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip{if $rs['field_key']!=='createdate'} datepick{else} datepick-time{/if}" {if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{if $rs['field_key']!=='createdate'}{date('Y-m-d',$record[$rs['field_key']])}{else}{date('Y-m-d H:i:s',$record[$rs['field_key']])}{/if}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 3}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{$record[$rs['field_key']]}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 4}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{$record[$rs['field_key']]}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 5}
                            <div class="input-group">
                            <input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip radius-right-none"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{$record[$rs['field_key']]}" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            <a class="after dropzone ui-icon-cloud-upload radius-none" config="{$rs['field_key']}" url="{U('upload/upfile','type='.$rs['field_upload_type'].'')}" maxsize="{if $rs['field_upload_type']==1}{C('upload_image_max')}{elseif $rs['field_upload_type']==2}{C('upload_video_max')}{else}{C('upload_file_max')}{/if}" data-thumb="0" title="上传">上传</a>
                            <a class="after fm-choose ui-icon-select radius-none" data-name="{$rs['field_key']}" data-url="{U('upload/imagelist','type='.$rs['field_upload_type'].'')}" data-type="{$rs['field_upload_type']}" data-multiple="0" title="选择">选择</a>
                            <a class="after lightbox ui-icon-zoomin" data-id="{$rs['field_key']}" data-name="lightbox-pic" title="{$rs['field_title']}">预览</a>
                            </div>
                            {/case}
                            {case 6}<input type="password" name="{$rs['field_key']}" id="{$rs['field_key']}"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} class="form-ip" value="{$record[$rs['field_key']]}" {deal_rule($rs['field_rule'],$rs['field_title'])}>{/case}
                            {case 7}<input type="text" name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip"{if $rs['field_length']!=0} maxlength="{$rs['field_length']}"{/if} value="{$record[$rs['field_key']]}">{/case}
                            {case 8}<textarea name="{$rs['field_key']}" class="form-ip" id="{$rs['field_key']}" rows="3" cols="50" {deal_rule($rs['field_rule'],$rs['field_title'])}>{$record[$rs['field_key']]}</textarea>{/case}
                            {case 9}
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                            {if $rs['field_radio']==2}<div class="input-group-check">{/if}
                            <label class="radio"><input type="radio" name="{$rs['field_key']}" value="{$data[1]}" {deal_rule($rs['field_rule'],$rs['field_title'],1)} {if $record[$rs['field_key']]=="".$data[1].""} checked{/if}><i></i>{$data[0]}</label>
                            {if $rs['field_radio']==2}</div>{/if}
                            {/foreach}
                            {/case}
                            {case 10}
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                            <label class="checkbox"><input type="checkbox" name="{$rs['field_key']}[]" value="{$data[1]}" {deal_rule($rs['field_rule'],$rs['field_title'],1)} {if stristr(",".$record[$rs['field_key']].",",",".$data[1].",")} checked{/if}><i></i>{$data[0]}</label>
                            {/foreach}
                            {/case}
                            {case 11}
                            <select name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            <option value="">请选择{$rs['field_title']}</option>
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            {php $data=explode("|",$key)}
                            <option value="{$data[1]}" {if $record[$rs['field_key']]=="".$data[1].""} selected{/if}>{$data[0]}</option>
                            {/foreach}
                            </select>
                            {/case}
                            {case 12}<script id="{$rs['field_key']}" name="{$rs['field_key']}" type="text/plain" style="height:260px;">{$record[$rs['field_key']]}</script>
                            <script>UE.getEditor('{$rs['field_key']}',{serverUrl:'{U('upload/index')}'{if $rs['field_editor']==1},toolbars:editorOption{/if}});</script>
							<input type="button" class="btn btn-info editor_savepic mt-sm" data-url="{U('upload/outimage')}" data-name="{$rs['field_key']}" value="保存编辑器中外部图片">
                            {if $rs['field_key']=='content'}
                            <label class="checkbox"><input type="checkbox" name="savepic" id="savepic" value="1"><i></i>提取正文中第1张图片为缩略图</label>
                            {/if}
                            {/case}
							{case 13}
							{php $data=jsdecode($record[$rs['field_key']])}
							<div class="btn-group mt-sm">
                                <a class="btn-group-item dropzone-more ui-icon-cloud-upload" config="{$rs['field_key']}" url="{U('upload/upfile','type=1&thumb=1&water='.C('water_piclist').'')}" maxsize="{C('upload_image_max')}" title="上传">上传</a>
                                <a class="btn-group-item fm-choose ui-icon-select" data-name="{$rs['field_key']}" data-url="{U('upload/imagelist','type=1&multiple=1&iseditor='.C('water_piclist').'')}" data-type="{$rs['field_upload_type']}" data-multiple="1" title="选择">选择</a>
                            </div>
							<div class="imagelist">
								<ul id="list_{$rs['field_key']}">
									{if is_array($data)}
									{foreach $data as $num=>$val}
									<li num="{$num}">
										<div class="preview">
											<input type="hidden" name="{$rs['field_key']}[{$num}][image]" value="{$val['image']}">
											<img src="{$val['image']}" />
										</div>
										<div class="intro">
											<textarea name="{$rs['field_key']}[{$num}][desc]" class="form-ip" placeholder="图片描述...">{deal_strip($val['desc'])}</textarea>
										</div>
										<div class="action"><a href="javascript:;" class="img-left"><i class="ui-icon-left"></i>左移</a><a href="javascript:;" class="img-right"><i class="ui-icon-right"></i>右移</a><a href="javascript:;" class="img-del"><i class="ui-icon-delete"></i>删除</a></div>
									</li>
									{/foreach}
									{/if}
								</ul>
							</div>
							{/case}
							{case 14}
                            <select name="{$rs['field_key']}" id="{$rs['field_key']}" class="form-ip" {deal_rule($rs['field_rule'],$rs['field_title'])}>
                            {php $table=$rs['field_table']}
							{php $join=$rs['field_join']}
							{php $where=$rs['field_where']}
							{php $order=$rs['field_order']}
							{php $value=$rs['field_value']}
							{php $label=$rs['field_label']}
							{php $default=$record[$rs['field_key']]}
							{if $where==''}
							{php $where='1=1'}
							{/if}
							{if $order==''}
							{php $order="$value desc"}
							{/if}
							<option value="">请选择{$rs['field_title']}</option>
							{kuicms:ra top="0" table="$table" join="$join" where="$where" order="$order"}
                            <option value="{$ra['.$value.']}"{if $default==$ra['.$value.']} selected{/if}>{$ra['.$label.']}</option>
							{/kuicms:ra}
                            </select>
							{/case}
                            {/switch}
                            {if $rs['field_tips']<>''}<span class="input-tips">{$rs['field_tips']}</span>{/if}
                        </div>
                    </div>
                    {/foreach}
                    {if $index==0}
                    <div class="form-group row{if C('user_open')==2} dis{/if}">
                        <label class="col-2">阅读权限：</label>
                        <div class="col-4">
                            {kuicms:rs top="0" table="kui_user_group" order="ordnum,gid"}
                            <label class="checkbox"><input type="checkbox" name="view_lever[]" value="{$rs[gid]}"{if in_array($rs[gid],explode(',',$record['view_groupid']))} checked{/if}><i></i>{$rs[gname]}</label>
                            {/kuicms:rs}
                        </div>
                    </div>
                    {/if}
                    {/if}
                    <!--aaa-->
                </div>
                {/foreach}
                {if count($edata)>0}
				{php $extend=unserialize($extend)}
                <div class="tab-panel">
					{foreach $edata as $rs}
					<div class="form-group row">
                        <label class="col-2 col-form-label">{$rs['field_title']}：</label>
                        <div class="col-4">
							{switch $rs['field_type']}
                            {case 1}<input type="text" name="extend[{$rs['field_key']}]" id="{$rs['field_key']}" class="form-ip" value="{if isset($extend[$rs['field_key']])}{$extend[$rs['field_key']]}{/if}" >{/case}
                            {case 2}
                            <select name="extend[{$rs['field_key']}]" id="{$rs['field_key']}" class="form-ip">
                            <option value="">请选择{$rs['field_title']}</option>
                            {php $arr=explode(",",$rs['field_list'])}
                            {foreach $arr as $j=>$key}
                            <option value="{$key}" {if isset($extend[$rs['field_key']])}{if $key=="".$extend[$rs['field_key']].""} selected{/if}{/if}>{$key}</option>
                            {/foreach}
                            </select>
                            {/case}
							{/switch}
						</div>
					</div>
					{/foreach}
				</div>
				{/if}              
            </div>
        </div>
        <div class="form-group mt">
            <button type="submit" class="btn btn-info mr-sm">保存</button>
            <button type="button" class="btn ui-back">返回</button>
        </div>
        </form>
        <!---->
    </div>

<script src="{WEB_ROOT}public/datepick/laydate.js"></script>
<script>
$(function()
{
	{if C('content_subid')==1}
	{no}
	$('.selectbox').SumoSelect(
	{ 
		csvDispCount:4, 
		captionFormat:'已选择：{0} 个', 
	});
	{/no}
	{/if}
	lay('.datepick').each(function()
	{
		laydate.render(
		{
			elem:this,
		});
	});
	lay('.datepick-time').each(function()
	{
		laydate.render(
		{
			elem:this,
			type:'datetime'
		});
	});
    $(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			{foreach $editor as $key=>$val}
			UE.getEditor('{$val}').sync();
			$("#{$val}").val(UE.getEditor('{$val}').getContent());
			{/foreach}
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U('lists','classid='.$classid.'')}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
$(".dropzone").dropzone(
{
	maxFiles: 1,
	success:function(file,data,that)
	{
		data=jQuery.parseJSON(data);
		this.removeFile(file);
		if(data.state=="success")
		{
			kuicms.success("上传成功");
			$("#"+$(that).attr("config")).val(data.msg);
		}
		else
		{
			kuicms.error("上传失败："+data.msg);
		}
	},
	sending:function(file)
	{
		kuicms.loading("正在上传，请稍等");
	},
	totaluploadprogress:function(progress)
	{
		$.progress((Math.round(progress*100)/100)+"%");
	},
	queuecomplete:function(progress)
	{
		$.progress('close');
	},
	error:function(file,msg)
	{
		kuicms.error(msg);
	}
});
$(".dropzone-more").dropzone(
{
	maxFiles:50,
	success:function(file,data,that)
	{
		data=jQuery.parseJSON(data);
        this.removeFile(file);
		if(data.state=="success")
		{
			var name=$(that).attr("config");
			var num=1;
			$("#list_"+name+" li").each(function()
			{
				var max=parseInt($(this).attr("num"));
				if (max>=num)
				{
					num=max+1;
				}
			});
			var html='';
			html+='<li num="'+num+'">';
			html+='	<div class="preview">';
			html+='		<input type="hidden" name="'+name+'['+num+'][image]" value="'+data.msg+'">';
			html+='		<u href="'+data.msg+'" class="lightbox"><img src="'+data.msg+'" /></u>';
			html+='	</div>';
			html+='	<div class="intro">';
			html+='		<textarea name="'+name+'['+num+'][desc]" class="form-ip" placeholder="图片描述..."></textarea>';
			html+='	</div>';
			html+='	<div class="action"><a href="javascript:;" class="img-left"><i class="ui-icon-left"></i>左移</a><a href="javascript:;" class="img-right"><i class="ui-icon-right"></i>右移</a><a href="javascript:;" class="img-del"><i class="ui-icon-delete"></i>删除</a></div>';
			html+='</li>';
			$("#list_"+name).append(html);
		}
		else
		{
			kuicms.error("上传失败："+data.msg);
		}
	},
	sending:function(file)
	{
		kuicms.loading("正在上传，请稍等");
	},
	totaluploadprogress:function(progress)
	{
		$.progress((Math.round(progress*100)/100)+"%");
	},
	queuecomplete:function(progress)
	{
		$.progress('close');
	},
	error:function(file,msg)
	{
		kuicms.error(msg);
	}
});
</script>
</body>
</html>