<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>添加字段</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：栏目管理 > <a href="{U('extend/index')}">内容扩展</a> > <a href="{U('index',"eid=".$eid."")}">{$mtitle}</a> > <a href="{U('index',"eid=".$eid."")}">字段管理</a> > <a href="{THIS_LOCAL}">添加字段</a></div>
    <div class="border">
        <!---->
        <form class="ui-form" method="post">
            <div class="form-group row">
                <label class="col-2 col-form-label">字段名称：</label>
                <div class="col-4">
                    <input type="text" name="t0" class="form-ip" placeholder="请输入字段名称" data-rule="字段名称:required;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">字段Key：</label>
                <div class="col-4">
                    <input type="text" name="t1" class="form-ip" placeholder="字母和数字的组合，长度3-50个字符" data-rule="字段Key:required;">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">字段类型：</label>
                <div class="col-4">
                    <select name="t2" id="t2" class="form-ip" data-rule="字段类型:required;">
                        <option value="">请选择字段类型</option>
                        <option value="1">普通文本</option>
                        <option value="2">下拉列表</option>
                    </select>
                </div>
            </div>
            <div class="form-group row dis" id="listval">
                <label class="col-2 col-form-label">候选值：</label>
                <div class="col-4">
                    <textarea name="t3" class="form-ip" rows="5" cols="50" data-rule="候选值:required;"></textarea>
                    <span class="gray"><br>示范：项目名称1<br>　　　项目名称2</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">默认值：</label>
                <div class="col-4">
                    <input type="text" name="t4" class="form-ip">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">字段排序：</label>
                <div class="col-4">
                    <input type="text" name="t5" class="form-ip" value="0">
                    <span class="input-tips">数字越小越靠前</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">状态：</label>
                <div class="col-4">
                    <label class="radio"><input type="radio" name="t6" value="1" checked><i></i>正常</label>
                    <label class="radio"><input type="radio" name="t6" value="0"><i></i>锁定</label>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label"></label>
                <div class="col-4">
                    <button type="submit" class="btn btn-info mr">保存</button>
                    <button type="button" class="btn ui-back">返回</button>
                </div>
            </div>
        </form>
        <!---->
    </div>

<script>
$(function()
{
    $("#t2").change(function(){
        switch ($(this).val())
        {
            case "1":
				$("#listval").addClass("dis");
				break;
            case "2":
				$("#listval").removeClass("dis");
				break;
        }
    });
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index","eid=".$eid."")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>