<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>编辑城市</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body class="bg_white">
    <div class="border_iframe">
        <!---->
        <form class="ui-form" method="post">
        <!--aaa-->
        <div class="form-group row">
            <label class="col-3 col-form-label">城市名称：</label>
            <div class="col-9">
                <input type="text" name="name" class="form-ip" value="{$name}" data-rule="城市名称:required;">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-3">开启分站：</label>
            <div class="col-9">
                <label class="radio"><input type="radio" name="t0" value="1" {if $site_open==1} checked{/if}><i></i>开启</label>
                <label class="radio"><input type="radio" name="t0" value="0" {if $site_open==0} checked{/if}><i></i>关闭</label>
                <span class="input-tips">关闭后，以下设置无效</span>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-3 col-form-label">路径：</label>
            <div class="col-9">
                <input type="text" name="t1" class="form-ip" value="{$site_root}" data-rule="路径:required;letters;">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-3">二级域名：</label>
            <div class="col-9">
                <label class="radio"><input type="radio" name="t2" value="1" {if $site_domain==1} checked{/if}><i></i>开启</label>
                <label class="radio"><input type="radio" name="t2" value="0" {if $site_domain==0} checked{/if}><i></i>关闭</label>
                <span class="input-tips">{if C('city_domain')!=''}开启后效果：{$site_root}.{C('city_domain')}{else}请先在【系统设置】里配置分站根域名{/if}</span>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-3">SEO设置：</label>
            <div class="col-9">
                <label class="radio"><input type="radio" name="t3" id="t3_0" value="0" {if $site_self==0} checked{/if}><i></i>使用主站</label>
                <label class="radio"><input type="radio" name="t3" id="t3_1" value="1" {if $site_self==1} checked{/if}><i></i>自定义</label>
            </div>
        </div>
        <div class="form-group row siteconfig{if $site_self==0} hide{/if}">
            <label class="col-3 col-form-label">分站优化标题：</label>
            <div class="col-9">
                <input type="text" name="t4" class="form-ip" value="{$site_title}">
            </div>
        </div>
        <div class="form-group row siteconfig{if $site_self==0} hide{/if}">
            <label class="col-3 col-form-label">分站关键字：</label>
            <div class="col-9">
                <textarea name="t5" rows="3" class="form-ip form-limit" data-max="255">{$site_key}</textarea>
                <div class="form-limit-text"><span>{mb_strlen($site_key)}</span>/255</div>
            </div>
        </div>
        <div class="form-group row siteconfig{if $site_self==0} hide{/if}">
            <label class="col-3 col-form-label">分站描述：</label>
            <div class="col-9">
                <textarea name="t6" rows="3" class="form-ip form-limit" data-max="255">{$site_desc}</textarea>
                <div class="form-limit-text"><span>{mb_strlen($site_desc)}</span>/255</div>
            </div>
        </div>
        <div class="form-group hide">
            <button type="submit" class="btn btn-blue" id="kuicms-submit">保存</button>
            <button type="button" class="btn ui-back">返回</button>
        </div>
    </form>
    <!---->
</div>

<script>
$(function()
{
	$("#t3_0").click(function()
	{
		$(".siteconfig").addClass("hide");
	});
	$("#t3_1").click(function()
	{
		$(".siteconfig").removeClass("hide");
	});
	var backurl=window.parent.location;
	$(".ui-form").form(
	{
		type:2,
		align:'bottom-center',
		result:function(form)
		{
			$.ajax(
			{
				type:'post',
				cache:false,
				dataType:'json',
				url:'{THIS_LOCAL}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){parent.location.href=backurl;},1000);
					}
					else
					{
						kuicms.error(d.msg);
					}  
				}
			});
		}
	});
})
</script>
</body>
</html>