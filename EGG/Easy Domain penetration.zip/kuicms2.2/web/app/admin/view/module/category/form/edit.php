<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>编辑表单</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script src="{WEB_ROOT}public/admin/js/base.js"></script>
</head>

<body>
    <div class="position">当前位置：栏目管理 > <a href="{U('index')}">表单管理</a> > <a href="{THIS_LOCAL}">编辑表单</a></div>
    <div class="borders">
        <!---->
        <form class="ui-form" method="post">
        <div class="tabs tabs-white">
            <ul class="tabs-nav">
                <li class="active"><a href="javascript:;">基本设置</a></li>
                <li><a href="javascript:;">模板设置</a></li>
                <li><a href="javascript:;">Seo设置</a></li>
            </ul>
            <div class="tabs-content">
                <div class="tabs-pane active">
                    <!--1111-->
                    <div class="form-group row">
                        <label class="col-2 col-form-label">表单名称：</label>
                        <div class="col-4">
                            <input type="text" name="t0" class="form-ip" value="{$title}" placeholder="请输入表单名称" data-rule="表单名称:required;">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">表单标识：</label>
                        <div class="col-4">
                            <input type="text" name="t1" class="form-ip" value="{$tablename}" disabled maxlength="20" placeholder="字母和数字的组合，长度3-50个字符" data-rule="表单标识:required;">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">验证码：</label>
                        <div class="col-4 col-form-label">
                            <label class="radio"><input type="radio" name="t2" value="1" {if $iscode==1} checked{/if}><i></i>启用</label>
                            <label class="radio"><input type="radio" name="t2" value="0" {if $iscode==0} checked{/if}><i></i>锁定</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">提交后返回：</label>
                        <div class="col-4 col-form-label">
                            <label class="radio"><input type="radio" name="t11" value="1" {if $backway==1} checked{/if}><i></i>列表页</label>
                            <label class="radio"><input type="radio" name="t11" value="2" {if $backway==2} checked{/if}><i></i>当前页</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">邮件提醒：</label>
                        <div class="col-4">
                            <select name="t12" class="form-ip">
                                <option value="0">不使用邮件提醒</option>
                                {kuicms:rs top="0" table="kui_temp_mail" where="islock=1 and mkey=''" order="id desc"}
                                <option value="{$rs[id]}"{if $mid==$rs[id]} selected{/if}>{$rs[title]}</option>
                                {/kuicms:rs}
                            </select>
                            <span class="input-tips">可在邮件模板中新建</span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">会员提交：</label>
                        <div class="col-4 col-form-label">
                            <label class="radio"><input type="radio" name="t13" value="1" {if $isuser==1} checked{/if}><i></i>开启</label>
                            <label class="radio"><input type="radio" name="t13" value="0" {if $isuser==0} checked{/if}><i></i>关闭</label>
                            <span class="input-tips">开启后，必须会员才能提交</span>
                        </div>
                    </div>
                    <div class="form-group row"> 
                        <label class="col-2 col-form-label">表单排序：</label>
                        <div class="col-4">
                            <input type="text" name="t3" class="form-ip" value="{$ordnum}">
                            <span class="input-tips">数字越小越靠前</span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2">状态：</label>
                        <div class="col-4">
                            <label class="radio"><input type="radio" name="t4" value="1" {if $islock==1} checked{/if}><i></i>启用</label>
                            <label class="radio"><input type="radio" name="t4" value="0" {if $islock==0} checked{/if}><i></i>锁定</label>
                        </div>
                    </div>
                    <!--1111-->
                </div>
                
                <div class="tabs-pane">
                    <!--2222-->
                    <div class="form-group row">
                        <label class="col-2 col-form-label">提交模板：</label>
                        <div class="col-3">
                        	<div class="input-group">
                            	<input type="text" name="t5" id="t5" value="{$add_skins}" class="form-ip radius-right-none">
                                <a class="after template ui-icon-select" data-name="t5" data-url="{U('theme/template')}" title="选择">选择</a>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">列表模板：</label>
                        <div class="col-3">
                        	<div class="input-group">
                            	<input type="text" name="t6" id="t6" value="{$list_skins}" class="form-ip radius-right-none">
                                <a class="after template ui-icon-select" data-name="t6" data-url="{U('theme/template')}" title="选择">选择</a>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">内容模板：</label>
                        <div class="col-3">
                        	<div class="input-group">
                            	<input type="text" name="t7" id="t7" value="{$show_skins}" class="form-ip radius-right-none">
                                <a class="after template ui-icon-select" data-name="t7" data-url="{U('theme/template')}" title="选择">选择</a>
                            </div>
                        </div>
                    </div>
                    <!--2222-->
                </div>
                
                <div class="tabs-pane">
                    <!--3333-->
                    <div class="form-group row">
                        <label class="col-2 col-form-label">优化标题：</label>
                        <div class="col-4">
                            <input type="text" name="t8" class="form-ip" value="{$seotitle}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">关键字：</label>
                        <div class="col-4">
                            <input type="text" name="t9" class="form-ip" value="{$seokey}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">描述：</label>
                        <div class="col-4">
                            <textarea name="t10" rows="4" class="form-ip form-limit" data-max="255">{$seodesc}</textarea>
                            <div class="form-limit-text"><span>{mb_strlen($seodesc)}</span>/255</div>
                        </div>
                    </div>
                    <!--3333-->
                </div>

            </div>
        </div>
        
        <div class="form-group mt">
            <button type="submit" class="btn btn-info mr-sm">保存</button>
            <button type="button" class="btn ui-back">返回</button>
        </div>
        </form>
        <!---->
    </div>
    
<script>
$(function()
{
    $(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>