<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>登录页面</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body class="bg-login">

    <div class="ui-login ui-am-scale-up">
        <div class="header">
        	<div class="logo"><a href="{WEB_ROOT}"><span class="ui-icon-home"></span>返回首页</a><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAArCAYAAAA9iMeyAAAMQ0lEQVR4nO2dedQWVR3HPy87KoiILC6IGW4oiEsKlqIYUaahoiR1xOVkZnS0xCULj3rMJZdcjxql4nEv18olIjNCQUHBEAMCN3hVRAQFBAV+/fG9c5557nufZ2ae5X3R5nPOnJnnzp1755lnfnN/250HcnJyStJQbqeZpW2nK3A88BnwV+Btb393YCjQDfgLsCjTWebkVEhDQ9lbPJFWVfbfG5gITAJ2BqbRVDgAlgL/AjoBfwT+BAyssu+cnLpTqYC0Ba4D3gT2BE4BzgFeLXPM28BlwLeB1sBLwH1AzwrPISen7lSiYh0M3AXsCPwK+GWFfZ8K/A74FPgeGllycmpKtSpWVgEZBdzvtr8O/K2q3qEP8LrbPhe4qsr2cnKKaE4BGQE84rYvBz4A3gXuqbDvk5Hd8h5wgys7D/h1he3l5DShuQSkN/CGq38vsA7d4AC7AvMDh7d29dcH9vWNHXM/sAAY7z4PAZ5Nce45OYk0l4BMAb7qtrsDewF3IMGZDeyNBKILGlkATgDaIS8XyMW7ErmCZwL7IMH4EfAPNJJs7dY7IiHMyamK5nDzfpOCcNwDvA/8HQnJDGAAsk02AAfFjjsaOC72eTASjpFIOGYB+wKT3bGR/dEDGJvivNogYY0v3UgQesdmgWN7II9cdVe0OrpS2ffJaQnMDDN7wgoMdGXx5U2371YzOydWvtDMlsU+n2VmE81srZmtMbOtvHY6mdk619YiM2sI9BVf+pvZZ97ylpm1Sziur5m9FzjWzOx6M2uVcHw9l5kVfJ98KbNUS9II0pnC6LEAeDm2bwzwOAXD/YeuPugJvRNSmbq6sg7AiUB74EjgQ6+vj4Gn3fZO6GlejjaBZauEY0CR/u6BY6cBZwEbU7RRLzqT/fvk1JEkAdkBRb9BtsThyB7ZGtkgQ1FM5ExgLbrJQOpXpBoMcOspwHIUUJwc66M1MBc4Crg9Vv7lhHPbECj7OOGYB5Br2WcuUg+rf+RUx2rvc+ToyGkh2iTsj9+ELwOD0IgyGf1wP0ER8ZfQSLLE1d01dtzuwDPAVFe+zOvjXlfnEOD3sfJaG+k/Q/liPh8hwW/JkSPCF9BFyG7LaSGSRpBuFG7oj5AhC4VR4ZVY3WUojQSKn/47u/UxgfbHU7hpe7s+ItZRu6fngcA1JfYdDrxTo36qJbq+jSh9J0nNzKkzSQJyAEoyBA3/Xb39I2Pbv0DBRLx6kV1yKHBxrPwC4JLY5y7AKrc9Ddie5BEuDZ0p2DY+o4AXa9BHLWiPYkPjgO1Q1vNF5HZIi5J0A44Gnkcq0m7ANighcQXS2c8D9nBl5wO3uePaxtro6NYrkRAZChQOc+UPIWHoDOwCTHd9jqYQQ6mGJykIaZzxwIMZ2rkB6BX7/A6yvUJ2S1+UmBnnKYpVSB9DQdIOyOU9zpVfnuEcOyC3fF+gH3KWlGIlOn/f7ok4k4KDpha8iVz7k1CsKwvD0LXpm+GY+eh+qx9mNtvMlprZKDPrY2ZDnfvscAtzqdt/S6zsLld2tld3lZkdFnPJDTKz7mb2DZOLeHqCC29AoP9GK3aLXlPiPCdW4DJc77Wx3kq7hIcE+nwwRR8XmdnG2DGLzaxtyvM73Qou97R0K9PeMxnbSssKMxtTpl9/ebjCfpZYM7h5X0WjxhVIbYq8T1Hm7Wiv/hq3Xhco+9SrOxQFHCOeRzr4FcCXvH1ZiK7Kscgw95mCXNRZ8Sd5lZv09UmgLM1TcyzFdlcr0tlhvwFuQXZcWozyXrvGDG1lYUvgTmT7JXETCjhXQpJHMxVJKtYbbt0HpYf8FpiAVIDZwJ+R2hEZwLPdOm70LnXrmbGyc5EqFTEQ+DFKgY+YmnTyAdogr093wurTYmB4Be02F4uRCz0LJ6H4TYg1FK6/zweE8+TK0UjTB902wOZl6rVBKrTPzRR7O312RveEz2qUzZFEublJtcHMDgoMXRtNKtQIM9vFDYMnmtmFsWHxO7H6J8TKz4h97meKrj8b6ONDM2ufMPSGVKy5ZraZmc0o0eZOCW2WW+Z77c230irWAYH+b0zRxyzvGF9l9JcOZrYy0NfbZnaymW1bxfe9J9DunoF6dyfUa2Vm3zWzjwP19ivT/2mB+jPMrFeW71EtSSrWVJo+yRuA01HcYx5KNGyNZhhGzC6xfTd62kwF5iDV4OBAv2OoLA6yHGUH7+uVGzL0Xm9yxOebI2jqgFiGct3uoPZqkj96QDhgG6+3Ef0mNwbqDQiURYRG0gdoZpd8mmTFo1FSYikOQRHwlUi3bIdUs8hlOxcNsxNdnQkocTHEIuDnSDjapTg3n7aEVbMGNm3VqlKGBMquI50KUgkdA2UhNT1ULzQlYssyfX0QKGv23zBNnOF9YH+URzUMBQE3QykofVydFSiOMQbFO3ZEOU9RmspCCgZkIzJi1yN7YTXSk6eiEen7ro1SsYty9ASuRHrx2d6+S4C3qI3reFMhpMNPDpRtCoTutXIP6ND3OAzNFSo1X+jfKG5Xs1EmSyDuLrdEXIae9gtQTKQr8DWkNo1z+9sjg7wLMianIUN0LeGh+TUUbzk/w3nFae/W41CEfgdv/50oZeYVvhh0CZTVa/SolpAwlEvvWYiSYY/yyg8mrJZHfIKcSaUcF5mo5rU/J7r1behHmYdewtAJ+C/yWj2HhtYt0ZN7HhoxQsLRg0JaStZAUsRGCqqZf2Ejnqap1+WLRLWvctqUOBXdM1noiIKcj1ODa1FpA8ejdIgNyBiM2BUlHj4aK3sURUCT8oq2ohCBX17hecWZhTKHfXoi93RW/GuVFEdoDkLXKaubeFNmGXK4XI7UpywJpUeit+VURRoB2RfZFHEucOsHKPxIw1Fe0xaBNtojG2NkYF9E69h2TYI8wNUoTcZnCNlfDuFn1W6g5QXkP4GyI5r9LOrLanS/9Ucqc2jZC3gscOy3qu08jYAcSHFEegQF99z1bt0B5TzNJJz8NwcZXX+gtOdiVWy7lineIwkL3DkoWTEtH3mfewRrieZKnX8yUHYW2SLqnycakQ3rL3NomtUBNUj0TCMgS1HcoxdKJrzTlb/gFigYRNORNN8aO/4WFCmPBOe8Ev28j9zAac8rLcspLQj3oe+UhgXe566Ufo9XLVTENDyNkgDjbIGcIcdSPlnxi8awQNm71Taaxou1Chm+c9FI0cGVXxmrc4pbj6UgAAPRSHAQErBohBiDMml9Q30N+rH7U3sj+kmU2uCnLjSg7NK+hINgcR6jqU47DuWU+Z6jcv79WvMD5FKP0wvlyy1Gv1uIFcgIXlVif0uzO8XB5yQODZQ9EijLRBoBiW7WuEtxHvCw2+5HIQ05fmN/xWsnsk22BfajOBdrOPJ2zUECUo/39Y5FQU3fWdAbORKS9NWH0MzJfbzyln4J9yTkFr8isG97wnlQEWew6QpIT8KjQlqeIGyXZCKNKhOqE5/otHtsew6KhRyIRpir0QgyiOJo/G5ee9ELHxa7zyFD36dtoKwX5bNfQ7MaQXMoys3VANkVRyAhqYRQzMLHt2uSvk/ElcBphKPPleJPjoPwNU9bL6QVdAqURVRjxy1EcbeqSTOC+MYpFN/gkcr1DpqBGKW3T6eYQUiP70NxKsIAZPifSuHChrwzofOa7ZUto/yFXYAu3E+98lYoSjsYxW5K8S7y6p2ERqP+FHvfypEmu3QKxTZR0veJMwGpVaPQJLa9CU8Ui1hOeWfILIoniEH4Xkhb7y2a/l7lpgysCNRPYgGydW+icB/WD5cRuV0gq3KtmXVx+4e5sqtSZFeOd3WPiZU978owsxfMbIOZtcmSsVnDZfMW6jdf6rRUSxoVawnSv0GTmkBxjZvddjRnPc2TNBqx/unWxyF17Ck0euyPnoBZ5ynUilLTT3P+T0n7bt4eKHp+I0oCvNqVH4eG9QluO0nPbkQqzEikpr3myvdAxn4/il/skJNTFc39/yARFwMXuu1ByO/+kFtfS1MXbivkMRmOXg20C7IzGpDAXYvSVLLm3eTklKWlBAT09wfRmxBHIJfaYGRY+apKR+QOfQ7NRZ7kykejYF1OTl1oSQEBvVzhejQqTCTZtXY7EqyH0VsZ6/VigJwcoOX/5XYRypocioKFM1CqcTzQty1So15EQbnBKA0iF46cTZ5a/U96xN4o+rkEvRmwAQXXeqJ0j/q/aSInJ0a1I0hOTk4Z/gdyxj9T23QruQAAAABJRU5ErkJggg=="></div>
        </div>
        <form class="ui-form" method="post">
            <div class="form-group">
        		<i class="form-icon ui-icon-user"></i>
                <input type="text" name="t0" class="form-ip" data-rule="用户名:required;username;" placeholder="请输入用户名" >
            </div>
            <div class="form-group">
        		<i class="form-icon ui-icon-lock"></i>
                <input type="password" name="t1" class="form-ip" placeholder=" 请输入密码" data-rule="密码:required;password;">
            </div>
            {if C('admin_code')==1}
            <div class="form-group">
                <div class="input-group">
                	<i class="form-icon ui-icon-eye"></i>
                    <input type="text" name="t2" id="t2" class="form-ip radius-right-none" placeholder="请输入验证码" data-rule="验证码:required;">
                    <span class="code"><img src="{U('code')}" id="verify" data-title="点击更换验证码" class="tips" data-align="top"></span>
                </div>
            </div>
            {/if}
            <div class="form-group">
                <input type="submit" value="登录" class="btn btn-block">
            </div>
        </form>
    </div>
	<div class="copyright ui-am-slide-bottom ui-am-delay-1"><span>当前版本：{C('version')}</span>Powered By <a href="https://www.kuicms.com" target="_blank">kuicms.com</a> @ 2008-{date('Y')} Inc.</div>
<script>
$(function(){
	$("img").click(function(){
		var img=$(this).attr("src");
		if(img.indexOf('?')>0)
		{
			$(this).attr("src",img+'&random='+Math.random());
		}
		else
		{
			$(this).attr("src",img.replace(/\?.*$/,'')+'?'+Math.random());
		}
		$("#t2").val("");
	});
	$("html,body").css({"display":"flex","align-items":"center","justify-content":"center","height":"100%"});
	$(".ui-form").form(
	{
		type:2,
		'align':"top-right",
		result:function(form)
		{
			$.ajax({
				type:'post',
				cache:false,
				dataType:'json',
				url:'{U("check")}',
				data:$(form).serialize(),
				error:function(e){alert(e.responseText);},
				success:function(d)
				{
					if(d.state=='success')
					{
						kuicms.success(d.msg);
						setTimeout(function(){location.href='{N(MODULE_NAME)}';},1500);
					}
					else
					{
						{if C('admin_code')==1}$("#verify").click();{/if}
						kuicms.error(d.msg);
					}
				}
			});
		}
	});
})
if(self!=top){top.location=self.location;}
</script>
</body>
</html>