<?php
/**
 * 作用：Http类
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

final class kuicms_http
{
	public function __construct(){}
	
	public static function get($url,$timeout=30,$head='')
	{
		$head=($head='')?FALSE:$head;
		$ch=curl_init();
		#设置超时
		curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
		//Url
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		#设置header
		curl_setopt($ch,CURLOPT_HEADER,$head);
		#要求结果为字符串且输出到屏幕上
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
		$result=curl_exec($ch);
		curl_close($ch);
		return $result;
	}

	public static function post($url,$data,$timeout=30,$head='')
	{
		$head=($head='')?FALSE:$head;
		$ch=curl_init();
		#设置超时
		curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
		#Url
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		#设置header
		curl_setopt($ch,CURLOPT_HEADER,$head);
		#要求结果为字符串且输出到屏幕上
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
		#post提交方式
		curl_setopt($ch,CURLOPT_POST,TRUE);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
		$result=curl_exec($ch);
		curl_close($ch);
		return $result;
	}

	public static function del_oss($url,$head)
	{
		$ch=curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
        curl_setopt($ch,CURLOPT_CUSTOMREQUEST,'DELETE');
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,5);
        $result=curl_exec($ch);
        curl_close($ch);
		return $result;
	}

	public static function del_qiniu($url,$head)
	{
		$ch=curl_init();
		$options=array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HEADER => true,
            CURLOPT_NOBODY => false,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_URL => $url,
        );
        $headers=[];
        foreach ($head as $key => $val)
        {
            array_push($headers,"$key: $val");
        }
        $options[CURLOPT_HTTPHEADER]=$headers;
        curl_setopt_array($ch,$options);
        $result=curl_exec($ch);
        $code=curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ['state'=>$code,'msg'=>$result];
	}
	
}