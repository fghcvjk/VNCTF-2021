<?php
/**
 * 作用：上传
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

class Upload extends HomeController
{
	public function index()
	{
		$result='';
		switch(F('get.action')) 
		{
			case 'image':
				$result=self::editor(1);
				break;
			default:
				$result=self::config();
				break;
		}
		if(isset($_GET["callback"]))
		{
		    if(preg_match("/^[\w_]+$/", $_GET["callback"]))
			{
		        echo htmlspecialchars($_GET["callback"]) . '(' . $result . ')';
		    }
		}
		else
		{
			echo $result;
		}
	}

	public function config()
	{
		list($host)=explode(':',$_SERVER['HTTP_HOST']);
		$arr=[
			'imageActionName'=>'image',
			'imageFieldName'=>'file',
			'imageMaxSize'=>C('upload_image_max')*1024*1024,
			'imageAllowFiles'=>[".png",".jpeg",".jpg",".gif"],
			'imageCompressEnable'=>false,
			'imageCompressBorder'=>9999,
			'imageInsertAlign'=>'none',
			'imageUrlPrefix'=>'',
			'imagePathFormat'=>'',

			'fileActionName'=>'file',
			'fileFieldName'=>'file',
			'filePathFormat'=>'',
			'fileUrlPrefix'=>'',
			'fileMaxSize'=>C('upload_file_max')*1024*1024,
			'fileAllowFiles'=>[".gif",".jpeg",".jpg",".png",
				".swf",".mp4",".flv",
				".doc",".docx",".xls",".xlsx",".ppt",".pptx",
				".rar",".zip",".7z",".gz",".tar",
				".apk",".iso",".pdf",".txt"],

			'imageManagerActionName'=>'listimage',
			'imageManagerListSize'=>'20',
			'imageManagerUrlPrefix'=>'',
			'imageManagerInsertAlign'=>'none',

			'fileManagerActionName'=>'listfile',
			'fileManagerListSize'=>'20',
			'fileManagerUrlPrefix'=>'',
			'catcherLocalDomain'=>["127.0.0.1","localhost",$host],
			'catcherActionName'=>'catchimage',
			'catcherFieldName'=>'source',
			'catcherPathFormat'=>'',
			'catcherUrlPrefix'=>'',
			'catcherMaxSize'=>C('upload_image_max')*1024*1024,
			'catcherAllowFiles'=>[".png",".jpg",".jpeg",".gif",".bmp"]
		];
		return jsencode($arr);
	}

	public function editor($type)
	{
		if(USER_ID==0)
		{
			$arr=['state'=>'未登录'];
		}
		else
		{
			$up=new kuicms_upload('file',$type,1,1);
			if($up->state=='success')
			{
				$arr=['state'=>'SUCCESS','url'=>$up->msg,'original'=>$up->oldname,'title'=>$up->oldname];
				#记录到附件
				$data=$up->fileinfo;
				$data['file_userid']=USER_ID;
				$this->db->add("kui_attachment",$data);
			}
			else
			{
				$arr=['state'=>$up->msg];
			}
		}
		return jsencode($arr);
	}

}