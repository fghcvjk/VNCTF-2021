<?php
/**
 * 作用：搜索主题
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

if(!defined('IN_KUICMS')) exit;

if(USER_ID==0)
{
	$this->error_tips(C('lan_bbs_search'));
	return;
}
$where='';
if(!isset($_GET['keyword']))
{
	$_GET['keyword']='';
}
$keyword=rawurldecode($_GET['keyword']);
$encode=mb_detect_encoding($keyword,['UTF-8','GBK','GB2312']);
if($encode!='UTF-8')
{
	$keyword=mb_convert_encoding($keyword,'utf-8',$encode);   
}
$keyword=enhtml($keyword);
if(strlen($keyword)<2||strlen($keyword)>20)
{
	$this->error_tips(C('lan_bbs_search_key'));
	return;
}
$where.=" and (title like '%$keyword%' or title like '$keyword%' or title like '%$keyword')";
$this->assign('keyword',$keyword);
$this->assign('where',$where);
$this->display(T('bbs_search'));