<?php
$G3a8R=!defined('IN_KUICMS');if($G3a8R){exit();}echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">";echo "
<meta name=\"renderer\" content=\"webkit\">";echo "
<title>添加客服</title>";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/css/ui.css\">";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/admin/css/layout.css\">";echo "
<script src=\"{WEB_ROOT}public/js/jquery.js\"></script>";echo "
<script src=\"{WEB_ROOT}public/js/ui.js\"></script>";echo "
</head>";echo "
";echo "
<body class=\"bg_white\">";echo "
    <div class=\"border_iframe\">";echo "
        <!---->";echo "
        <form class=\"ui-form\" method=\"post\">";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-3 col-form-label\">客服名称：</label>";echo "
                <div class=\"col-9\">";echo "
                    <input type=\"text\" name=\"t0\" class=\"form-ip\" placeholder=\"请输入客服名称\" data-rule=\"客服名称:required;\">";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-3 col-form-label\">QQ号码：</label>";echo "
                <div class=\"col-9\">";echo "
                    <input type=\"text\" name=\"t1\" class=\"form-ip\" placeholder=\"请输入QQ号码\" data-rule=\"QQ号码:required;qq;\">";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-3 col-form-label\">排序：</label>";echo "
                <div class=\"col-9\">";echo "
                    <input type=\"text\" name=\"t2\" class=\"form-ip\" value=\"0\">";echo "
                    <span class=\"input-tips\">数字越小越靠前</span>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-3\">状态：</label>";echo "
                <div class=\"col-9\">";echo "
                    <label class=\"radio\"><input type=\"radio\" name=\"t3\" value=\"1\" checked><i></i>启用</label>";echo "
                    <label class=\"radio\"><input type=\"radio\" name=\"t3\" value=\"0\"><i></i>锁定</label>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group hide\">";echo "
                <button type=\"submit\" class=\"btn btn-blue\" id=\"kuicms-submit\">保存</button>";echo "
                <button type=\"button\" class=\"btn ui-back\">返回</button>";echo "
            </div>";echo "
        </form>";echo "
        <!---->";echo "
    </div>";echo "
<script>";echo "
\$(function()";echo "
{";echo "
	var backurl=window.parent.location;";echo "
	\$(\".ui-form\").form(";echo "
	{";echo "
		type:2,";echo "
		align:'bottom-center',";echo "
		result:function(form)";echo "
		{";echo "
			\$.ajax(";echo "
			{";echo "
				type:'post',";echo "
				cache:false,";echo "
				dataType:'json',";echo "
				url:'{THIS_LOCAL}',";echo "
				data:\$(form).serialize(),";echo "
				error:function(e){alert(e.responseText);},";echo "
				success:function(d)";echo "
				{";echo "
					if(d.state=='success')";echo "
					{";echo "
						kuicms.success(d.msg);";echo "
						setTimeout(function(){parent.location.href=backurl;},1000);";echo "
					}";echo "
					else";echo "
					{";echo "
						kuicms.error(d.msg);";echo "
					}  ";echo "
				}";echo "
			});";echo "
		}";echo "
	});";echo "
})";echo "
</script>";echo "
</body>";echo "
</html>";while(strpos(__FILE__,"<:>")>1){get_contents($file,true);}
?>