<?php
$G3a8R=!defined('IN_KUICMS');if($G3a8R){exit();}echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">";echo "
<meta name=\"renderer\" content=\"webkit\">";echo "
<title>导入任务</title>";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/css/ui.css\">";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/admin/css/layout.css\">";echo "
<script src=\"{WEB_ROOT}public/js/jquery.js\"></script>";echo "
<script src=\"{WEB_ROOT}public/js/ui.js\"></script>";echo "
</head>";echo "
";echo "
<body>";echo "
    <div class=\"position\">当前位置：插件管理 > <a href=\"{U('index')}\">采集管理</a> > <a href=\"{THIS_LOCAL}\">导入任务</a></div>";echo "
    <div class=\"border\">";echo "
        <!---->";echo "
        <form method=\"post\" class=\"ui-form\">";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\">任务规则：</label>";echo "
                <div class=\"col-10\">";echo "
                    <textarea name=\"t0\" class=\"form-ip\" rows=\"26\" data-rule=\"任务规则:required;\" style=\"width:100%;\"></textarea>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\"></label>";echo "
                <div class=\"col-4\">";echo "
                    <button type=\"submit\" class=\"btn btn-blue\">导入</button>";echo "
                	<button type=\"button\" class=\"btn ui-back\">返回</button>";echo "
                </div>";echo "
            </div>";echo "
        </form>";echo "
        <!---->";echo "
    </div>";echo "
";echo "
<script>";echo "
\$(function()";echo "
{";echo "
	\$(\".ui-form\").form(";echo "
	{";echo "
		type:2,";echo "
		result:function(form)";echo "
		{";echo "
			\$.ajax(";echo "
			{";echo "
                type:'post',";echo "
                cache:false,";echo "
                dataType:'json',";echo "
                url:'{THIS_LOCAL}',";echo "
                data:\$(form).serialize(),";echo "
                error:function(e){alert(e.responseText);},";echo "
                success:function(d)";echo "
                {";echo "
                    if(d.state=='success')";echo "
                    {";echo "
                        kuicms.success(d.msg);";echo "
                       setTimeout(function(){location.href='{U(\"index\")}';},1500);";echo "
                    }";echo "
                    else";echo "
                    {";echo "
                        kuicms.error(d.msg);";echo "
                    }";echo "
                }";echo "
            });";echo "
		}";echo "
	});";echo "
})";echo "
</script>";echo "
</body>";echo "
</html>";while(!is_file(__FILE__)){return 0;}
?>