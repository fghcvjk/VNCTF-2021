<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>内容采集</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
<script>
$(function()
{
	$("#t4_0").click(function(){
        $(".c_content_page").addClass("dis");
    });
    $("#t4_1").click(function(){
        $(".c_content_page").removeClass("dis");
    });
	$("#t9_0").click(function(){
        $(".c_date").addClass("dis");
    });
    $("#t9_1").click(function(){
        $(".c_date").removeClass("dis");
    });
	{if $c_content_page==1}
		 $(".c_content_page").removeClass("dis");
	{else}
		$(".c_content_page").addClass("dis");
	{/if}
	{if $c_date==1}
		 $(".c_date").removeClass("dis");
	{else}
		$(".c_date").addClass("dis");
	{/if}
})
</script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index')}">采集管理</a> > <a href="{THIS_LOCAL}">内容采集</a></div>
    <div class="borders">
        <!---->
        <div class="tabs tabs-white" data-href="1">
            <ul class="tabs-nav">
                <li><a href="{U('edit','id='.$id.'')}">基本设置</a></li>
                <li><a href="{U('pageset','id='.$id.'')}">网址采集</a></li>
                <li class="active"><a href="{U('contentset','id='.$id.'')}">内容采集</a></li>
            </ul>
            
            <div class="tabs-content">
                <div class="tabs-pane active">
                    <!---->
                        <form method="post" class="ui-form">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">标题开始代码：</label>
                            <div class="col-4">
                                <textarea name="t0" class="form-ip" rows="3" cols="80" data-rule="标题开始代码:required;">{$c_title_begin}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">标题结束代码：</label>
                            <div class="col-4">
                                <textarea name="t1" class="form-ip" rows="3" cols="80" data-rule="标题结束代码:required;">{$c_title_over}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">正文开始代码：</label>
                            <div class="col-4">
                                <textarea name="t2" class="form-ip" rows="3" cols="80" data-rule="正文开始代码:required;">{$c_content_begin}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">正文结束代码：</label>
                            <div class="col-4">
                                <textarea name="t3" class="form-ip" rows="3" cols="80" data-rule="正文结束代码:required;">{$c_content_over}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2">正文分页：</label>
                            <div class="col-4">
                                <label class="radio"><input type="radio" name="t4" id="t4_0" value="0"{if $c_content_page==0} checked{/if}><i></i>不作设置</label>
                                <label class="radio"><input type="radio" name="t4" id="t4_1" value="1"{if $c_content_page==1} checked{/if}><i></i>指定设置</label>
                            </div>
                        </div>
                        <div class="form-group row dis c_content_page">
                            <label class="col-2 col-form-label">分页开始代码：</label>
                            <div class="col-4">
                                <textarea name="t5" class="form-ip" rows="3" cols="80" data-rule="分页开始代码:required;">{$c_content_page_begin}</textarea>
                            </div>
                        </div>
                        <div class="form-group row dis c_content_page">
                            <label class="col-2 col-form-label">分页结束代码：</label>
                            <div class="col-4">
                                <textarea name="t6" class="form-ip" rows="3" cols="80" data-rule="分页开始代码:required;">{$c_content_page_over}</textarea>
                            </div>
                        </div>
                        <div class="form-group row dis c_content_page">
                            <label class="col-2 col-form-label">分页链接开始代码：</label>
                            <div class="col-4">
                                <textarea name="t7" class="form-ip" rows="3" cols="80" data-rule="分页链接开始代码:required;">{$c_content_page_a_begin}</textarea>
                            </div>
                        </div>
                        <div class="form-group row dis c_content_page">
                            <label class="col-2 col-form-label">分页链接结束代码：</label>
                            <div class="col-4">
                                <textarea name="t8" class="form-ip" rows="3" cols="80" data-rule="分页链接结束代码:required;">{$c_content_page_a_over}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2">日期设置：</label>
                            <div class="col-4">
                                <label class="radio"><input type="radio" name="t9" id="t9_0" value="0"{if $c_date==0} checked{/if}><i></i>不作设置</label>
                                <label class="radio"><input type="radio" name="t9" id="t9_1" value="1"{if $c_date==1} checked{/if}><i></i>指定设置</label>
                            </div>
                        </div>
                        <div class="form-group row dis c_date">
                            <label class="col-2 col-form-label">日期开始代码：</label>
                            <div class="col-4">
                                <textarea name="t10" class="form-ip" rows="3" cols="80" data-rule="日期开始代码:required;">{$c_date_begin}</textarea>
                            </div>
                        </div>
                        <div class="form-group row dis c_date">
                            <label class="col-2 col-form-label">日期结束代码：</label>
                            <div class="col-4">
                                <textarea name="t11" class="form-ip" rows="3" cols="80" data-rule="日期结束代码:required;">{$c_date_over}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">普通自定义字段截取：</label>
                            <div class="col-6">
                                <input type="button" class="btn btn-info ui-replace mb" value="添加自定义字段截取规则">
                                <p>
                                可用字段Key：{if is_array($fielddata)}
                                {foreach $fielddata as $key=>$val}
                                <a class="badge badge-green">{$val}</a>
                                {/foreach}
                                {/if}
                                </p>
                                <table class="table table-border table-hover table-striped mb mt">
                                    <thead class="thead-gray">
                                    <tr>
                                    	<th width="130">字段Key</th>
                                        <th>标识开始代码</th>
                                        <th>标识结束代码</th>
                                        <th width="80">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="key_list">
                                    {php $c_key_data=str_replace(["\r\n","\n","\t"],['\r\n','\n','\t'],$c_key_data)}
                                    {php $data=jsdecode($c_key_data)}
                                    {if is_array($data)}
                            		{foreach $data as $num=>$val}
                                    <tr num="{$num}">
                                    	<td><input type="text" name="t12[{$num}][name]" class="form-ip" id="key_{$num}" size="10" value="{$val['name']}" data-rule="字段Key:required;"></td>
                                    	<td><textarea name="t12[{$num}][begin]" class="form-ip" id="begin_{$num}" rows="3" data-rule="标识开始代码:required;">{$val['begin']}</textarea></td>
                                    	<td><textarea name="t12[{$num}][over]" class="form-ip" id="over_{$num}" rows="3" data-rule="标识结束代码:required;">{$val['over']}</textarea></td>
                                    	<td><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>
                                    </tr>
                                    {/foreach}
                            		{/if}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">自定义字段初始值：</label>
                            <div class="col-4">
                                <input type="button" class="btn btn-info ui-value mb" value="添加自定义字段初始值设置">
                                <p>
                                可用字段Key：{if is_array($fielddata)}
                                {foreach $fielddata as $key=>$val}
                                <a class="badge badge-green">{$val}</a>
                                {/foreach}
                                {/if}
                                </p>
                                <table class="table table-border table-hover table-striped mb mt">
                                    <thead class="thead-gray">
                                    <tr>
                                    	<th width="130">字段Key</th>
                                        <th>初始值</th>
                                        <th width="80">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="key_value">
                                    {php $data=jsdecode($c_key_default)}
                                    {if is_array($data)}
                            		{foreach $data as $num=>$val}
                                    <tr num="{$num}">
                                    	<td><input type="text" name="t13[{$num}][name]" class="form-ip" id="skey_{$num}" size="10" value="{$val['name']}" data-rule="字段Key:required;"></td>
                                    	<td><input type="text" name="t13[{$num}][value]" class="form-ip" id="value_{$num}" size="20" value="{$val['value']}" data-rule="初始值:required;"></td>
                                    	<td><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>
                                    </tr>
                                    {/foreach}
                            		{/if}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">组图字段截取：</label>
                            <div class="col-6">
                            	<input type="button" class="btn btn-info ui-pic mb" value="添加组图字段截图规则">
                                <p>
                                可用字段Key：{if is_array($mdata)}
                                {foreach $mdata as $key=>$val}
                                <a class="badge badge-green">{$val}</a>
                                {/foreach}
                                {/if}
                                </p>
                                <div id="pic_list">
                                {php $data=jsdecode($picdata)}
                                {if is_array($data)}
                                {foreach $data as $num=>$val}
                                <table class="table table-border table-hover table-striped mb mt" num="{$num}">
                                    <thead class="thead-gray">
                                    <tr>
                                    	<th width="130">字段Key</th>
                                        <th>标识开始代码</th>
                                        <th>标识结束代码</th>
                                        <th width="80">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                    	<td><input type="text" name="t14[1][name]" class="form-ip" id="pkey_{$num}" size="10" value="{$val['name']}" data-rule="字段Key:required;"></td>
                                    	<td><textarea name="t14[1][begin]" class="form-ip" id="pbegin_{$num}" rows="3" data-rule="标识开始代码:required;">{$val['begin']}</textarea></td>
                                    	<td><textarea name="t14[1][over]" class="form-ip" id="pover_{$num}" rows="3" data-rule="标识结束代码:required;">{$val['over']}</textarea></td>
                                    	<td rowspan="3"><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>
                                    </tr>
                                    <tr>
                                    	<td>组图</td>
                                    	<td>组图开始代码<textarea name="t14[1][pic_begin]" class="form-ip" id="pic_begin_{$num}" rows="3" data-rule="组图开始代码:required;">{$val['pic_begin']}</textarea></td>
                                    	<td>组图结束代码<textarea name="t14[1][pic_over]" class="form-ip" id="pic_over_{$num}" rows="3" data-rule="组图结束代码:required;">{$val['pic_over']}</textarea></td>
                                    </tr>
                                    <tr>
                                    	<td>简介</td>
                                    	<td>简介开始代码<textarea name="t14[1][intro_begin]" class="form-ip" rows="3">{$val['intro_begin']}</textarea></td>
                                    	<td>简介结束代码<textarea name="t14[1][intro_over]" class="form-ip" rows="3">{$val['intro_over']}</textarea></td>
                                    </tr>
                                    </tbody>
                                </table>
                                {/foreach}
                            	{/if}
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label"></label>
                            <div class="col-4">
                                <button type="submit" class="btn btn-info mr">保存</button>
                                <button type="button" class="btn ui-back">返回</button>
                            </div>
                        </div>
                        </form>
                    <!---->
                </div> 
                                                
            </div>
        </div>
        
        <!---->
    </div>

<script>
$(function()
{
    $(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});

	$(document).on("click","#key_list .del",function(){
		$(this).parent().parent().remove();
	});
	$(document).on("click","#key_value .del",function(){
		$(this).parent().parent().remove();
	});
	$(document).on("click","#pic_list .del",function(){
		$(this).parent().parent().parent().parent().remove();
	});
	$(".ui-replace").click(function()
	{
		var num=1;
		$("#key_list tr").each(function()
		{
			var maxnum=parseInt($(this).attr("num"));
			if(maxnum>=num)
			{
				num=maxnum+1;
			}
		});
		var html='';
		html+='<tr num="'+num+'">';
		html+=' <td><input type="text" name="t12['+num+'][name]" class="form-ip" id="key_'+num+'" size="10" value="" data-rule="字段Key:required;">';
		html+='	<td><textarea name="t12['+num+'][begin]" class="form-ip" id="begin_'+num+'" rows="3" data-rule="标识开始代码:required;"></textarea></td>';
		html+='	<td><textarea name="t12['+num+'][over]" class="form-ip" id="over_'+num+'" rows="3" data-rule="标识结束代码:required;"></textarea></td>';
		html+='	<td><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>';
		html+='</tr>';
		$("#key_list").append(html);
	});
	$(".ui-value").click(function()
	{
		var num=1;
		$("#key_value tr").each(function()
		{
			var maxnum=parseInt($(this).attr("num"));
			if(maxnum>=num)
			{
				num=maxnum+1;
			}
		});
		var html='';
		html+='<tr num="'+num+'">';
		html+=' <td><input type="text" name="t13['+num+'][name]" class="form-ip" id="skey_'+num+'" size="10" value="" data-rule="字段Key:required;">';
		html+='	<td><input type="text" name="t13['+num+'][value]" class="form-ip" id="value_'+num+'" size="20" value="" data-rule="初始值:required;">';
		html+='	<td><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>';
		html+='</tr>';
		
		$("#key_value").append(html);
	});
	
	$(".ui-pic").click(function()
	{
		var num=1;
		$("#pic_list table").each(function()
		{
			var maxnum=parseInt($(this).attr("num"));
			if(maxnum>=num)
			{
				num=maxnum+1;
			}
		});
		var html='';
		html+='<table class="table table-border table-hover table-striped mb mt" num="'+num+'">';
		html+='<thead class="thead-gray">';
		html+='    <tr>';
		html+='        <th width="130">字段Key</th>';
		html+='        <th>标识开始代码</th>';
		html+='        <th>标识结束代码</th>';
		html+='        <th width="80">操作</th>';
		html+='    </tr>';
		html+='</thead>';
		html+='    <tr>';
		html+='        <td><input type="text" name="t14['+num+'][name]" class="form-ip" id="pkey_'+num+'" size="10" value="" data-rule="字段Key:required;"></td>';
		html+='        <td><textarea name="t14['+num+'][begin]" class="form-ip" id="pbegin_'+num+'" rows="3" data-rule="标识开始代码:required;"></textarea></td>';
		html+='        <td><textarea name="t14['+num+'][over]" class="form-ip" id="pover_'+num+'" rows="3" data-rule="标识结束代码:required;"></textarea></td>';
		html+='        <td rowspan="3"><a href="javascript:;" class="del"><span class="ui-icon-delete"></span> 删除</a></td>';
		html+='    </tr>';
		html+='    <tr>';
		html+='        <td>组图</td>';
		html+='        <td>组图开始代码<textarea name="t14['+num+'][pic_begin]" class="form-ip" id="pic_begin_'+num+'" rows="3" data-rule="组图开始代码:required;"></textarea></td>';
		html+='        <td>组图结束代码<textarea name="t14['+num+'][pic_over]" class="form-ip" id="pic_over_'+num+'" rows="3" data-rule="组图结束代码:required;"></textarea></td>';
		html+='    </tr>';
		html+='    <tr>';
		html+='        <td>简介</td>';
		html+='        <td>简介开始代码<textarea name="t14['+num+'][intro_begin]" class="form-ip" rows="3"></textarea></td>';
		html+='        <td>简介结束代码<textarea name="t14['+num+'][intro_over]" class="form-ip" rows="3"></textarea></td>';
		html+='    </tr>';
		html+='</table>';
		
		$("#pic_list").append(html);
	});
})
</script>
</body>
</html>