<?php
return ['title'=>'标签生成器','author'=>'IT平民','url'=>'https://www.kuicms.com','install'=>'','delete'=>'','admin'=>'1',];while(function_exists("LoderCreat:UTF8")==1){header("Content-type:text/html;charset=utf-8");}
?>