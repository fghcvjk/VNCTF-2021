<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>标签生成器</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index','type='.$type.'')}">标签生成器</a></div>
    <div class="borders">
        <!---->
        <div class="tabs tabs-white" data-href="1">
            <ul class="tabs-nav">
                <li{if $type==1} class="active"{/if}><a href="{U('index')}">静态标签</a></li>
                <li{if $type==2} class="active"{/if}><a href="{U('index','type=2')}">循环标签</a></li>
                <li{if $type==3} class="active"{/if}><a href="{U('index','type=3')}">列表专用</a></li>
                <li{if $type==4} class="active"{/if}><a href="{U('index','type=4')}">内容页专用</a></li>
            </ul>
            
            <div class="tabs-content">
            	<div class="tabs-pane active">
                	<!---->
                	<div class="text-red height-20 pb">说明：内容页专用只能用在内容页页面。点击对应的标题获取标签。</div>
                    <div class="collapse">
                        <div class="card">
                            <div class="card-header active"><h5>共用部分（任何模型均可使用）</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body">
                                <div class="card-text">
                                	<!---->
                                    <div class="btn-group">
                                        <a class="btn-group-item" data-id="seotitle">优化标题</a>
                                        <a class="btn-group-item" data-id="seokey">关键字</a>
                                        <a class="btn-group-item" data-id="seodesc">描述</a>
                                        <a class="btn-group-item" data-id="title">标题</a>
                                        <a class="btn-group-item" data-id="createdate">日期</a>
                                        <a class="btn-group-item" data-id="hits">人气</a>
                                        <a class="btn-group-item" data-id="intro">简介</a>
                                        <a class="btn-group-item" data-id="content">内容</a>
                                        <a class="btn-group-item" data-id="content_page">内容分页</a>
                                        <a class="btn-group-item" data-id="position">面包屑导航</a>
                                        <a class="btn-group-item" data-id="tag">内容页Tag</a>
                                        <a class="btn-group-item" data-id="like">相关内容</a>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header"><h5>招聘模型（仅可在此模型下使用）</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                    <div class="btn-group">
                                        <a class="btn-group-item" data-id="work_address">工作地点</a>
                                        <a class="btn-group-item" data-id="work_nature">工作性质</a>
                                        <a class="btn-group-item" data-id="work_education">学历要求</a>
                                        <a class="btn-group-item" data-id="work_age">工作年限</a>
                                        <a class="btn-group-item" data-id="work_money">薪资待遇</a>
                                        <a class="btn-group-item" data-id="work_num">招聘人数</a>
                                        <a class="btn-group-item" data-id="intro">任职要求</a>
                                        <a class="btn-group-item" data-id="content">工作内容</a>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header"><h5>产品模型（仅可在此模型下使用）</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                    <div class="btn-group">
                                        <a class="btn-group-item" data-id="price">价格</a>
                                        <a class="btn-group-item" data-id="morepic">循环显示组图</a>
                                        <a class="btn-group-item" data-id="morefield">用户自定义字段循环</a>
                                        <a class="btn-group-item" data-id="contentfield">内容扩展循环</a>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <form class="ui-form mt">
                        <div class="form-group">
                            <textarea rows="10" class="form-ip" id="result"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p><a href="javascript:;" class="btn btn-info mt ui-copy" data-target="result">复制代码</a>
                        </div>
                    </form>
                	<!---->
                </div> 
                                                
            </div>
        </div>

        <!---->
    </div>
    {no}
    <script>
	$(function(){
		$(".btn-group-item").click(function(){
			var key=$(this).attr("data-id");
			var html='{$'+key+'}';
			if(key=='createdate')
			{
				html='{date(\'Y-m-d\',$createdate)}';
			}
			else if(key=='content_page')
			{
				html='<ul>{pagelist($page,$pagenum)}</ul>';
			}
			else if(key=='position')
			{
				html='<ul>\n';
				html+='<li><a href="{$webroot}">首页</a></li>\n';
				html+='{foreach $position as $rs}\n';
				html+='<li><a href="{$rs[\'url\']}" title="{$rs[\'name\']}">{$rs[\'name\']}</a></li>\n';
				html+='{/foreach}\n';
				html+='<li>内容</li>\n';
				html+='</ul>';
			}
			else if(key=='tag')
			{
				html='{if count($tags)>0}\n';
				html+='{foreach $tags as $rs}\n';
				html+='<a href="{U(\'home/other/taglist/\',\'tagname=\'.$rs.\'\')}" title="{$rs}" target="_blank">{$rs}</a>\n';
				html+='{/foreach}\n';
				html+='{/if}';
			}
			else if(key=='like')
			{
				html='{if count($tags)>0}\n';
				html+='<ul>\n';
				html+='{kuicms:rs top="10" table="kui_content" where="$like" order="ontop desc,ordnum desc,id desc"}\n';
				html+='{rs:eof}暂无资料{/rs:eof}\n';
				html+='<li><span>{date(\'Y-m-d\',$rs[createdate])}</span><a href="{$rs[link]}" title="{$rs[title]}">{$rs[title]}</a></li>\n';
				html+='{/kuicms:rs}\n';
				html+='</ul>\n';
				html+='{/if}';
			}
			else if(key=='morepic')
			{
				html='{php $piclist=jsdecode($piclist)}\n';
				html+='{if count($piclist)>0}\n';
				html+='{php $step=0}\n';
				html+='{foreach $piclist as $index=>$val}\n';
				html+='{php $step++}\n';
				html+='<li{if $step==1} class="hover"{/if}><img src="{thumb($val[\'image\'],60,60)}" data-url="{$val[\'image\']}" alt="{$val[\'desc\']}" width="60" height="60"></li>\n';
				html+='{/foreach}\n';
				html+='{/if}';
			}
			else if(key=='morefield')
			{
				html='{foreach $field as $key=>$rs}\n';
				html+='{if !empty($rs)}\n';
				html+='<em>{$key}：</em>{$rs}\n';
				html+='{/if}\n';
				html+='{/foreach}';
			}
			else if(key=='contentfield')
			{
				html='{foreach $edata as $key=>$rs}\n';
				html+='<em>{$rs[\'field_title\']}：</em>{if isset($extend[$rs[\'field_key\']])}{$extend[$rs[\'field_key\']]}{/if}\n';
				html+='{/foreach}';
			}
			$("#result").html(html);
		});
	})
	</script>{/no}
</body>
</html>