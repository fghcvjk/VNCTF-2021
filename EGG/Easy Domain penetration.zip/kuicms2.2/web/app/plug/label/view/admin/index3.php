<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>标签生成器</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index','type='.$type.'')}">标签生成器</a></div>
    <div class="borders">
        <!---->
        <div class="tabs tabs-white" data-href="1">
            <ul class="tabs-nav">
                <li{if $type==1} class="active"{/if}><a href="{U('index')}">静态标签</a></li>
                <li{if $type==2} class="active"{/if}><a href="{U('index','type=2')}">循环标签</a></li>
                <li{if $type==3} class="active"{/if}><a href="{U('index','type=3')}">列表专用</a></li>
                <li{if $type==4} class="active"{/if}><a href="{U('index','type=4')}">内容页专用</a></li>
            </ul>
            
            <div class="tabs-content">
            	<div class="tabs-pane active">
                	<!---->
                	<div class="text-red height-20 pb">说明：列表页标签只能用在列表页面。点击对应的标题获取标签。</div>
                    <div class="btn-group">
                        <a class="btn-group-item" data-id="catetitle">优化标题</a>
                        <a class="btn-group-item" data-id="catekey">关键字</a>
                        <a class="btn-group-item" data-id="catedesc">描述</a>
                        <a class="btn-group-item" data-id="catename">栏目名称</a>
                        <a class="btn-group-item" data-id="position">面包屑导航</a>
                        <a class="btn-group-item" data-id="list">列表循环</a>
                    </div>
                    <form class="ui-form mt">
                        <div class="form-group">
                            <textarea rows="10" class="form-ip" id="result"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p><a href="javascript:;" class="btn btn-info mt ui-copy" data-target="result">复制代码</a>
                        </div>
                    </form>
                	<!---->
                </div> 
                                                
            </div>
        </div>

        <!---->
    </div>
    {no}
    <script>
	$(function(){
		$(".btn-group-item").click(function(){
			var key=$(this).attr("data-id");
			var html='{$'+key+'}';
			if(key=='position')
			{
				html='<ul>\n';
				html+='<li><a href="{$webroot}">首页</a></li>\n';
				html+='{foreach $position as $rs}\n';
				html+='<li><a href="{$rs[\'url\']}" title="{$rs[\'name\']}">{$rs[\'name\']}</a></li>\n';
				html+='{/foreach}\n';
				html+='<li>列表</li>\n';
				html+='</ul>';
			}
			else if(key=='list')
			{
				html='{kuicms:rs pagesize="$catepage" table="kui_content" join="$join" where="$where" order="ontop desc,ordnum desc,id desc"}\n';
				html+='{rs:eof}暂无资料{/rs:eof}\n';
				html+='标题：<a href="{$rs[link]}" title="{$rs[title]}">{cutstr($rs[title],50,1)}</a>\n';
				html+='日期：{date(\'Y-m-d\',$rs[createdate])}\n';
				html+='简介：{cutstr($rs[intro],200,1)}\n';
				html+='缩略图：<img src="{$rs[pic]}">\n';
				html+='{/kuicms:rs}\n';
				html+='<div class="pagelist"><ul>{$showpage}</ul></div>\n\n';
				html+='循环部分的标签格式：{$rs[字段名]}  主表和副表的任何字段均可直接调用\n';
			}
			$("#result").html(html);
		});
	})
	</script>{/no}
</body>
</html>