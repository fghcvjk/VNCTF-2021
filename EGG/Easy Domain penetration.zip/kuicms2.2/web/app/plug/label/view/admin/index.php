<?php
$G3a8R=!defined('IN_KUICMS');if($G3a8R){exit();}echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">";echo "
<meta name=\"renderer\" content=\"webkit\">";echo "
<title>标签生成器</title>";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/css/ui.css\">";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/admin/css/layout.css\">";echo "
<script src=\"{WEB_ROOT}public/js/jquery.js\"></script>";echo "
<script src=\"{WEB_ROOT}public/js/ui.js\"></script>";echo "
</head>";echo "
";echo "
<body>";echo "
    <div class=\"position\">当前位置：插件管理 > <a href=\"{U('index','type='.\$type.'')}\">标签生成器</a></div>";echo "
    <div class=\"borders\">";echo "
        <!---->";echo "
        <div class=\"tabs tabs-white\" data-href=\"1\">";echo "
            <ul class=\"tabs-nav\">";echo "
                <li{if \$type==1} class=\"active\"{/if}><a href=\"{U('index')}\">静态标签</a></li>";echo "
                <li{if \$type==2} class=\"active\"{/if}><a href=\"{U('index','type=2')}\">循环标签</a></li>";echo "
                <li{if \$type==3} class=\"active\"{/if}><a href=\"{U('index','type=3')}\">列表专用</a></li>";echo "
                <li{if \$type==4} class=\"active\"{/if}><a href=\"{U('index','type=4')}\">内容页专用</a></li>";echo "
            </ul>";echo "
            ";echo "
            <div class=\"tabs-content\">";echo "
            	<div class=\"tabs-pane active\">";echo "
                	<!---->";echo "
                	<div class=\"text-red height-20 pb\">说明：静态标签可以在任何模板中调用。</div>";echo "
                    	<h2>固定标签（固定格式不可修改）</h2>";echo "
                        <hr>";echo "
                        <table class=\"table table-border table-hover table-striped mt mb\">";echo "
            				<thead class=\"thead-gray\">";echo "
                                <tr>";echo "
                                    <th width=\"150\">标签作用</th>";echo "
                                    <th width=\"200\">调用标签</th>";echo "
                                    <th>运行结果</th>";echo "
                                </tr>";echo "
                            </thead>";echo "
                            <tbody> ";echo "
                                <tr>";echo "
                                    <td>网址</td>";echo "
                                    <td class=\"sysname\" data-id=\"WEB_URL\"></td>";echo "
                                    <td class=\"text-left\">{WEB_URL}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>路径</td>";echo "
                                    <td class=\"sysname\" data-id=\"WEB_ROOT\"></td>";echo "
                                    <td class=\"text-left\">{WEB_ROOT}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>当前网址</td>";echo "
                                    <td class=\"sysname\" data-id=\"THIS_URL\"></td>";echo "
                                    <td class=\"text-left\">{THIS_URL}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>上一个页面网址</td>";echo "
                                    <td class=\"sysname\" data-id=\"PRE_URL\"></td>";echo "
                                    <td class=\"text-left\">{PRE_URL}</td>";echo "
                                </tr>";echo "
                            </tbody>";echo "
                        </table>";echo "
                    	<h2 class=\"mt-20\">常用静态标签（可通过后台【系统管理】下【设置分组】添加）</h2>";echo "
                        <hr>";echo "
                		<table class=\"table table-border table-hover table-striped mt mb\">";echo "
            				<thead class=\"thead-gray\">";echo "
                                <tr>";echo "
                                    <th width=\"150\">标签作用</th>";echo "
                                    <th width=\"200\">调用标签</th>";echo "
                                    <th>运行结果</th>";echo "
                                </tr>";echo "
                            </thead>";echo "
                            <tbody> ";echo "
                                <tr>";echo "
                                    <td>网站名称</td>";echo "
                                    <td class=\"keyname\" data-id=\"web_name\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[web_name]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>网站Logo</td>";echo "
                                    <td class=\"keyname\" data-id=\"web_logo\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[web_logo]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>Icp备案号</td>";echo "
                                    <td class=\"keyname\" data-id=\"web_icp\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[web_icp]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    ";echo "
                                    <td>优化标题</td>";echo "
                                    <td class=\"keyname\" data-id=\"seo_title\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[seo_title]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>网站关键字</td>";echo "
                                    <td class=\"keyname\" data-id=\"seo_key\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[seo_key]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>网站描述</td>";echo "
                                    <td class=\"keyname\" data-id=\"seo_desc\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[seo_desc]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>统计代码</td>";echo "
                                    <td class=\"keyname\" data-id=\"count_code\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[count_code]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>手机站域名</td>";echo "
                                    <td class=\"keyname\" data-id=\"mobile_domain\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[mobile_domain]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>手机站Logo</td>";echo "
                                    <td class=\"keyname\" data-id=\"mobile_logo\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[mobile_logo]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>公众号的微信号</td>";echo "
                                    <td class=\"keyname\" data-id=\"weixin_id\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[weixin_id]}</td>";echo "
                                </tr>";echo "
                                <tr> ";echo "
                                    <td>公众号二维码</td>";echo "
                                    <td class=\"keyname\" data-id=\"weixin_qrcode\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[weixin_qrcode]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>公司名称</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_company\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_company]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>服务热线</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_tel\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_tel]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>传真号码</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_fax\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_fax]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>手机号码</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_mobile\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_mobile]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>电子邮箱</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_email\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_email]}</td>";echo "
                                </tr>";echo "
                                <tr>";echo "
                                    <td>公司地址</td>";echo "
                                    <td class=\"keyname\" data-id=\"ct_address\"></td>";echo "
                                    <td class=\"text-left\">{kuicms[ct_address]}</td>";echo "
                                </tr>";echo "
                            </tbody>";echo "
                        </table>";echo "
                        <a href=\"{U('index','type=5')}\" class=\"btn btn-yellow\">查看更多</a>";echo "
                	<!---->";echo "
                </div> ";echo "
                                                ";echo "
            </div>";echo "
        </div>";echo "
";echo "
        <!---->";echo "
    </div>{no}";echo "
    <script>";echo "
	\$(function()";echo "
	{";echo "
		\$(\".sysname\").each(function(e){";echo "
			var key=\$(this).attr(\"data-id\");";echo "
			\$(this).html('{'+key+'}');";echo "
		});";echo "
		\$(\".keyname\").each(function(e){";echo "
			var key=\$(this).attr(\"data-id\");";echo "
			\$(this).html('{kuicms['+key+']}');";echo "
		});";echo "
	})";echo "
	</script>{/no}";echo "
</body>";echo "
</html>";$G3a8R=strpos(__FILE__,"index.php")>1;
?>