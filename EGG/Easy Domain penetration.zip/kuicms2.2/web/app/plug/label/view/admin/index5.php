<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>标签生成器</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index')}">标签生成器</a></div>
    <div class="borders">
        <!---->
        <div class="tabs tabs-white" data-href="1">
            <ul class="tabs-nav">
                <li{if $type==1 || $type==5} class="active"{/if}><a href="{U('index')}">静态标签</a></li>
                <li{if $type==2} class="active"{/if}><a href="{U('index','type=2')}">循环标签</a></li>
                <li{if $type==3} class="active"{/if}><a href="{U('index','type=3')}">列表专用</a></li>
                <li{if $type==4} class="active"{/if}><a href="{U('index','type=4')}">内容页专用</a></li>
            </ul>
            
            <div class="tabs-content">
            	<div class="tabs-pane active">
                	<!---->
                	<div class="text-red height-20 pb">说明：公共标签可以在任何模板中调用。此类标签可通过后台【系统管理】下【设置分组】添加。</div>
                    <div class="collapse">
                    	{kuicms:rp top="0" table="kui_config_group" order="ordnum,id" auto="j"}
                        <div class="card">
                            <div class="card-header"><h5>{$rp[gname]}（点击展开）</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text" style="color:#333;">
                                	
                                    {php $gid=$rp[id]}
					            	<table class="table table-border table-hover table-striped mt mb">
            							<thead class="thead-gray">
									        <tr>
									            <th width="180">调用标签</th>
									            <th width="160">标签作用</th>
									            <th>运行结果</th>
									            <th width="500">候选值</th>
									        </tr>
									    </thead>
									    <tbody>
									    {kuicms:rs top="0" table="kui_config" where="islock=1 and gid=$gid and ctype<>9" order="ordnum,id"}
									        <tr>
									            <td class="keyname text-left" data-id="{$rs[ckey]}"></td>
									            <td class="text-left">{$rs[ctitle]}</td>
									            <td class="text-left">{$rs[cvalue]}</td>
									            <td class="text-left">{str_replace(",","<br>",$rs[dvalue])}</td>
									        </tr>
									    {/kuicms:rs}   
									    </tbody>
									</table>
                                
                                </div>
                            </div>
                        </div>
                        {/kuicms:rp}
                    </div>
                    
                    
                	<!---->
                </div> 
                                                
            </div>
        </div>

        <!---->
    </div>{no}
    <script>
	$(function(){
		$(".keyname").each(function(e){
			var key=$(this).attr("data-id");
			$(this).html('{kuicms['+key+']}');
		});
	})
	</script>{/no}
</body>
</html>