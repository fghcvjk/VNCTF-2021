<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>标签生成器</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index','type='.$type.'')}">标签生成器</a></div>
    <div class="borders">
        <!---->
        
        <div class="tabs tabs-white" data-href="1">
            <ul class="tabs-nav">
                <li{if $type==1} class="active"{/if}><a href="{U('index')}">静态标签</a></li>
                <li{if $type==2} class="active"{/if}><a href="{U('index','type=2')}">循环标签</a></li>
                <li{if $type==3} class="active"{/if}><a href="{U('index','type=3')}">列表专用</a></li>
                <li{if $type==4} class="active"{/if}><a href="{U('index','type=4')}">内容页专用</a></li>
            </ul>
            
            <div class="tabs-content">
            	<div class="tabs-pane active">
                	<!---->
                	<div class="text-red height-20 pb">说明：循环标签可以在任何模板中调用。生成的标签请自己配合html代码组合，样式自己书写。</div>
                    
                    <div class="collapse">
                        <div class="card">
                            <div class="card-header"><h5>栏目标签</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form category" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">调用数量：</label>
                                        <div class="col-4">
                                            <input name="t0" type="text" value="10" class="form-ip" maxlength="3" data-rule="数量:required;int;"><span class="input-tips">为 0 时显示全部</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">所属分类：</label>
                                        <div class="col-4">
                                            <select name="t1" class="form-ip">
                                                <option value="0">一级分类</option>
                                                {foreach C('category') as $rs}
                                                <option value="{$rs['cateid']}">{str_repeat("　",$rs['depth'])}{$rs['catename']}</option>
                                                {/foreach}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">截取栏目名称长度：</label>
                                        <div class="col-4">
                                            <input name="t2" type="text" value="0" class="form-ip" maxlength="3" data-rule="栏目名称长度:required;int;"><span class="input-tips">为 0 时不截取</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2">属性设置：</label>
                                        <div class="col-4">
                                            <label class="checkbox"><input type="checkbox" name="t3[]" id="t3" value="1" checked><i></i>导航显示</label>
                                            <label class="checkbox"><input type="checkbox" name="t4[]" id="t4" value="1"><i></i>截取栏目名称时显示省略号</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="category">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header"><h5>内容标签</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form content" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">数据表：</label>
                                        <div class="col-4">
                                            <select name="t10" class="form-ip" data-rule="数据表:required;">
                                                <option value="content">主表（kui_content）</option>
                                                {kuicms:rs top="0" table="kui_model" where="islock=1" order="ordnum,id"}
                                                <option value="{$rs[tablename]}">{$rs[title]}（kui_{$rs[tablename]}）</option>
                                                {/kuicms:rs}
                                            </select><span class="input-tips">如需调用自定义字段，请选择对应的模型表</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">调用数量：</label>
                                        <div class="col-4">
                                            <input name="t0" type="text" value="10" class="form-ip" maxlength="3" data-rule="数量:required;int;"><span class="input-tips">为 0 时显示全部</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">所属分类：</label>
                                        <div class="col-4">
                                            <select name="t1" class="form-ip">
                                                <option value="0">不设置类别</option>
                                                {foreach C('category') as $rs}
                                                <option value="{$rs['cateid']}">{str_repeat("　",$rs['depth'])}{$rs['catename']}</option>
                                                {/foreach}
                                            </select>
                                        </div>
                                        <div class="col-4 col-form-label pl">
                                            <label class="checkbox"><input type="checkbox" name="t2[]" id="t2" value="1" checked><i></i>包含子类</label>
                                            <label class="checkbox"><input type="checkbox" name="t11[]" id="t11" value="1"><i></i>包含副栏目</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2">查询条件：</label>
                                        <div class="col-6">
                                            <label class="checkbox"><input type="checkbox" name="t3[]" id="t3_1" value="1"><i></i>内容推荐</label>
                                            <label class="checkbox"><input type="checkbox" name="t3[]" id="t3_2" value="2"><i></i>内容置顶</label>
                                            <label class="checkbox"><input type="checkbox" name="t3[]" id="t3_3" value="3"><i></i>有缩略图</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">排序条件：</label>
                                        <div class="col-4">
                                            <select name="t4" class="form-ip">
                                                <option value="0">默认排序</option>
                                                <option value="1">按发布时间（降序）</option>
                                                <option value="2">按发布时间（升序）</option>
                                                <option value="3">按访问人气（降序）</option>
                                                <option value="4">按访问人气（升序）</option>
                                                <option value="5">随机排序</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">日期格式：</label>
                                        <div class="col-4">
                                            <select name="t5" class="form-ip">
                                                <option value="1">Y-m-d（{date('Y-m-d')}）</option>
                                                <option value="2">m-d（{date('m-d')}）</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">截取标题长度：</label>
                                        <div class="col-4">
                                            <input name="t6" type="text" value="50" class="form-ip" maxlength="3" data-rule="标题长度:required;int;"><span class="input-tips">为 0 时不截取</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">截取简介长度：</label>
                                        <div class="col-4">
                                            <input name="t7" type="text" value="200" class="form-ip" maxlength="3" data-rule="简介长度:required;int;"><span class="input-tips">为 0 时不截取</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2">属性设置：</label>
                                        <div class="col-4">
                                            <label class="checkbox"><input type="checkbox" name="t8[]" id="t8" value="1" checked><i></i>截取标题时显示省略号</label>
                                            <label class="checkbox"><input type="checkbox" name="t9[]" id="t9" value="1" checked><i></i>截取简介时显示省略号</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="content">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header"><h5>单页标签</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form page" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">所属分类：</label>
                                        <div class="col-4">
                                            <select name="t0" class="form-ip" data-rule="所属分类:required;">
                                                <option value="">请选择分类</option>
                                                {foreach C('category') as $rs}
                                                <option value="{$rs['cateid']}"{if $rs['catetype']!=-1} disabled{/if}>{str_repeat("　",$rs['depth'])}{$rs['catename']}</option>
                                                {/foreach}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="page">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header"><h5>广告标签</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form ad" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">广告选择：</label>
                                        <div class="col-4">
                                            <select name="t0" class="form-ip" data-rule="广告选择:required;">
                                                <option value="">请选择广告</option>
                                                {kuicms:rs top="0" table="kui_ad" where="1=1" order="ordnum,id"}
                                                <option value="{$rs[id]}">{$rs[title]}</option>
                                                {/kuicms:rs}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="ad">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header"><h5>友情链接标签</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form link" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">链接类型：</label>
                                        <div class="col-4">
                                            <select name="t0" class="form-ip" data-rule="链接类型:required;">
                                                <option value="">请选择链接类型</option>
                                                <option value="1">文字链接</option>
                                                <option value="2">Logo链接</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">调用数量：</label>
                                        <div class="col-4">
                                            <input name="t1" type="text" value="0" class="form-ip" maxlength="3" data-rule="数量:required;int;"><span class="input-tips">为 0 时显示全部</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">截取标题长度：</label>
                                        <div class="col-4">
                                            <input name="t2" type="text" value="0" class="form-ip" maxlength="3" data-rule="标题长度:required;int;"><span class="input-tips">为 0 时不截取</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2">属性设置：</label>
                                        <div class="col-4">
                                            <label class="checkbox"><input type="checkbox" name="t3[]" id="t3" value="1"><i></i>截取标题时显示省略号</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="link">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header"><h5>自定义数据表调用</h5><div class="card-header-more"><span class="ui-icon-right"></span></div></div>
                            <div class="card-body hide">
                                <div class="card-text">
                                <!---->
                                <form class="ui-form other" method="post">
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">数据表：</label>
                                        <div class="col-4">
                                            <select name="t0" class="form-ip" id="tablelist" data-rule="数据表:required;">
                                                <option value="">请选择数据表</option>
                                                {foreach $db as $rs}
                                                <option value="{$rs['Name']}">{$rs['Name']}</option>
                                                {/foreach}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">调用数量：</label>
                                        <div class="col-4">
                                            <input name="t1" type="text" value="10" class="form-ip" maxlength="3" data-rule="数量:required;int;"><span class="input-tips">为 0 时显示全部</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">查询条件：</label>
                                        <div class="col-4">
                                            <input name="t2" type="text" class="form-ip" maxlength="255">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-2 col-form-label">排序条件：</label>
                                        <div class="col-4">
                                            <input name="t3" type="text" class="form-ip" maxlength="255">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-2"></label>
                                        <div class="col-4">
                                        <button type="submit" class="btn btn-info mr-sm">生成标签</button>
                                        </div>
                                    </div>
                                    <div class="form-group row dis" id="other">
                                        <label class="col-2 col-form-label">生成的结果：</label>
                                        <div class="col-10">
                                            <textarea rows="6" class="form-ip"></textarea><p class="input-tips">请将生成的代码复制到您的模板中</p>
                                        </div>
                                    </div>
                                </form>
                                <!---->                               
                                </div>
                            </div>
                        </div>
                        
                    </div>
 
                	<!---->
                </div> 
                                                
            </div>
        </div>
        
        <!---->
    </div>
<script>
$(function()
{
	$(".category").form(
	{
		type:2,
		result:function(form)
		{
			$("#category").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("category")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#category").removeClass("dis");
                    	$("#category textarea").html(d);
					},500)
                }
            });
		}
	});
	$(".content").form(
	{
		type:2,
		result:function(form)
		{
			$("#content").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("content")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#content").removeClass("dis");
                    	$("#content textarea").html(d);
					},500)
                }
            });
		}
	});
	$(".page").form(
	{
		type:2,
		result:function(form)
		{
			$("#page").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("page")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#page").removeClass("dis");
                    	$("#page textarea").html(d);
					},500)
                }
            });
		}
	});
	$(".ad").form(
	{
		type:2,
		result:function(form)
		{
			$("#ad").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("ad")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#ad").removeClass("dis");
                    	$("#ad textarea").html(d);
					},500)
                }
            });
		}
	});
	$(".link").form(
	{
		type:2,
		result:function(form)
		{
			$("#link").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("link")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#link").removeClass("dis");
                    	$("#link textarea").html(d);
					},500)
                }
            });
		}
	});
	$(".other").form(
	{
		type:2,
		result:function(form)
		{
			$("#other").addClass("dis");
			$.ajax(
			{
                type:'post',
                cache:false,
                url:'{U("other")}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    setTimeout(function(){
						$("#other").removeClass("dis");
                    	$("#other textarea").html(d);
					},500)
                }
            });
		}
	});
})
</script>
</body>
</html>