<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>百度推送</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{THIS_LOCAL}">百度推送</a></div>
    <div class="border">
        <!---->
        <div class="navbar">
            <div class="lefter">
                <a href="javascript:;" class="btach btn btn-info mr-sm">批量推送</a>
                
                <a href="{U('config')}" class="btn btn-yellow">参数配置</a>

                <span class="btn-group btn-group-yellow btn-group-bg">
                    <a class="btn-group-item{if $type==0} active{/if}" href="{U('index','type=0')}">全部</a>
                    <a class="btn-group-item{if $type==1} active{/if}" href="{U('index','type=1')}">未推送</a>
                    <a class="btn-group-item{if $type==2} active{/if}" href="{U('index','type=2')}">已推送</a>
                </span>
            </div>

            
        </div>
        <form method="post" class="ui-form">
        <table class="table table-border table-hover table-striped mb mt">
            <thead class="thead-gray">
                <tr>
                    <th width="30" height="30"><label class="checkbox tips" data-align="right-top" data-title="全选/取消"><input type="checkbox" class="checkall" value=""><i></i></label></th>
                    <th>标题</th>
                    <th width="500">网址</th>
                    <th width="80">状态</th>
                    <th width="80">操作</th>
                </tr>
            </thead>
            <tbody>
            {kuicms:rs pagesize="20" table="kui_content" where="$where" order="ordnum desc,id desc"}
            {rs:eof}
            <tr>
                <td colspan="5">暂无数据</td>
            </tr>
            {/rs:eof}
            <tr>
            	<td><label class="checkbox"><input type="checkbox" name="id" value="{$rs[id]}"><i></i></label></td>
                <td class="text-left">{$rs[title]}</td>
                <td class="text-left">{$rs[link]}</td>
                <td>{iif($rs[ispush]==1,"已推送","<em>未推送</em>")}</td>
                <td><a href="javascript:;" class="push" data-url="{U('push','id='.$rs[id].'')}"><span class="ui-icon-link"></span> 推送</a></td>
            </tr>
            {/kuicms:rs}
            </tbody>
        </table>
        </form>
        {if $total_rs!=0}
        <div class="page page-center page-info">
            <div class="page-list"><ul>{$showpage}</ul></div>
        </div>
        {/if}
        <!---->
    </div>

<script>
$(function()
{
    $(".btach").click(function()
	{
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条内容');
        }
        else
        {
            $.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{U("btach")}',
                data:"id="+data.join(","),
                error:function(e){alert(e.responseText);},
                success:function(d)
				{
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
        }
    });
	$(".push").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要推送？",
			'oktheme':'btn-info',
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
})
</script>
</body>
</html>