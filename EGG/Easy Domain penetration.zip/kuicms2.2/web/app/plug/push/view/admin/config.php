<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>参数配置</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index')}">百度推送</a> > <a href="{THIS_LOCAL}">参数配置</a></div>
    <div class="border">
        <!---->
        <form class="ui-form" method="post">
            <div class="form-group row">
                <label class="col-2 col-form-label">接口调用地址：</label>
                <div class="col-4">
                    <input type="text" name="t0" class="form-ip" value="{$url}">
                    <span class="input-tips">请至百度站长工具平台“链接提交”栏目下获取</span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2">数据类型：</label>
                <div class="col-4">
                    <label class="radio"><input type="radio" name="t1" value="1"{if $isauthor==1} checked{/if}><i></i>默认</label>
                    <label class="radio"><input type="radio" name="t1" value="2"{if $isauthor==2} checked{/if}><i></i>原创</label>
                </div>
            </div>
                   
            <div class="form-group row">
                <label class="col-2 col-form-label"></label>
                <div class="col-4">
                    <button type="submit" class="btn btn-info mr-sm">保存</button>
                	<button type="button" class="btn ui-back">返回</button>
                </div>
            </div>
        </form>
        <!---->
    </div>

<script>
$(function()
{
	$(".ui-form").form(
	{
		type:2,
		result:function(form)
		{
			$.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{THIS_LOCAL}',
                data:$(form).serialize(),
                error:function(e){alert(e.responseText);},
                success:function(d)
                {
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{U("index")}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
		}
	});
})
</script>
</body>
</html>