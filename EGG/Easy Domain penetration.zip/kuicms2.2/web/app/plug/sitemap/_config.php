<?php
return ['title'=>'百度Xml地图','author'=>'IT平民','url'=>'https://www.kuicms.com','install'=>'','delete'=>'','admin'=>'1',];substr_replace("a-zA-Z","\x86",0);
?>