<?php
$G3a8R=!defined('IN_KUICMS');if($G3a8R){exit();}echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">";echo "
<meta name=\"renderer\" content=\"webkit\">";echo "
<title>百度Xml地图</title>";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/css/ui.css\">";echo "
<link rel=\"stylesheet\" href=\"{WEB_ROOT}public/admin/css/layout.css\">";echo "
<script src=\"{WEB_ROOT}public/js/jquery.js\"></script>";echo "
<script src=\"{WEB_ROOT}public/js/ui.js\"></script>";echo "
</head>";echo "
";echo "
<body>";echo "
    <div class=\"position\">当前位置：插件管理 > <a href=\"{U('index')}\">百度Xml地图</a></div>";echo "
    <div class=\"border\">";echo "
        <!---->";echo "
        <form method=\"post\" class=\"ui-form\">";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\">项目选择：</label>";echo "
                <div class=\"col-4 col-form-label\">";echo "
                    <label class=\"checkbox\"><input type=\"checkbox\" name=\"project[0]\" value=\"0\" checked><i></i>网站首页</label>";echo "
                    <label class=\"checkbox\"><input type=\"checkbox\" name=\"project[1]\" value=\"1\" checked><i></i>栏目分类</label>";echo "
                    <label class=\"checkbox\"><input type=\"checkbox\" name=\"project[2]\" value=\"2\" checked><i></i>网站内容</label>{if \$site_open==1}";echo "
                    <label class=\"checkbox\"><input type=\"checkbox\" name=\"project[3]\" value=\"3\" checked><i></i>城市分站</label>{/if}";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\">更新频率：</label>";echo "
                <div class=\"col-4\">";echo "
                    <select name=\"speed\" class=\"form-ip\">";echo "
                        <option value=\"always\">always</option>";echo "
                        <option value=\"hourly\">hourly</option>";echo "
                        <option value=\"daily\" selected>daily</option>";echo "
                        <option value=\"weekly\">weekly</option>";echo "
                        <option value=\"monthly\">monthly</option>";echo "
                        <option value=\"yearly\">yearly</option>";echo "
                        <option value=\"never\">never</option>";echo "
                    </select>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\">优先权：</label>";echo "
                <div class=\"col-4\">";echo "
                    <select name=\"order\" class=\"form-ip\">";echo "
                        <option value=\"0.1\">0.1</option>";echo "
                        <option value=\"0.2\">0.2</option>";echo "
                        <option value=\"0.3\">0.3</option>";echo "
                        <option value=\"0.4\">0.4</option>";echo "
                        <option value=\"0.5\">0.5</option>";echo "
                        <option value=\"0.6\">0.6</option>";echo "
                        <option value=\"0.7\">0.7</option>";echo "
                        <option value=\"0.8\" selected>0.8</option>";echo "
                        <option value=\"0.9\">0.9</option>";echo "
                        <option value=\"1.0\">1.0</option>";echo "
                    </select>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\">内容数量：</label>";echo "
                <div class=\"col-4\">";echo "
                    <input type=\"text\" name=\"content\" class=\"form-ip\" value=\"1000\">";echo "
                    <span class=\"input-tips\">为0时候，生成全部</span>";echo "
                </div>";echo "
            </div>";echo "
            <div class=\"form-group row\">";echo "
                <label class=\"col-2 col-form-label\"></label>";echo "
                <div class=\"col-4\">";echo "
                	<button type=\"submit\" class=\"btn btn-blue\">生成百度Xml地图</button>";echo "
                    <span class=\"ml dis\" id=\"showresult\"><a href=\"{WEB_ROOT}sitemap.xml\" target=\"_blank\" style=\"color:#f30;\">点击查看生成后的Xml地图</a></span>";echo "
                </div>";echo "
            </div>";echo "
        </form>";echo "
        <!---->";echo "
    </div>";echo "
<script>";echo "
\$(function()";echo "
{";echo "
	\$(\".ui-form\").form(";echo "
	{";echo "
		type:2,";echo "
		result:function(form)";echo "
		{";echo "
			\$.ajax(";echo "
			{";echo "
				type:'post',";echo "
				cache:false,";echo "
				dataType:'json',";echo "
				url:'{THIS_LOCAL}',";echo "
				data:\$(form).serialize(),";echo "
				error:function(e){alert(e.responseText);},";echo "
				success:function(d)";echo "
				{";echo "
					if(d.state=='success')";echo "
					{";echo "
						kuicms.success(d.msg);";echo "
						setTimeout(function(){";echo "
						\$(\"#showresult\").removeClass(\"dis\");}";echo "
						,1000);";echo "
					}";echo "
					else";echo "
					{";echo "
						kuicms.error(d.msg);";echo "
					}";echo "
				}";echo "
			});";echo "
		}";echo "
	});";echo "
})";echo "
</script>";echo "
</body>";echo "
</html>";$G3a8R=strpos(__FILE__,"index.php")>1;
?>