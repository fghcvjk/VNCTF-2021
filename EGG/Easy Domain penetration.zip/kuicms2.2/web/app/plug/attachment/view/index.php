<?php if(!defined('IN_KUICMS')) exit;?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>附件管理</title>
<link rel="stylesheet" href="{WEB_ROOT}public/css/ui.css">
<link rel="stylesheet" href="{WEB_ROOT}public/admin/css/layout.css">
<script src="{WEB_ROOT}public/js/jquery.js"></script>
<script src="{WEB_ROOT}public/js/ui.js"></script>
</head>

<body>
    <div class="position">当前位置：插件管理 > <a href="{U('index')}">附件管理</a></div>
    <div class="border">
        <!---->
        
        <div class="tabs" data-href="1">
            <div class="tabs-header-nav">
                <ul class="tabs-nav">
                    <li{if $type==0} class="active"{/if}><a href="{U('index','type=0')}">全部文件</a></li>
                    <li{if $type==1} class="active"{/if}><a href="{U('index','type=1')}">图片文件</a></li>
                    <li{if $type==2} class="active"{/if}><a href="{U('index','type=2')}">视频文件</a></li>
                    <li{if $type==3} class="active"{/if}><a href="{U('index','type=3')}">其他文件</a></li>
                </ul>
                {if kuicms[thumb_auto]==1}
                <div class="tabs-header-more"><a href="javascript:;" class="clear btn btn-info mb-sm">一键清理缩略图</a></div>
                {/if}
            </div>
            
        </div>
        
        <div class="row mt-15 mb">
        	<div class="filelist-left">
            	<ul>
                	<li{if $gid==0} class="actice"{/if}><a href="{U('index','type='.$type.'')}"><span>{$total}</span>未分组</a></li>
                    {kuicms:rs top="0" field="aid,gname,(select count(1) from kui_attachment where gid=a.aid $where_query) as num" table="kui_attachment_group a" where="islock=1" order="ordnum,aid"}
                    <li{if $gid==$rs[aid]} class="actice"{/if}><a href="{U('index','type='.$type.'&gid='.$rs[aid].'')}"><span>{$rs[num]}</span>{$rs[gname]}</a></li>
                    {/kuicms:rs}
                </ul>
                <div class="addgroup">
                	<div class="btn-group">
                        <a class="btn-group-item add_iframe">添加分组</a>
                        {if $total_rs>0}
                        <a class="btn-group-item list_iframe">分组管理</a>
                        {/if}
                    </div>
                </div>
            </div>
            <div class="filelist-right">
            <!---->
            	<form method="post" class="ui-form">
            	{kuicms:rs pagesize="20" table="kui_attachment" where="$where" order="$order"}
                {rs:head}
                <div class="row align-items-center">
                	<label class="checkbox font-13"><input type="checkbox" class="checkall" value=""><i></i>全选/取消</label>
                    <div class="btn-group ml">
                        <a class="btn-group-item move">批量修改分组</a>
                        <a class="btn-group-item btach">批量删除</a>
                    </div>
                </div>
                
    
                 <div class="piclist piclist-16-9 piclist-col-4">
                 {/rs:head}   
                    {rs:eof}
                        <div class="pt pl font-14">暂无文件</div>
                    {/rs:eof}
                    <div class="piclist-item">
                        <div class="piclist-image{if $rs[file_type]>1} file-preview file-type-{trim($rs[file_ext],".")}{/if}">
                        {if $rs[file_type]==1}
                            <a href="{$rs[file_url]}" class="lightbox" data-title="{$rs[file_name]}"><img src="{$rs[file_url]}" /></a>
                        {else}
                        	<a href="{$rs[file_url]}"{if trim($rs[file_ext],".")=="mp4"} class="lightbox" data-mode="video" data-title="{$rs[file_name]}"{else} target="_blank"{/if}></a>
                        {/if}
                        </div>
                        <div class="piclist-body">
                            <div class="piclist-title text-hide"><label class="checkbox"><input type="checkbox" name="id" value="{$rs[id]}"><i></i>{$rs[file_name]}</label></div>
                            <div class="btn-group btn-group-full mt">
                                <a class="btn-group-item group" data-id="{$rs[id]}">分组</a>
                                <a class="btn-group-item dropdown-show" data-val="{if $rs[file_local]==1}{WEB_URL}{/if}{$rs[file_url]}" data-target="#dropdown-link" data-align="bottom">链接</a>
                                <a class="btn-group-item del" data-url="{U('del','id='.$rs[id].'')}">删除</a>
                            </div>
                        </div>
                    </div>
                {rs:foot}  
                </div>
                {/rs:foot}
                {/kuicms:rs}    
            	</form>
           		<div class="dropdown" id="dropdown-link" style="width:400px;">
                    <div class="input-group pl pr">
                        <input type="text" id="outurl" class="form-ip radius-right-none" readonly value="">
                        <a href="javascript:;" class="after ui-icon-file-copy ui-copy" data-target="outurl">复制</a>
                    </div>
                </div>
            <!---->
            </div>
        </div>

        {if $total_rs!=0}
        <div class="page page-center page-info mt">
            <ul>{$showpage}</ul>
        </div>
        {/if}
        <!---->
    </div>
<script>
$(function()
{
	$(".dropdown-show").click(function()
	{
		var val=$(this).data("val");
		$("#outurl").val(val);
	});
	$(".add_iframe").click(function()
	{
		$.dialogbox(
		{
			'title':"添加分组",
			'inputval':"",
			'inputholder':"请输入分组名称",
			'type':1,
			'ok':function(e)
			{
				var val=e.inputval();
				if(val=='')
				{
					kuicms.error("分组名称不能为空");
				}
				else
				{
					$.ajax(
					{
						url:'{U("addgroup")}',
						type:'post',
						dataType:'json',
						data:"name="+encodeURIComponent(val),
						success:function(d)
						{
							if(d.state=='success')
							{
								kuicms.success(d.msg);
								setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
							}
							else
							{
								kuicms.error(d.msg);
							}
						}
					});
				}
			}
		});
	});
	$(".list_iframe").click(function()
	{
		$.dialogbox(
		{
			'title':"分组管理",
			'text':'{U("lists")}',
			'width':'600px',
			'height':'50%',
			'type':3,
			'oktheme':'btn-info',
			'footer':false
		});
	});
	$(".clear").click(function()
	{
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要清理？",
			'ok':function(e)
			{
				$.ajax(
				{
                    url:'{U('clear')}',
					type:'post',
					dataType:'json',
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
	$(".del").click(function()
	{
		var url=$(this).attr("data-url");
		$.dialog(
		{
			'title':"操作提示",
			'text':"确定要删除？不可恢复！",
			'ok':function(e)
			{
				$.ajax(
				{
                    url:url,type:'post',dataType:'json',
					error:function(e){alert(e.responseText);},
                    success:function(d)
                    {
                        e.close();
                        if(d.state=='success')
                        {
                            kuicms.success(d.msg);
                            setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                        }
                        else
                        {
                            kuicms.error(d.msg);
                        }
                    }
                });
			}
		});
    });
	$(".btach").click(function()
	{
		var type=$(this).attr("type");
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条');
        }
        else
        {
            $.ajax(
			{
                type:'post',
                cache:false,
                dataType:'json',
                url:'{U("btach")}',
                data:"id="+data.join(","),
                error:function(e){alert(e.responseText);},
                success:function(d)
				{
                    if(d.state=='success')
                    {
                        kuicms.success(d.msg);
                        setTimeout(function(){location.href='{THIS_LOCAL}';},1500);
                    }
                    else
                    {
                        kuicms.error(d.msg);
                    }
                }
            });
        }
    });
	
	$(".group").click(function()
	{
		var id=$(this).data("id");
		$.dialogbox(
		{
			'title':"修改分组",
			'text':'{U("move")}',
			'width':'500px',
			'height':'370px',
			'type':3,
			'oktheme':'btn-info',
			'ok':function(e)
			{
				var gid=e.iframe().contents().find("#go").val();
				if(gid=='')
				{
					kuicms.error('请选择分组');
					return false;
				}
				$.ajax(
				{
					 type:'post',
					 url:'{U("move")}',
					 dataType:'json',
					 data:'id='+id+'&gid='+gid,
					 error:function(e){alert(e.responseText);},
					 success:function(d)
					 {
						if(d.state=='success')
						{
							e.close();
							kuicms.success(d.msg);
							setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
						}
						else
						{
							kuicms.error(d.msg);
						}
					}
				});
			}
		});
	});
	
	$(".move").click(function()
	{
        var type=$(this).attr("type");
		var data=[];
		$(".ui-form").find("input[type=checkbox]:checked").each(function()
		{
			if($(this).attr("class")!='checkall' && !$(this).closest("label").hasClass("switch"))
			{
				data.push($(this).val());
			}
		});
        if(data.length==0)
        {
            kuicms.error('至少选择一条');
        }
        else
        {
			var list=data.join(",");
			$.dialogbox(
			{
				'title':"批量修改分组",
				'text':'{U("move")}',
				'width':'500px',
				'height':'370px',
				'type':3,
				'oktheme':'btn-info',
				'ok':function(e)
				{
					var gid=e.iframe().contents().find("#go").val();
					if(gid=='')
                    {
                        kuicms.error('请选择分组');
                        return false;
                    }
					$.ajax(
					{
                         type:'post',
                         url:'{U("move")}',
                         dataType:'json',
                         data:'id='+list+'&gid='+gid,
                         error:function(e){alert(e.responseText);},
                         success:function(d)
						 {
                            if(d.state=='success')
                            {
								e.close();
                                kuicms.success(d.msg);
                                setTimeout(function(){location.href='{THIS_LOCAL}';},1000);
                            }
                            else
                            {
                                kuicms.error(d.msg);
                            }
                        }
                    });
				}
			});
        }
    });
})
</script>
</body>
</html>