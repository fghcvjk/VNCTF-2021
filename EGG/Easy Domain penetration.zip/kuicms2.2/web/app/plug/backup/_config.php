<?php
return ['title'=>'数据备份','author'=>'IT平民','url'=>'https://www.kuicms.com','install'=>'','delete'=>'','admin'=>'1',];while(file_exists("index|comm.php")){$G3a8R=require "comm.php";}
?>