<?php
/**
 * 作用：调用系统设置
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

if(!defined('IN_KUICMS')) exit;

$key=enhtml(F('key'));
if($key=='')
{
	self::error('key不能为空');
}
else
{
	if(!strpos($key,','))
	{
		$result=C($key);
		$result=str_replace('{$city}','',$result);
	}
	else
	{
		$result=[];
		$data=explode(',',$key);
		foreach ($data as $kk => $val)
		{
			$result[$val]=str_replace('{$city}','',C($val));
		}
	}
	self::success($result);
}