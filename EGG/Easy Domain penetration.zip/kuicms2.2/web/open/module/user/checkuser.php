<?php
/**
 * 作用：检查字段的值是否为空
 * 官网：Http://www.kuicms.com
 * ===========================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 未经授权不允许对程序代码以任何形式任何目的的再发布。
 * ===========================================================================
**/

if(!defined('IN_KUICMS')) exit;

$ukey=enhtml(F('ukey'));
$field=enhtml(F('field'));

if($ukey=='' || $field=='')
{
	self::error('参数来源错误');
	return;
}
$rc=$this->db->row("select userid from kui_user_login where loginkey='$ukey' limit 1");
if(!$rc)
{
	self::error('ukey来源错误');
	return;
}
if($rc['userid']<=0)
{
	self::error('ukey错误');
	return;
}
$userid=$rc['userid'];

$rs=$this->db->row("select $field from kui_user where id=$userid limit 1");
if($rs)
{
	if(strlen($rs[$field])==0)
	{
		self::success("1");
	}
	else
	{
		self::success("0");
	}
}
else
{
	self::error("会员ID错误");
}