chmod -R 777 /var/www/html/storage/framework/sessions
chmod -R 777 /var/www/html/storage/logs